#pragma once

// Start the optional player health regeneration worker for the supported XBE build.
bool health_regen_initialize();
