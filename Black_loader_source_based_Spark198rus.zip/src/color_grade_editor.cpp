#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <algorithm>
#include <cmath>
#include <cwchar>
#include <iterator>
#include <string>

namespace {
enum { ID_LEVEL=100, ID_ENABLED=101, ID_SLIDER_BASE=110, ID_EDIT_BASE=120, ID_LUT=130, ID_IMPORT=131, ID_SAVE=132, ID_RELOAD=133 };
constexpr UINT_PTR ID_AUTO_SAVE=2;
constexpr int kFields=10;
const wchar_t *kKeys[kFields]={L"exposure",L"contrast",L"saturation",L"hue",L"vibrance",L"temperature",L"tint",L"shadows",L"highlights",L"lut_strength"};
const wchar_t *kNames[kFields]={L"Exposure",L"Contrast",L"Saturation",L"Hue shift",L"Vibrance",L"Temperature",L"Tint",L"Shadows",L"Highlights",L"LUT mix"};
const int kLow[kFields]={-500,0,0,-180,-100,-100,-100,-100,-100,0};
const int kHigh[kFields]={500,300,300,180,100,100,100,100,100,100};
const float kScale[kFields]={100,100,100,1,100,100,100,100,100,100};
const float kDefault[kFields]={0,1,1,0,0,0,0,0,0,1};
HWND g_window,g_level,g_enabled,g_sliders[kFields],g_edits[kFields],g_lut,g_status;
std::wstring g_ini,g_exe_dir;
bool g_loading,g_dirty;

std::wstring section_for(int n){wchar_t s[40]{};swprintf_s(s,L"color_grade_level_%02d",n);return s;}
int mission(){const LRESULT i=SendMessageW(g_level,CB_GETCURSEL,0,0);return i<0?0:(int)i;}
std::wstring read_value(const wchar_t*sec,const wchar_t*key,const wchar_t*fallback){wchar_t b[512]{};GetPrivateProfileStringW(sec,key,fallback,b,(DWORD)std::size(b),g_ini.c_str());return b;}
float parse_float(const std::wstring&s,float fallback){wchar_t*e=nullptr;float v=wcstof(s.c_str(),&e);return e==s.c_str()||!std::isfinite(v)?fallback:v;}
float read_field(int i){std::wstring base=read_value(L"color_grade",kKeys[i],L"");return parse_float(read_value(section_for(mission()).c_str(),kKeys[i],base.c_str()),kDefault[i]);}
float edit_value(int i){wchar_t b[64]{};GetWindowTextW(g_edits[i],b,(int)std::size(b));return std::clamp(parse_float(b,kDefault[i]),(float)kLow[i]/kScale[i],(float)kHigh[i]/kScale[i]);}
void show_value(int i,float v){wchar_t b[32]{};swprintf_s(b,L"%.2f",v);SetWindowTextW(g_edits[i],b);SendMessageW(g_sliders[i],TBM_SETPOS,TRUE,(LPARAM)lroundf(v*kScale[i]));}
void load_selected(){
    KillTimer(g_window,ID_AUTO_SAVE);g_dirty=false;g_loading=true;const int n=mission();
    std::wstring def=read_value(L"color_grade",L"enabled",L"0"),active=read_value(section_for(n).c_str(),L"enabled",def.c_str());
    SendMessageW(g_enabled,BM_SETCHECK,(active==L"1"||active==L"true"||active==L"on")?BST_CHECKED:BST_UNCHECKED,0);
    for(int i=0;i<kFields;i++)show_value(i,read_field(i));
    std::wstring base=read_value(L"color_grade",L"lut",L"");SetWindowTextW(g_lut,read_value(section_for(n).c_str(),L"lut",base.c_str()).c_str());
    g_loading=false;SetWindowTextW(g_status,L"Live preview is on. Changes save automatically and reload in-game.");
}
void schedule_auto_save(){if(g_loading||!g_window)return;g_dirty=true;KillTimer(g_window,ID_AUTO_SAVE);SetTimer(g_window,ID_AUTO_SAVE,300,nullptr);SetWindowTextW(g_status,L"Live preview: saving this mission automatically…");}
void save_selected(){
    const std::wstring section=section_for(mission());
    WritePrivateProfileStringW(section.c_str(),L"enabled",SendMessageW(g_enabled,BM_GETCHECK,0,0)==BST_CHECKED?L"1":L"0",g_ini.c_str());
    wchar_t b[64]{};
    for(int i=0;i<kFields;i++){swprintf_s(b,L"%.3f",edit_value(i));WritePrivateProfileStringW(section.c_str(),kKeys[i],b,g_ini.c_str());}
    wchar_t lut[512]{};GetWindowTextW(g_lut,lut,(int)std::size(lut));WritePrivateProfileStringW(section.c_str(),L"lut",lut,g_ini.c_str());
    WritePrivateProfileStringW(nullptr,nullptr,nullptr,nullptr);
    SetWindowTextW(g_status,L"Saved. The game reloads world_fx.ini automatically.");
}
void save_now(){KillTimer(g_window,ID_AUTO_SAVE);g_dirty=false;save_selected();}
void import_lut(){
    wchar_t source[MAX_PATH]{};OPENFILENAMEW ofn{};ofn.lStructSize=sizeof(ofn);ofn.hwndOwner=g_window;ofn.lpstrFilter=L"3D LUT files (*.cube)\0*.cube\0All files (*.*)\0*.*\0\0";ofn.lpstrFile=source;ofn.nMaxFile=(DWORD)std::size(source);ofn.Flags=OFN_FILEMUSTEXIST|OFN_PATHMUSTEXIST;ofn.lpstrTitle=L"Import a 3D .cube LUT";
    if(!GetOpenFileNameW(&ofn))return;
    wchar_t target[MAX_PATH]{};swprintf_s(target,L"%sfx\\grade_%02d.cube",g_exe_dir.c_str(),mission());CreateDirectoryW((g_exe_dir+L"fx").c_str(),nullptr);
    if(_wcsicmp(source,target)!=0&&!CopyFileW(source,target,FALSE)){SetWindowTextW(g_status,L"Could not copy the LUT into the runtime fx folder.");return;}
    wchar_t rel[64]{};swprintf_s(rel,L"fx\\grade_%02d.cube",mission());SetWindowTextW(g_lut,rel);SendMessageW(g_enabled,BM_SETCHECK,BST_CHECKED,0);schedule_auto_save();
}
void label(HWND h,const wchar_t*t,int x,int y,int width){CreateWindowW(L"STATIC",t,WS_CHILD|WS_VISIBLE,x,y,width,22,h,nullptr,nullptr,nullptr);}
HWND make_edit(HWND h,int id,int x,int y,int width){return CreateWindowExW(WS_EX_CLIENTEDGE,L"EDIT",L"0",WS_CHILD|WS_VISIBLE|WS_TABSTOP|ES_AUTOHSCROLL,x,y,width,25,h,(HMENU)(INT_PTR)id,nullptr,nullptr);}
LRESULT CALLBACK wndproc(HWND h,UINT m,WPARAM w,LPARAM l){
    switch(m){
    case WM_CREATE:{
        g_window=h;
        label(h,L"Per-mission full-frame grading. Sliders preview automatically; imported 3D .cube LUTs blend after the controls.",16,12,860);
        label(h,L"Mission",16,50,80);g_level=CreateWindowW(WC_COMBOBOXW,L"",WS_CHILD|WS_VISIBLE|WS_TABSTOP|CBS_DROPDOWNLIST,112,44,150,240,h,(HMENU)ID_LEVEL,nullptr,nullptr);
        for(int i=0;i<100;i++){wchar_t t[24]{};swprintf_s(t,L"Mission %02d",i);SendMessageW(g_level,CB_ADDSTRING,0,(LPARAM)t);}SendMessageW(g_level,CB_SETCURSEL,0,0);
        g_enabled=CreateWindowW(L"BUTTON",L"Enable grade for this mission",WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_AUTOCHECKBOX,310,46,280,24,h,(HMENU)ID_ENABLED,nullptr,nullptr);
        for(int i=0;i<kFields;i++){
            const int col=i%2,row=i/2,x=16+col*440,y=96+row*56;
            label(h,kNames[i],x,y+6,112);
            g_sliders[i]=CreateWindowExW(0,TRACKBAR_CLASSW,L"",WS_CHILD|WS_VISIBLE|WS_TABSTOP|TBS_NOTICKS,x+116,y,220,34,h,(HMENU)(INT_PTR)(ID_SLIDER_BASE+i),nullptr,nullptr);
            SendMessageW(g_sliders[i],TBM_SETRANGEMIN,FALSE,kLow[i]);SendMessageW(g_sliders[i],TBM_SETRANGEMAX,TRUE,kHigh[i]);
            g_edits[i]=make_edit(h,ID_EDIT_BASE+i,x+342,y+4,66);
        }
        label(h,L"3D LUT (.cube)",16,385,112);g_lut=make_edit(h,ID_LUT,132,381,565);CreateWindowW(L"BUTTON",L"Import LUT…",WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_PUSHBUTTON,712,380,130,29,h,(HMENU)ID_IMPORT,nullptr,nullptr);
        label(h,L"Import copies the LUT to this build's fx folder as grade_NN.cube.",16,419,800);
        CreateWindowW(L"BUTTON",L"Save now",WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_PUSHBUTTON,16,462,130,34,h,(HMENU)ID_SAVE,nullptr,nullptr);
        CreateWindowW(L"BUTTON",L"Reload",WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_PUSHBUTTON,158,462,96,34,h,(HMENU)ID_RELOAD,nullptr,nullptr);
        g_status=CreateWindowW(L"STATIC",L"",WS_CHILD|WS_VISIBLE,16,510,850,38,h,nullptr,nullptr,nullptr);load_selected();return 0;}
    case WM_COMMAND:
        if(LOWORD(w)==ID_LEVEL&&HIWORD(w)==CBN_SELCHANGE){if(g_dirty)save_now();load_selected();return 0;}
        if(LOWORD(w)==ID_SAVE){save_now();return 0;}
        if(LOWORD(w)==ID_RELOAD){load_selected();return 0;}
        if(LOWORD(w)==ID_IMPORT){import_lut();return 0;}
        if((HIWORD(w)==EN_CHANGE&&((LOWORD(w)>=ID_EDIT_BASE&&LOWORD(w)<ID_EDIT_BASE+kFields)||LOWORD(w)==ID_LUT))||(LOWORD(w)==ID_ENABLED&&HIWORD(w)==BN_CLICKED)){schedule_auto_save();return 0;}
        return 0;
    case WM_HSCROLL:{if(g_loading)return 0;const int i=GetDlgCtrlID((HWND)l)-ID_SLIDER_BASE;if(i>=0&&i<kFields){float v=(float)SendMessageW((HWND)l,TBM_GETPOS,0,0)/kScale[i];wchar_t b[32]{};swprintf_s(b,L"%.2f",v);SetWindowTextW(g_edits[i],b);schedule_auto_save();}return 0;}
    case WM_TIMER:if(w==ID_AUTO_SAVE&&g_dirty){KillTimer(h,ID_AUTO_SAVE);g_dirty=false;save_selected();}return 0;
    case WM_CLOSE:if(g_dirty)save_now();DestroyWindow(h);return 0;
    case WM_DESTROY:KillTimer(h,ID_AUTO_SAVE);PostQuitMessage(0);return 0;
    }
    return DefWindowProcW(h,m,w,l);
}
}
int WINAPI wWinMain(HINSTANCE instance,HINSTANCE,PWSTR,int){
    SetProcessDPIAware();INITCOMMONCONTROLSEX cc{sizeof(cc),ICC_BAR_CLASSES};InitCommonControlsEx(&cc);
    wchar_t p[MAX_PATH]{};GetModuleFileNameW(nullptr,p,(DWORD)std::size(p));if(wchar_t*s=wcsrchr(p,L'\\'))s[1]=0;g_exe_dir=p;g_ini=g_exe_dir+L"world_fx.ini";
    WNDCLASSW wc{};wc.lpfnWndProc=wndproc;wc.hInstance=instance;wc.hCursor=LoadCursorW(nullptr,IDC_ARROW);wc.hbrBackground=(HBRUSH)(COLOR_WINDOW+1);wc.lpszClassName=L"BlackColorGradeEditor";RegisterClassW(&wc);
    HWND h=CreateWindowW(wc.lpszClassName,L"BLACK Color Grade Editor",WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX,CW_USEDEFAULT,CW_USEDEFAULT,920,620,nullptr,nullptr,instance,nullptr);if(!h)return 1;
    ShowWindow(h,SW_SHOW);UpdateWindow(h);MSG msg{};while(GetMessageW(&msg,nullptr,0,0)>0){TranslateMessage(&msg);DispatchMessageW(&msg);}return(int)msg.wParam;
}
