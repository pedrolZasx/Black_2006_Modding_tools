#include "wind.h"
#include "common.h"
#include "rain.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <d3d9.h>
#include <algorithm>
#include <map>
#include <unordered_map>
#include <unordered_set>
#include <string>
#include <vector>

namespace wind {
namespace {

struct Class {
    bool enabled = true;
    float strength = 1.0f;   // multiplier on the master strength
    int weight = 0;          // 0 none (whole piece moves), 1 uv v (V=0 is the tip), 2 uv v (V=1 is the tip), 3 vertex colour alpha
    float bend = 1.5f;       // weight ^ bend: >1 keeps the root still, tips move more
    float phase = 0.0f;      // radians: so grass and trees do not move in lock step
};

struct Settings {
    bool enabled = true;
    std::vector<int> levels;      // empty = every level
    std::vector<uint32_t> forced_foliage; // mission-specific shader hashes; used instead of the global foliage list
    bool foliage_hashes_override = false;
    bool follow_rain = true;      // direction and base speed from rain.ini's wind (so rain and leaves agree)
    float direction = 60.0f;      // degrees the wind blows TOWARDS: 0 = +Z, 90 = +X (ignored when follow_rain)
    float drift = 25.0f;          // degrees the direction wanders left and right over time
    float drift_speed = 0.05f;    // Hz of that wander
    float speed = 6.0f;           // m/s: how fast gust fronts travel across the map (also scales with rain wind when follow_rain)
    float wavelength = 14.0f;     // metres between gust fronts
    float strength = 0.18f;       // metres of lean at the tips at full weight
    float variation = 0.35f;      // per-position phase and amplitude variation for less synchronized foliage
    float gust = 0.6f;            // 0..2 how much the strength swells and dies over time
    float gust_speed = 0.25f;     // Hz of the swell
    float flutter = 0.35f;        // 0..1 fast random shiver (fraction of strength), different for every vertex position
    float flutter_speed = 3.2f;   // Hz
    float droop = 0.25f;          // tips drop a little when bent (fraction of the lean)
    Class foliage, lightray, grass; // foliage = alpha-tested trees / bushes, lightray = alpha-blended cards (light rays), grass = only shaders listed under [shaders] grass=
    bool lightray_blend = true;   // alpha-blended (not alpha-tested) world cards count as light rays
};

struct GrassCfg { std::vector<std::pair<int, float>> sway; };
std::vector<uint32_t> g_force_foliage, g_force_lightray, g_force_grass, g_ignore, g_ground_shaders;
bool g_snap = true;
GrassCfg g_grass;
struct Dens { int n = 1; float spread = 0.4f; };
int g_snap_budget = 50000;  // [density] snap_budget: max vertices per frame that get per-vertex ground snapping (0 = unlimited); the rest are copied without snapping
int g_copy_cap = 300000;    // [density] copy_cap: max extra (copied) vertices per frame over all density copies (0 = unlimited); later draws get fewer copies
Dens g_dens[4]; // by class: 1 tree / foliage, 2 light ray, 3 grass

Settings g_s;
Settings g_default;
std::vector<std::pair<int, Settings>> g_level;
bool g_loaded = false, g_user_on = true;
CompileOpts g_co;
FILETIME g_stamp{};
DWORD g_last = 0;

std::wstring exe_dir()
{
    wchar_t p[MAX_PATH]{};
    GetModuleFileNameW(nullptr, p, MAX_PATH);
    wchar_t *s = wcsrchr(p, L'\\');
    if (s) s[1] = 0;
    return p;
}
std::wstring ini_path() { return exe_dir() + L"wind.ini"; }

std::string trim(const std::string &s)
{
    size_t a = s.find_first_not_of(" \t\r\n"), b = s.find_last_not_of(" \t\r\n");
    return a == std::string::npos ? std::string() : s.substr(a, b - a + 1);
}
std::string lower(std::string s) { for (char &c : s) c = (char)tolower((unsigned char)c); return s; }

void parse_hexlist(const std::string &v, std::vector<uint32_t> &out)
{
    const char *p = v.c_str();
    while (*p) { char *e; unsigned long n = strtoul(p, &e, 16); if (e == p) { p++; continue; } out.push_back((uint32_t)n); p = e; }
}
bool pbool(const std::string &v) { const std::string l = lower(v); return !(l == "0" || l == "false" || l == "off" || l == "no" || l.empty()); }

int pweight(const std::string &v)
{
    const std::string l = lower(v);
    if (l == "none" || l == "uniform") return 0;
    if (l == "uv" || l == "uv_top" || l == "uv_v0") return 1;
    if (l == "uv_bottom" || l == "uv_v1") return 2;
    if (l == "alpha" || l == "color_alpha") return 3;
    return std::clamp(atoi(l.c_str()), 0, 3);
}

void apply_class(Class &c, const std::string &k, const std::string &v)
{
    const float x = (float)atof(v.c_str());
    if (k == "enabled") c.enabled = pbool(v);
    else if (k == "strength") c.strength = std::clamp(x, 0.f, 10.f);
    else if (k == "weight") c.weight = pweight(v);
    else if (k == "bend") c.bend = std::clamp(x, 0.2f, 6.f);
    else if (k == "phase") c.phase = x;
}

void apply_main(Settings &s, const std::string &k, const std::string &v)
{
    const float x = (float)atof(v.c_str());
    if (k == "enabled") s.enabled = pbool(v);
    else if (k == "levels") {
        s.levels.clear();
        const char *p = v.c_str();
        while (*p) { char *e; long n = strtol(p, &e, 10); if (e == p) { p++; continue; } s.levels.push_back((int)n); p = e; }
    }
    else if (k == "follow_rain") s.follow_rain = pbool(v);
    else if (k == "direction") s.direction = x;
    else if (k == "direction_drift") s.drift = std::clamp(x, 0.f, 180.f);
    else if (k == "direction_drift_speed") s.drift_speed = std::clamp(x, 0.f, 2.f);
    else if (k == "speed") s.speed = std::clamp(x, 0.f, 60.f);
    else if (k == "wavelength") s.wavelength = std::clamp(x, 0.5f, 200.f);
    else if (k == "strength") s.strength = std::clamp(x, 0.f, 3.f);
    else if (k == "variation") s.variation = std::clamp(x, 0.f, 1.f);
    else if (k == "gust") s.gust = std::clamp(x, 0.f, 2.f);
    else if (k == "gust_speed") s.gust_speed = std::clamp(x, 0.f, 3.f);
    else if (k == "flutter") s.flutter = std::clamp(x, 0.f, 1.f);
    else if (k == "flutter_speed") s.flutter_speed = std::clamp(x, 0.f, 20.f);
    else if (k == "droop") s.droop = std::clamp(x, 0.f, 1.f);
    else if (k == "lightray_blend") s.lightray_blend = pbool(v);
}

const char *kDefaultIni =
    "; wind.ini  -  put next to black.exe. Re-read while the game runs (save the file and look). F10 = wind on/off.\n"
    ";\n"
    "; The vertex shaders of alpha-tested (leaves, bushes, trees) and alpha-blended (light ray cards) WORLD geometry get a wind displacement.\n"
    "; Only shaders that transform v0 with the game's world view-projection (slots c10..c13) are moved, so the push is a true world-space\n"
    "; direction (the same trick world_lights uses). Skinned meshes (people, the gun) are never touched.\n"
    ";\n"
    "; direction     degrees the wind blows TOWARDS, 0 = +Z, 90 = +X. Ignored when follow_rain=1 (then rain.ini's wind is used).\n"
    "; speed         m/s the gust fronts travel across the map     wavelength  metres between fronts\n"
    "; strength      metres of lean at full weight (tips)           gust / gust_speed   slow swell of strength (0..2, Hz)\n"
    "; flutter       fast per-vertex shiver (0..1 of strength)      droop       tips dip a little when they bend\n"
    "; weight        how much of a piece moves:  none = the whole piece, uv = V=0 is the tip, uv_bottom = V=1 is the tip,\n"
    ";               alpha = vertex colour alpha. Grass needs uv/alpha or the roots slide over the ground.\n"
    "; bend          weight^bend: 1 linear, 2+ keeps the root still and moves only the tip\n"
    "[wind]\n"
    "enabled=1\n"
    "follow_rain=1\n"
    "direction=60\n"
    "direction_drift=25\n"
    "direction_drift_speed=0.05\n"
    "speed=6\n"
    "wavelength=14\n"
    "strength=0.18\n"
    "variation=0.35\n"
    "gust=0.6\n"
    "gust_speed=0.25\n"
    "flutter=0.35\n"
    "flutter_speed=3.2\n"
    "droop=0.25\n"
    "lightray_blend=1   ; alpha-blended world cards are treated as light rays (wind is off for them by default, see [wind_lightray])\n"
    "\n"
    "[wind_foliage]   ; alpha-tested: leaves, bushes, tree crowns\n"
    "enabled=1\n"
    "strength=1.0\n"
    "weight=none\n"
    "bend=1.5\n"
    "phase=0\n"
    "\n"
    "[wind_lightray] ; alpha-blended cards = light rays: no wind by default\n"
    "enabled=0\n"
    "strength=0\n"
    "weight=none\n"
    "\n"
    "[wind_grass]     ; only shaders listed under [shaders] grass=\n"
    "enabled=1\n"
    "strength=1.6\n"
    "weight=uv\n"
    "bend=1.8\n"
    "phase=1.7\n"
    "\n"
    "; compile-time (restart the game after changing): which vertex registers carry texcoord 0 / diffuse colour,\n"
    "; and an optional object->world matrix slot for shaders that are not in world space.\n"
    "[compile]\n"
    "uv_reg=9\n"
    "color_reg=3\n"
    "world_const=-1\n"
    "object_space=0\n"
    "\n"
    "; Pick shaders by hash. Press F11 in game, then read the [wind-scan] lines in black.log: each shader that draws is listed with its\n"
    "; draw count and alpha state. Grass is usually the one with many alpha-blended or alpha-tested draws. Restart after changing.\n"
    "[shaders]\n"
    "foliage=            ; hex hashes, e.g. 1A2B3C4D,5E6F7081   (always moved as leaves, even if the draw state says otherwise)\n"
    "grass=              ; the real grass: moved by [wind_grass], thickened by [density] grass\n"
    "lightray=           ; force light ray class\n"
    "ignore=             ; never touched\n"
    "ground=             ; shaders that draw the ground / walls (hex): density copies of grass then follow the ground height instead of floating\n"
    "\n"
    "; DENSITY: every draw of the class is drawn N times in total (1 = off, max 8); copies are shifted sideways by up to *_spread metres\n"
    "; (stable per patch, no shimmer). Costs frame time. tree = alpha-tested foliage (bushes, crowns); NOTE: a tree trunk is a different draw\n"
    "; (no alpha test) and is not copied, so use small tree_spread / bushes first. Copies sit at the same height (slopes: some float / sink).\n"
    "[density]\n"
    "tree=1\n"
    "tree_spread=1.5\n"
    "lightray=1\n"
    "lightray_spread=0.4\n"
    "grass=1\n"
    "grass_spread=0.4\n"
    "snap_to_ground=1   ; needs [shaders] ground=; copies are moved up / down to the ground under them (per vertex)\n"
    "snap_budget=50000  ; anti-lag: max vertices per frame that get ground snapping (0 = unlimited); the rest are copied without snapping\n"
    "copy_cap=300000    ; anti-lag: max extra copied vertices per frame (0 = unlimited); once reached, later draws get fewer copies\n"
    "\n"
    "; sway_const: the game animates its own grass in its shader; if you find the constant slot that drives it (disassembly in the log),\n"
    "; scale it here (slot = Xbox c-register + 96). More than one sway_const line is allowed.\n"
    "[grass]\n"
    "; sway_const=120 0.5\n"
    "\n"
    "; per mission override, e.g. a stormier mission 3:\n"
    "; [wind_level_03]\n"
    "; strength=0.35\n"
    "; gust=1.2\n";

void load()
{
    g_default = Settings();
    g_level.clear();
    g_co = CompileOpts();
    FILE *fp = nullptr;
    _wfopen_s(&fp, ini_path().c_str(), L"rt");
    if (!fp) {
        FILE *w = nullptr;
        if (!_wfopen_s(&w, ini_path().c_str(), L"wt") && w) { fputs(kDefaultIni, w); fclose(w); logf("[wind] wrote default wind.ini"); }
        g_s = g_default;
        g_default.lightray.enabled = false; g_default.lightray.strength = 0.f; g_default.foliage.weight = 0; g_default.grass.weight = 1; g_default.grass.strength = 1.6f; g_default.grass.bend = 1.8f; g_default.grass.phase = 1.7f;
        g_s = g_default;
        return;
    }
    struct Sec { std::string name; std::vector<std::pair<std::string, std::string>> kv; };
    std::vector<Sec> secs;
    char line[1024];
    while (fgets(line, sizeof line, fp)) {
        std::string s = trim(line);
        if (s.empty() || s[0] == ';' || s[0] == '#') continue;
        if (s[0] == '[') {
            const size_t e = s.find(']');
            secs.push_back({lower(trim(s.substr(1, e == std::string::npos ? std::string::npos : e - 1))), {}});
        } else if (!secs.empty()) {
            const size_t eq = s.find('=');
            if (eq == std::string::npos) continue;
            std::string v = trim(s.substr(eq + 1));
            const size_t cm = v.find(';');
            if (cm != std::string::npos) v = trim(v.substr(0, cm));
            secs.back().kv.push_back({lower(trim(s.substr(0, eq))), v});
        }
    }
    fclose(fp);
    g_default.lightray.enabled = false; g_default.lightray.strength = 0.f;
    g_default.grass.weight = 1; g_default.grass.strength = 1.6f; g_default.grass.bend = 1.8f; g_default.grass.phase = 1.7f;
    for (const Sec &sec : secs) {
        if (sec.name == "wind") for (auto &kv : sec.kv) apply_main(g_default, kv.first, kv.second);
        else if (sec.name == "wind_foliage") for (auto &kv : sec.kv) apply_class(g_default.foliage, kv.first, kv.second);
        else if (sec.name == "wind_lightray") for (auto &kv : sec.kv) apply_class(g_default.lightray, kv.first, kv.second);
        else if (sec.name == "wind_grass") for (auto &kv : sec.kv) apply_class(g_default.grass, kv.first, kv.second);
        else if (sec.name == "compile") for (auto &kv : sec.kv) {
            const int x = atoi(kv.second.c_str());
            if (kv.first == "uv_reg") g_co.uv_reg = std::clamp(x, 1, 15);
            else if (kv.first == "color_reg") g_co.color_reg = std::clamp(x, 1, 15);
            else if (kv.first == "world_const") g_co.world_const = std::clamp(x, -1, 188);
            else if (kv.first == "object_space") g_co.object_space = pbool(kv.second);
        }
    }
    g_ground_shaders.clear(); g_snap = true; g_force_foliage.clear(); g_force_lightray.clear(); g_force_grass.clear(); g_ignore.clear(); g_grass = GrassCfg(); g_snap_budget = 50000; g_copy_cap = 300000; for (Dens &d : g_dens) d = Dens();
    for (const Sec &sec : secs) {
        if (sec.name == "shaders") for (auto &kv : sec.kv) {
            if (kv.first == "foliage" || kv.first == "tree") parse_hexlist(kv.second, g_force_foliage);
            else if (kv.first == "lightray") parse_hexlist(kv.second, g_force_lightray);
            else if (kv.first == "ground") parse_hexlist(kv.second, g_ground_shaders);
            else if (kv.first == "grass") parse_hexlist(kv.second, g_force_grass);
            else if (kv.first == "ignore") parse_hexlist(kv.second, g_ignore);
        } else if (sec.name == "density") for (auto &kv : sec.kv) {
            if (kv.first == "snap_to_ground") { g_snap = pbool(kv.second); continue; }
            if (kv.first == "snap_budget") { g_snap_budget = std::max(0, atoi(kv.second.c_str())); continue; }
            if (kv.first == "copy_cap") { g_copy_cap = std::max(0, atoi(kv.second.c_str())); continue; }
            const int n = std::clamp(atoi(kv.second.c_str()), 1, 8);
            const float sp = std::clamp((float)atof(kv.second.c_str()), 0.f, 8.f);
            if (kv.first == "tree") g_dens[1].n = n; else if (kv.first == "tree_spread") g_dens[1].spread = sp;
            else if (kv.first == "lightray") g_dens[2].n = n; else if (kv.first == "lightray_spread") g_dens[2].spread = sp;
            else if (kv.first == "grass") g_dens[3].n = n; else if (kv.first == "grass_spread") g_dens[3].spread = sp;
        } else if (sec.name == "grass") for (auto &kv : sec.kv) {
            if (kv.first == "sway_const") { int sl; float sc; if (sscanf_s(kv.second.c_str(), "%d %f", &sl, &sc) == 2 && sl >= 0 && sl < 192) g_grass.sway.push_back({sl, sc}); }
        }
    }
    for (const Sec &sec : secs) {
        int level = -1;
        if (sscanf_s(sec.name.c_str(), "wind_level_%d", &level) != 1 || level < 0) continue;
        Settings s = g_default;
        for (auto &kv : sec.kv) {
            if (kv.first == "foliage_hashes") {
                const std::string hashes = lower(trim(kv.second));
                s.foliage_hashes_override = hashes == "none";
                s.forced_foliage.clear();
                if (!hashes.empty() && hashes != "none") {
                    s.foliage_hashes_override = true;
                    parse_hexlist(kv.second, s.forced_foliage);
                }
                continue;
            }
            apply_main(s, kv.first, kv.second);
            // Per-level class overrides use explicit prefixes so grass, foliage and light rays
            // can be tuned independently without changing the global [wind_*] defaults.
            const char *classes[] = {"foliage_", "grass_", "lightray_"};
            Class *values[] = {&s.foliage, &s.grass, &s.lightray};
            bool matched = false;
            for (int i = 0; i < 3; ++i) {
                const size_t n = strlen(classes[i]);
                if (kv.first.compare(0, n, classes[i]) == 0) {
                    apply_class(*values[i], kv.first.substr(n), kv.second);
                    matched = true;
                    break;
                }
            }
            // Keep the original unprefixed per-level fields compatible (main wind + foliage).
            if (!matched) apply_class(s.foliage, kv.first, kv.second);
        }
        g_level.push_back({level, s});
    }
    g_s = g_default;
    logf("[wind] wind.ini loaded: %s, follow_rain %d, strength %.2f m, %zu level override(s)", g_default.enabled ? "on" : "off", (int)g_default.follow_rain,
         g_default.strength, g_level.size());
}

void reload_if_changed()
{
    const DWORD now = GetTickCount();
    if (g_loaded && now - g_last < 1000) return;
    g_last = now;
    WIN32_FILE_ATTRIBUTE_DATA a{};
    if (!GetFileAttributesExW(ini_path().c_str(), GetFileExInfoStandard, &a)) {
        if (!g_loaded) load(); // writes the default file
        g_loaded = true;
        return;
    }
    if (g_loaded && !CompareFileTime(&g_stamp, &a.ftLastWriteTime)) return;
    g_stamp = a.ftLastWriteTime;
    g_loaded = true;
    load();
}

const Settings &for_level(int level)
{
    for (auto &p : g_level) if (p.first == level) return p.second;
    return g_default;
}

// smooth slow noise from a few sines (no state, cheap)
float slow_noise(float t) { return 0.5f * sinf(t * 1.00f) + 0.3f * sinf(t * 2.37f + 1.7f) + 0.2f * sinf(t * 5.11f + 0.4f); }

struct FrameK { uint32_t frame = 0xFFFFFFFF; bool on = false; float a[4], b[4], c[4], d[4]; float cls_strength[3]; Class cls[4]; };
FrameK g_fk;

void update_frame()
{
    reload_if_changed();
    const uint32_t f = g_frame_count.load();
    if (f == g_fk.frame) return;
    g_fk.frame = f;
    static bool key_prev = false;
    const bool key = (GetAsyncKeyState(VK_F10) & 0x8000) != 0;
    if (key && !key_prev) toggle();
    key_prev = key;
    g_fk.on = false;
    const int level = g_current_level.load();
    const Settings &s = for_level(level);
    if (!g_user_on || !s.enabled || level < 0) return;
    if (!s.levels.empty() && std::find(s.levels.begin(), s.levels.end(), level) == s.levels.end()) return;

    static LARGE_INTEGER freq{}, t0{};
    if (!freq.QuadPart) { QueryPerformanceFrequency(&freq); QueryPerformanceCounter(&t0); }
    LARGE_INTEGER now; QueryPerformanceCounter(&now);
    const double sec = (double)(now.QuadPart - t0.QuadPart) / (double)freq.QuadPart;
    const float t = (float)fmod(sec, 3600.0);

    float dx, dz, base_speed = s.speed;
    float deg = s.direction;
    if (s.follow_rain) {
        float w[2];
        if (rain::wind_xz(w)) {
            const float len = sqrtf(w[0] * w[0] + w[1] * w[1]);
            if (len > 0.01f) {
                deg = atan2f(w[0], w[1]) * 57.2957795f;                    // 0 = +Z, 90 = +X
                base_speed = std::max(s.speed * 0.5f, len * 1.3f);       // stronger rain wind -> faster fronts
            }
        }
    }
    deg += s.drift * slow_noise(t * s.drift_speed * 6.2831853f);
    const float rad = deg * 0.0174532925f;
    dx = sinf(rad); dz = cosf(rad);

    const float gust_mul = std::max(0.0f, 1.0f + s.gust * slow_noise(t * s.gust_speed * 6.2831853f));
    g_fk.a[0] = t; g_fk.a[1] = dx; g_fk.a[2] = dz; g_fk.a[3] = 1.0f;
    g_fk.b[0] = base_speed; g_fk.b[1] = s.wavelength; g_fk.b[2] = s.strength * gust_mul; g_fk.b[3] = 0.0f;
    g_fk.c[0] = s.flutter; g_fk.c[1] = s.flutter_speed * 6.2831853f; g_fk.c[2] = s.droop; g_fk.c[3] = 0.0f;
    g_fk.d[0] = 0.0f; g_fk.d[1] = s.variation; g_fk.d[2] = g_fk.d[3] = 0.0f;
    g_fk.cls[1] = s.foliage;
    g_fk.cls[2] = s.lightray;
    g_fk.cls[3] = s.grass;
    g_fk.on = s.strength > 0.0f;
}

} // namespace

CompileOpts compile_opts() { reload_if_changed(); return g_co; }

void toggle() { g_user_on = !g_user_on; logf("[wind] %s", g_user_on ? "on" : "off"); }

int forced_class(uint32_t hash)
{
    reload_if_changed();
    if (std::find(g_ignore.begin(), g_ignore.end(), hash) != g_ignore.end()) return -1;
    if (std::find(g_force_lightray.begin(), g_force_lightray.end(), hash) != g_force_lightray.end()) return 2;
    if (std::find(g_force_grass.begin(), g_force_grass.end(), hash) != g_force_grass.end()) return 3;
    const Settings &s = for_level(g_current_level.load());
    const auto &foliage = s.foliage_hashes_override ? s.forced_foliage : g_force_foliage;
    if (std::find(foliage.begin(), foliage.end(), hash) != foliage.end()) return 1;
    return 0;
}

bool draw_constants(bool alpha_test, bool alpha_blend, bool first_person, int forced, int *cls_out, float k[20])
{
    if (cls_out) *cls_out = 0;
    if (first_person || forced < 0) return false;
    update_frame();
    int cls = forced > 0 ? forced : (alpha_test ? 1 : 0);
    if (!cls && alpha_blend && for_level(g_current_level.load()).lightray_blend) cls = 2;
    if (!cls) return false;
    if (cls_out) *cls_out = cls; // density works even when the wind is off
    if (!g_fk.on) return false;
    const Class &c = g_fk.cls[cls];
    if (!c.enabled || c.strength <= 0.0f) return false;
    memcpy(k, g_fk.a, 16);
    memcpy(k + 4, g_fk.b, 16);
    memcpy(k + 8, g_fk.c, 16);
    memcpy(k + 12, g_fk.d, 16);
    k[3] = 1.0f;                       // gate
    k[6] *= c.strength;                // strength in metres for this class
    k[7] = c.phase;
    k[11] = (float)c.weight;
    k[12] = c.bend;
    k[16] = k[17] = k[18] = k[19] = 0.0f;
    return true;
}

int snap_budget() { return g_snap_budget; }
int copy_cap() { return g_copy_cap; }
int copies(int cls) { return cls >= 1 && cls <= 3 ? g_dens[cls].n : 1; }

void offset(int cls, int copy, uint32_t h, float out[4])
{
    const Dens &d = g_dens[cls >= 1 && cls <= 3 ? cls : 1];
    const float a = (float)(h % 1000u) / 1000.0f * 6.2831853f + (float)copy * 2.3999632f;
    const float r = d.spread * (0.45f + 0.55f * (float)((h >> 10) % 1000u) / 1000.0f) * (0.6f + 0.4f * (float)copy / (float)std::max(1, d.n - 1));
    out[0] = cosf(a) * r; out[1] = 0.0f; out[2] = sinf(a) * r; out[3] = 0.0f;
}

void grass_sway_constants(IDirect3DDevice9 *d, const float *all)
{
    for (auto &p : g_grass.sway) {
        float v[4];
        for (int i = 0; i < 4; i++) v[i] = all[p.first * 4 + i] * p.second;
        d->SetVertexShaderConstantF(p.first, v, 1);
    }
}


namespace {
struct Tri { float v[9]; float inv_d; };
constexpr float kCell = 4.0f;
std::unordered_map<uint64_t, std::vector<Tri>> g_gcells;
std::unordered_set<uint64_t> g_gdraws;
const std::vector<Tri> *g_last_cell = nullptr; // last cell found by ground_height (neighbouring vertices hit the same 4 m cell)
uint64_t g_last_key = 0;
int g_glevel = -2;
size_t g_gtris = 0;
uint64_t cell_key(int cx, int cz) { return ((uint64_t)(uint32_t)cx << 32) | (uint32_t)cz; }
void ground_level_check()
{
    const int lv = g_current_level.load();
    if (lv != g_glevel) { g_glevel = lv; g_gcells.clear(); g_gdraws.clear(); g_gtris = 0; g_last_cell = nullptr; }
}
}

bool is_ground(uint32_t hash)
{
    reload_if_changed();
    return std::find(g_ground_shaders.begin(), g_ground_shaders.end(), hash) != g_ground_shaders.end();
}

bool ground_wanted()
{
    if (!g_snap || g_ground_shaders.empty()) return false;
    return g_dens[1].n > 1 || g_dens[2].n > 1 || g_dens[3].n > 1;
}

bool ground_seen_draw(uint64_t sig)
{
    ground_level_check();
    return !g_gdraws.insert(sig).second;
}

void ground_add_tri(const float *a, const float *b, const float *c)
{
    if (g_gtris > 3000000) return;
    const float e1x = b[0] - a[0], e1y = b[1] - a[1], e1z = b[2] - a[2], e2x = c[0] - a[0], e2y = c[1] - a[1], e2z = c[2] - a[2];
    const float nx = e1y * e2z - e1z * e2y, ny = e1z * e2x - e1x * e2z, nz = e1x * e2y - e1y * e2x;
    const float len = sqrtf(nx * nx + ny * ny + nz * nz);
    if (len < 1e-8f || fabsf(ny) < 0.2f * len) return; // walls and slivers are not ground
    const float minx = std::min({a[0], b[0], c[0]}), maxx = std::max({a[0], b[0], c[0]});
    const float minz = std::min({a[2], b[2], c[2]}), maxz = std::max({a[2], b[2], c[2]});
    if (!(maxx - minx < 400.f) || !(maxz - minz < 400.f)) return;
    const int x0 = (int)floorf(minx / kCell), x1 = (int)floorf(maxx / kCell), z0 = (int)floorf(minz / kCell), z1 = (int)floorf(maxz / kCell);
    if ((x1 - x0 + 1) * (z1 - z0 + 1) > 64) return;
    Tri t;
    {
        const float d = (b[2] - c[2]) * (a[0] - c[0]) + (c[0] - b[0]) * (a[2] - c[2]);
        if (fabsf(d) < 1e-9f) return;
        t.inv_d = 1.0f / d;
    }
    memcpy(t.v, a, 12); memcpy(t.v + 3, b, 12); memcpy(t.v + 6, c, 12);
    for (int cz = z0; cz <= z1; cz++)
        for (int cx = x0; cx <= x1; cx++) g_gcells[cell_key(cx, cz)].push_back(t);
    g_gtris++;
}

bool ground_height(float x, float z, float yref, float *out)
{
    const uint64_t key = cell_key((int)floorf(x / kCell), (int)floorf(z / kCell));
    if (!g_last_cell || key != g_last_key) {
        const auto it = g_gcells.find(key);
        if (it == g_gcells.end()) return false;
        g_last_cell = &it->second; // element pointers stay valid while cells are added; reset on level change
        g_last_key = key;
    }
    bool found = false;
    float best = 1e30f;
    for (const Tri &t : *g_last_cell) {
        const float *a = t.v, *b = t.v + 3, *c = t.v + 6;
        const float l1 = ((b[2] - c[2]) * (x - c[0]) + (c[0] - b[0]) * (z - c[2])) * t.inv_d;
        if (l1 < -0.001f) continue;
        const float l2 = ((c[2] - a[2]) * (x - c[0]) + (a[0] - c[0]) * (z - c[2])) * t.inv_d;
        if (l2 < -0.001f) continue;
        const float l3 = 1.0f - l1 - l2;
        if (l3 < -0.001f) continue;
        const float y = l1 * a[1] + l2 * b[1] + l3 * c[1];
        const float dist = fabsf(y - yref);
        if (dist < best) { best = dist; *out = y; found = true; }
    }
    return found;
}

namespace {
struct ScanRow { uint32_t insts = 0, draws = 0, at = 0, ab = 0; int cls = 0; bool code = false; };
std::map<uint32_t, ScanRow> g_scan;
uint32_t g_scan_end = 0;
bool g_scan_on = false;
std::vector<uint32_t> g_blink_list;
int g_blink = -1;
uint32_t g_scan_overlay_until = 0;
}

bool blink_hides(uint32_t hash)
{
    return g_blink >= 0 && g_blink < (int)g_blink_list.size() && g_blink_list[g_blink] == hash && ((GetTickCount() / 400) & 1);
}

void scan_note(uint32_t hash, uint32_t insts, int cls, bool at, bool ab, bool code)
{
    static bool key_prev = false;
    const uint32_t f = g_frame_count.load();
    static uint32_t last = 0xFFFFFFFF;
    if (f != last) {
        last = f;
        const bool key = (GetAsyncKeyState(VK_F11) & 0x8000) != 0;
        if (key && !key_prev && !g_scan_on) { g_scan_on = true; g_scan.clear(); g_scan_end = f + 120; g_scan_overlay_until = GetTickCount() + 15000; logf("[wind-scan] collecting shaders for 2 seconds ..."); }
        key_prev = key;
        static bool k12_prev = false;
        const bool k12 = (GetAsyncKeyState(VK_F12) & 0x8000) != 0;
        if (k12 && !k12_prev) {
            g_scan_overlay_until = GetTickCount() + 12000;
            if (g_blink_list.empty()) logf("[wind-scan] press F11 first (it makes the list F12 walks through)");
            else {
                g_blink++;
                if (g_blink >= (int)g_blink_list.size()) { g_blink = -1; logf("[wind-scan] blink off"); }
                else logf("[wind-scan] BLINK %d/%zu: shader %08X is hidden every other 0.4 s - whatever blinks on screen is drawn by it", g_blink + 1, g_blink_list.size(), g_blink_list[g_blink]);
            }
        }
        k12_prev = k12;
        if (g_scan_on && f >= g_scan_end) {
            g_scan_on = false;
            std::vector<std::pair<uint32_t, ScanRow>> rows(g_scan.begin(), g_scan.end());
            std::sort(rows.begin(), rows.end(), [](auto &x, auto &y) { return x.second.draws > y.second.draws; });
            g_blink_list.clear(); g_blink = -1;
            for (auto &r : rows) g_blink_list.push_back(r.first);
            g_scan_overlay_until = GetTickCount() + 15000;
            logf("[wind-scan] done: F12 walks through the list one shader at a time (that shader blinks on screen), press it until the grass blinks");
            logf("[wind-scan] %zu shaders drew (most draws first); 'at' = draws with alpha test, 'ab' = with alpha blend", rows.size());
            for (size_t i = 0; i < rows.size() && i < 60; i++)
                logf("[wind-scan] draws shader %08X: %u instructions, %u draws, at %u, ab %u, wind class %d (1 tree/foliage, 2 light ray, 3 grass), wind code %d", rows[i].first, rows[i].second.insts,
                     rows[i].second.draws, rows[i].second.at, rows[i].second.ab, rows[i].second.cls, (int)rows[i].second.code);
        }
    }
    if (!g_scan_on) return;
    ScanRow &r = g_scan[hash];
    r.insts = insts; r.draws++; r.at += at; r.ab += ab; if (cls) r.cls = cls; r.code = code;
}

bool scan_overlay_text(std::vector<std::string> &lines)
{
    if (!g_scan_on && g_blink < 0 && (int32_t)(g_scan_overlay_until - GetTickCount()) <= 0) return false;
    char line[192];
    if (g_scan_on) {
        const uint32_t elapsed = 120 - std::min<uint32_t>(120, g_scan_end - g_frame_count.load());
        sprintf_s(line, "F11 SHADER SCAN  |  %u%%", elapsed * 100 / 120);
        lines.emplace_back(line);
        sprintf_s(line, "Collected %zu shader IDs so far", g_scan.size());
        lines.emplace_back(line);
        lines.emplace_back("Wait for the scan to finish, then press F12 to select and blink an ID");
        return true;
    }
    if (g_blink >= 0 && g_blink < (int)g_blink_list.size()) {
        const uint32_t id = g_blink_list[g_blink];
        const auto it = g_scan.find(id);
        const ScanRow row = it == g_scan.end() ? ScanRow{} : it->second;
        sprintf_s(line, "SHADER / MATERIAL ID: %08X  (%d/%zu)", id, g_blink + 1, g_blink_list.size());
        lines.emplace_back(line);
        sprintf_s(line, "Draws %u  |  Instructions %u  |  Alpha test %u  |  Alpha blend %u", row.draws, row.insts, row.at, row.ab);
        lines.emplace_back(line);
        lines.emplace_back("F12 next ID; selected shader continues blinking until you step past the list");
    } else {
        sprintf_s(line, "Scan complete: %zu shader IDs  |  Press F12 to display and blink each ID", g_blink_list.size());
        lines.emplace_back(line);
    }
    return true;
}

bool scan_overlay_active()
{
    return g_scan_on || g_blink >= 0 || (int32_t)(g_scan_overlay_until - GetTickCount()) > 0;
}

} // namespace wind
