#include "ads_tweak.h"

#include <commctrl.h>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <cwchar>

namespace {
constexpr int kSliderFirst = 101, kValueFirst = 121, kZoomSlider = 117, kAdsTimeSlider = 118, kZoomTimeSlider = 119;
constexpr int kZoomValue = 127, kAdsTimeValue = 128, kZoomTimeValue = 129;
constexpr int kJointList = 110, kReset = 112, kSave = 113, kStatus = 114, kMoveAll = 115, kGlobalRotation = 116;
AdsTweakShared *g_shared;
int g_joint;
HWND g_sliders[6], g_labels[6], g_values[6], g_joint_label, g_joint_list, g_status, g_weapon_label;
HWND g_zoom_slider, g_zoom_value, g_ads_time_slider, g_ads_time_value, g_zoom_time_slider, g_zoom_time_value;
HWND g_game_window;
DWORD g_target_pid;
bool g_waiting_save;
bool g_move_all, g_global_rotation;
const wchar_t *kComponent[] = {L"X", L"Y", L"Z", L"Rot X", L"Rot Y", L"Rot Z"};

void read_pose(float out[kAdsJointCount][6])
{
    LONG first, last;
    for (;;) {
        first = InterlockedCompareExchange(&g_shared->sequence, 0, 0);
        if (first & 1) { YieldProcessor(); continue; }
        memcpy(out, g_shared->offsets, sizeof g_shared->offsets);
        MemoryBarrier();
        last = InterlockedCompareExchange(&g_shared->sequence, 0, 0);
        if (first == last && !(last & 1)) break;
    }
}

void write_pose(const float pose[kAdsJointCount][6])
{
    float copy[kAdsJointCount][6];
    memcpy(copy, pose, sizeof copy);
    if (g_move_all)
        for (int j = 0; j < kAdsJointCount; ++j)
            if (j != g_joint) memcpy(copy[j], copy[g_joint], sizeof copy[j]);
    InterlockedIncrement(&g_shared->sequence);
    MemoryBarrier();
    memcpy(g_shared->offsets, copy, sizeof g_shared->offsets);
    MemoryBarrier();
    InterlockedIncrement(&g_shared->sequence);
}

void refresh_controls()
{
    float pose[kAdsJointCount][6];
    read_pose(pose);
    wchar_t title[80];
    swprintf_s(title, L"Joint %d of %d   (skin constants c%d-c%d)", g_joint, kAdsJointCount - 1, 60 + g_joint * 3,
               62 + g_joint * 3);
    if (g_global_rotation) {
        wchar_t suffix[48];
        swprintf_s(suffix, L"   (global pivot)");
        wcscat_s(title, suffix);
    }
    SetWindowTextW(g_joint_label, title);
    for (int a = 0; a < 6; ++a) {
        const int value = a < 3 ? (int)lroundf(pose[g_joint][a] * 100.0f) : (int)lroundf(pose[g_joint][a]);
        SendMessageW(g_sliders[a], TBM_SETPOS, TRUE, value);
        wchar_t label[64], value_text[32];
        swprintf_s(label, L"%s", kComponent[a]);
        if (a < 3) swprintf_s(value_text, L"%.4f", pose[g_joint][a]);
        else swprintf_s(value_text, L"%.2f", pose[g_joint][a]);
        SetWindowTextW(g_labels[a], label);
        SetWindowTextW(g_values[a], value_text);
    }
    int zoom = std::clamp((int)InterlockedCompareExchange(&g_shared->weapon_zoom_milli, 1000, 0), 1000, 4000);
    SendMessageW(g_zoom_slider, TBM_SETPOS, TRUE, zoom / 10);
    wchar_t zoom_text[32];
    swprintf_s(zoom_text, L"%.3fx", zoom * 0.001f);
    SetWindowTextW(g_zoom_value, zoom_text);
    int ads_ms = std::clamp((int)InterlockedCompareExchange(&g_shared->ads_transition_ms, 220, 0), 50, 1000);
    SendMessageW(g_ads_time_slider, TBM_SETPOS, TRUE, ads_ms);
    wchar_t time_text[32];
    swprintf_s(time_text, L"%d ms", ads_ms);
    SetWindowTextW(g_ads_time_value, time_text);
    int zoom_ms = std::clamp((int)InterlockedCompareExchange(&g_shared->zoom_transition_ms, 220, 0), 50, 1000);
    SendMessageW(g_zoom_time_slider, TBM_SETPOS, TRUE, zoom_ms);
    swprintf_s(time_text, L"%d ms", zoom_ms);
    SetWindowTextW(g_zoom_time_value, time_text);
}

void commit_zoom()
{
    wchar_t text[64] = {};
    GetWindowTextW(g_zoom_value, text, (int)_countof(text));
    wchar_t *end = nullptr;
    double parsed = wcstod(text, &end);
    while (end && (*end == L' ' || *end == L'\t' || *end == L'x' || *end == L'X')) ++end;
    if (end == text || !end || *end || !std::isfinite(parsed)) {
        refresh_controls();
        return;
    }
    int zoom = (int)lround(std::clamp(parsed, 1.0, 4.0) * 1000.0);
    InterlockedExchange(&g_shared->weapon_zoom_milli, zoom);
    refresh_controls();
}

void commit_transition(HWND value_control, volatile LONG *shared_value)
{
    wchar_t text[64] = {};
    GetWindowTextW(value_control, text, (int)_countof(text));
    wchar_t *end = nullptr;
    double parsed = wcstod(text, &end);
    while (end && (*end == L' ' || *end == L'\t')) ++end;
    if (end && (*end == L'm' || *end == L'M')) {
        ++end;
        if (*end == L's' || *end == L'S') ++end;
    }
    while (end && (*end == L' ' || *end == L'\t')) ++end;
    if (end == text || !end || *end || !std::isfinite(parsed)) {
        refresh_controls();
        return;
    }
    InterlockedExchange(shared_value, (LONG)lround(std::clamp(parsed, 50.0, 1000.0)));
    refresh_controls();
}

void commit_value(int axis)
{
    wchar_t text[64] = {};
    GetWindowTextW(g_values[axis], text, (int)_countof(text));
    wchar_t *end = nullptr;
    double parsed = wcstod(text, &end);
    while (end && (*end == L' ' || *end == L'\t')) ++end;
    if (end == text || !end || *end || !std::isfinite(parsed)) {
        refresh_controls();
        return;
    }
    float pose[kAdsJointCount][6];
    read_pose(pose);
    const float low = axis < 3 ? -5.0f : -180.0f;
    const float high = axis < 3 ? 5.0f : 180.0f;
    pose[g_joint][axis] = std::clamp((float)parsed, low, high);
    write_pose(pose);
    refresh_controls();
}

void find_game_window()
{
    if (g_game_window && IsWindow(g_game_window)) return;
    g_game_window = nullptr;
    EnumWindows([](HWND candidate, LPARAM target_pid) -> BOOL {
        DWORD owner = 0;
        GetWindowThreadProcessId(candidate, &owner);
        if (owner != (DWORD)target_pid) return TRUE;
        wchar_t cls[64]{};
        if (GetClassNameW(candidate, cls, 64) && wcscmp(cls, L"BlackLoaderWindow") == 0) {
            g_game_window = candidate;
            return FALSE;
        }
        return TRUE;
    }, (LPARAM)g_target_pid);
}

LRESULT CALLBACK wndproc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp)
{
    switch (msg) {
    case WM_CREATE: {
        g_joint = std::clamp((int)InterlockedCompareExchange(&g_shared->pivot_joint, 0, 0), 0, kAdsJointCount - 1);
        g_weapon_label = CreateWindowW(L"STATIC", L"Weapon ID: default", WS_CHILD | WS_VISIBLE, 14, 8, 150, 22, hwnd,
                                       nullptr, nullptr, nullptr);
        CreateWindowW(L"STATIC", L"Tap Aim to toggle ADS; edit a value or use its slider.", WS_CHILD | WS_VISIBLE,
                      166, 8, 280, 22, hwnd, nullptr, nullptr, nullptr);
        g_joint_list = CreateWindowW(L"LISTBOX", nullptr,
                                    WS_CHILD | WS_VISIBLE | WS_TABSTOP | WS_VSCROLL | LBS_NOTIFY | LBS_MULTICOLUMN |
                                        LBS_NOINTEGRALHEIGHT,
                                    14, 32, 430, 170, hwnd, (HMENU)kJointList, nullptr, nullptr);
        SendMessageW(g_joint_list, LB_SETITEMHEIGHT, 0, 22);
        SendMessageW(g_joint_list, LB_SETCOLUMNWIDTH, 105, 0);
        for (int j = 0; j < kAdsJointCount; ++j) {
            wchar_t item[48];
            swprintf_s(item, L"J%d  c%d-%d", j, 60 + j * 3, 62 + j * 3);
            SendMessageW(g_joint_list, LB_ADDSTRING, 0, (LPARAM)item);
        }
        SendMessageW(g_joint_list, LB_SETCURSEL, 0, 0);
        g_joint_label = CreateWindowW(L"STATIC", L"Joint 0 of 43", WS_CHILD | WS_VISIBLE, 14, 210, 255, 22, hwnd,
                                      nullptr, nullptr, nullptr);
        HWND global_rotation = CreateWindowW(L"BUTTON", L"Global rotation around selected joint", WS_CHILD | WS_VISIBLE |
                                                 WS_TABSTOP | BS_AUTOCHECKBOX,
                                             14, 234, 260, 28, hwnd, (HMENU)kGlobalRotation, nullptr, nullptr);
        g_global_rotation = InterlockedCompareExchange(&g_shared->global_rotation, 0, 0) != 0;
        SendMessageW(global_rotation, BM_SETCHECK, g_global_rotation ? BST_CHECKED : BST_UNCHECKED, 0);
        HWND move_all = CreateWindowW(L"BUTTON", L"Move all joints", WS_CHILD | WS_VISIBLE | WS_TABSTOP | BS_AUTOCHECKBOX,
                                      275, 234, 160, 28, hwnd, (HMENU)kMoveAll, nullptr, nullptr);
        g_move_all = InterlockedCompareExchange(&g_shared->move_all, 0, 0) != 0;
        SendMessageW(move_all, BM_SETCHECK, g_move_all ? BST_CHECKED : BST_UNCHECKED, 0);
        {
            int weapon = InterlockedCompareExchange(&g_shared->weapon_id, 0, 0);
            wchar_t label[64];
            if (weapon >= 0) swprintf_s(label, L"Weapon ID: %d", weapon);
            else wcscpy_s(label, L"Weapon ID: default");
            SetWindowTextW(g_weapon_label, label);
        }
        CreateWindowW(L"STATIC", L"WEAPON ZOOM   (Modern ADS, per weapon)", WS_CHILD | WS_VISIBLE,
                      14, 266, 420, 18, hwnd, nullptr, nullptr, nullptr);
        g_zoom_slider = CreateWindowExW(0, TRACKBAR_CLASSW, nullptr,
                                        WS_CHILD | WS_VISIBLE | WS_TABSTOP | TBS_AUTOTICKS,
                                        92, 284, 238, 26, hwnd, (HMENU)kZoomSlider, nullptr, nullptr);
        g_zoom_value = CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", L"1.000x",
                                       WS_CHILD | WS_VISIBLE | WS_TABSTOP | ES_AUTOHSCROLL,
                                       340, 284, 88, 26, hwnd, (HMENU)kZoomValue, nullptr, nullptr);
        SendMessageW(g_zoom_slider, TBM_SETRANGE, TRUE, MAKELONG(100, 400));
        SendMessageW(g_zoom_slider, TBM_SETTICFREQ, 25, 0);
        CreateWindowW(L"STATIC", L"ADS speed (transition time)", WS_CHILD | WS_VISIBLE,
                      14, 316, 420, 18, hwnd, nullptr, nullptr, nullptr);
        g_ads_time_slider = CreateWindowExW(0, TRACKBAR_CLASSW, nullptr, WS_CHILD | WS_VISIBLE | WS_TABSTOP | TBS_AUTOTICKS,
                                            92, 334, 238, 26, hwnd, (HMENU)kAdsTimeSlider, nullptr, nullptr);
        g_ads_time_value = CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", L"220 ms", WS_CHILD | WS_VISIBLE | WS_TABSTOP | ES_AUTOHSCROLL,
                                           340, 334, 88, 26, hwnd, (HMENU)kAdsTimeValue, nullptr, nullptr);
        SendMessageW(g_ads_time_slider, TBM_SETRANGE, TRUE, MAKELONG(50, 1000));
        SendMessageW(g_ads_time_slider, TBM_SETTICFREQ, 100, 0);
        CreateWindowW(L"STATIC", L"ZOOM transition time", WS_CHILD | WS_VISIBLE,
                      14, 366, 420, 18, hwnd, nullptr, nullptr, nullptr);
        g_zoom_time_slider = CreateWindowExW(0, TRACKBAR_CLASSW, nullptr, WS_CHILD | WS_VISIBLE | WS_TABSTOP | TBS_AUTOTICKS,
                                             92, 384, 238, 26, hwnd, (HMENU)kZoomTimeSlider, nullptr, nullptr);
        g_zoom_time_value = CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", L"220 ms", WS_CHILD | WS_VISIBLE | WS_TABSTOP | ES_AUTOHSCROLL,
                                            340, 384, 88, 26, hwnd, (HMENU)kZoomTimeValue, nullptr, nullptr);
        SendMessageW(g_zoom_time_slider, TBM_SETRANGE, TRUE, MAKELONG(50, 1000));
        SendMessageW(g_zoom_time_slider, TBM_SETTICFREQ, 100, 0);
        CreateWindowW(L"STATIC", L"POSITION   (0.01 game units per step)", WS_CHILD | WS_VISIBLE,
                      14, 416, 420, 18, hwnd, nullptr, nullptr, nullptr);
        CreateWindowW(L"STATIC", L"ROTATION   (degrees)", WS_CHILD | WS_VISIBLE,
                      14, 520, 420, 18, hwnd, nullptr, nullptr, nullptr);
        for (int a = 0; a < 6; ++a) {
            const int y = a < 3 ? 436 + a * 26 : 540 + (a - 3) * 26;
            const int id = kSliderFirst + a;
            g_labels[a] = CreateWindowW(L"STATIC", kComponent[a], WS_CHILD | WS_VISIBLE,
                                        14, y + 8, 78, 22, hwnd, nullptr, nullptr, nullptr);
            g_sliders[a] = CreateWindowExW(0, TRACKBAR_CLASSW, nullptr,
                                           WS_CHILD | WS_VISIBLE | WS_TABSTOP | TBS_AUTOTICKS,
                                           92, y, 238, 26, hwnd, (HMENU)id, nullptr, nullptr);
            g_values[a] = CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", L"0.0000",
                                          WS_CHILD | WS_VISIBLE | WS_TABSTOP | ES_AUTOHSCROLL,
                                          340, y, 88, 26, hwnd, (HMENU)(kValueFirst + a), nullptr, nullptr);
            SendMessageW(g_sliders[a], TBM_SETRANGE, TRUE, MAKELONG(a < 3 ? -200 : -180, a < 3 ? 200 : 180));
            SendMessageW(g_sliders[a], TBM_SETTICFREQ, a < 3 ? 50 : 45, 0);
        }
        CreateWindowW(L"BUTTON", L"Reset joint", WS_CHILD | WS_VISIBLE | WS_TABSTOP | BS_PUSHBUTTON,
                      14, 620, 150, 42, hwnd, (HMENU)kReset, nullptr, nullptr);
        CreateWindowW(L"BUTTON", L"Save ADS pose", WS_CHILD | WS_VISIBLE | WS_TABSTOP | BS_DEFPUSHBUTTON,
                      278, 620, 150, 42, hwnd, (HMENU)kSave, nullptr, nullptr);
        g_status = CreateWindowW(L"STATIC", L"Waiting for gameplay Aim trigger", WS_CHILD | WS_VISIBLE,
                                 14, 670, 430, 24, hwnd, (HMENU)kStatus, nullptr, nullptr);
        refresh_controls();
        SetTimer(hwnd, 1, 40, nullptr);
        return 0;
    }
    case WM_MOUSEACTIVATE: return MA_ACTIVATE; // numeric fields need keyboard focus for precise entry
    case WM_TIMER:
        {
            int weapon = InterlockedCompareExchange(&g_shared->weapon_id, 0, 0);
            static int last_weapon = -3;
            if (weapon != last_weapon) {
                last_weapon = weapon;
                wchar_t label[64];
                if (weapon >= 0) swprintf_s(label, L"Weapon ID: %d", weapon);
                else wcscpy_s(label, L"Weapon ID: default");
                SetWindowTextW(g_weapon_label, label);
                refresh_controls();
            }
        }
        find_game_window();
        if (g_game_window) {
            RECT client{};
            GetClientRect(g_game_window, &client);
            POINT p = {client.left, client.top};
            ClientToScreen(g_game_window, &p);
            SetWindowPos(hwnd, HWND_TOPMOST, p.x + 12, p.y + 12, 0, 0,
                         SWP_NOSIZE | SWP_NOACTIVATE | SWP_SHOWWINDOW);
        }
        {
            POINT cursor{};
            HWND hit = GetCursorPos(&cursor) ? WindowFromPoint(cursor) : nullptr;
            bool over_editor = hit && (hit == hwnd || GetAncestor(hit, GA_ROOT) == hwnd);
            InterlockedExchange(&g_shared->editor_hover, over_editor ? 1 : 0);
        }
        if (g_waiting_save) {
            if (InterlockedCompareExchange(&g_shared->save_requested, 0, 0) == 0) {
                SetWindowTextW(g_status, L"Pose saved to black.ini");
                g_waiting_save = false;
            } else SetWindowTextW(g_status, L"Saving pose to black.ini...");
        } else {
            SetWindowTextW(g_status, InterlockedCompareExchange(&g_shared->aim_active, 0, 0)
                                         ? L"ADS on: configured FOV and joint pose are active"
                                         : L"ADS off: tap the mapped Aim trigger during gameplay");
        }
        return 0;
    case WM_COMMAND:
        if (LOWORD(wp) == kZoomValue && HIWORD(wp) == EN_KILLFOCUS) {
            commit_zoom();
            return 0;
        }
        if (LOWORD(wp) == kAdsTimeValue && HIWORD(wp) == EN_KILLFOCUS) {
            commit_transition(g_ads_time_value, &g_shared->ads_transition_ms);
            return 0;
        }
        if (LOWORD(wp) == kZoomTimeValue && HIWORD(wp) == EN_KILLFOCUS) {
            commit_transition(g_zoom_time_value, &g_shared->zoom_transition_ms);
            return 0;
        }
        if (HIWORD(wp) == EN_KILLFOCUS && LOWORD(wp) >= kValueFirst && LOWORD(wp) < kValueFirst + 6) {
            commit_value(LOWORD(wp) - kValueFirst);
            return 0;
        }
        if (LOWORD(wp) == kJointList && HIWORD(wp) == LBN_SELCHANGE) {
            int selected = (int)SendMessageW(g_joint_list, LB_GETCURSEL, 0, 0);
            if (selected >= 0 && selected < kAdsJointCount) {
                g_joint = selected;
                InterlockedExchange(&g_shared->pivot_joint, g_joint);
            }
            refresh_controls();
            return 0;
        }
        if (LOWORD(wp) == kGlobalRotation && HIWORD(wp) == BN_CLICKED) {
            g_global_rotation = SendMessageW((HWND)lp, BM_GETCHECK, 0, 0) == BST_CHECKED;
            InterlockedExchange(&g_shared->global_rotation, g_global_rotation ? 1 : 0);
            InterlockedExchange(&g_shared->pivot_joint, g_joint);
            refresh_controls();
            return 0;
        }
        if (LOWORD(wp) == kMoveAll && HIWORD(wp) == BN_CLICKED) {
            g_move_all = SendMessageW((HWND)lp, BM_GETCHECK, 0, 0) == BST_CHECKED;
            InterlockedExchange(&g_shared->move_all, g_move_all ? 1 : 0);
            if (g_move_all) {
                float pose[kAdsJointCount][6];
                read_pose(pose);
                write_pose(pose); // immediately copy the selected pose to all joints
            }
            refresh_controls();
            return 0;
        }
        if (LOWORD(wp) == kReset) {
            float pose[kAdsJointCount][6];
            read_pose(pose);
            for (int a = 0; a < 6; ++a) pose[g_joint][a] = 0.0f;
            write_pose(pose);
            refresh_controls();
            return 0;
        }
        if (LOWORD(wp) == kSave) {
            InterlockedExchange(&g_shared->save_requested, 1);
            g_waiting_save = true;
            SetWindowTextW(g_status, L"Saving pose to black.ini...");
            return 0;
        }
        break;
    case WM_HSCROLL: {
        HWND slider = (HWND)lp;
        if (slider == g_zoom_slider) {
            int zoom = (int)SendMessageW(g_zoom_slider, TBM_GETPOS, 0, 0) * 10;
            InterlockedExchange(&g_shared->weapon_zoom_milli, zoom);
            refresh_controls();
            return 0;
        }
        if (slider == g_ads_time_slider) {
            InterlockedExchange(&g_shared->ads_transition_ms, (LONG)SendMessageW(slider, TBM_GETPOS, 0, 0));
            refresh_controls();
            return 0;
        }
        if (slider == g_zoom_time_slider) {
            InterlockedExchange(&g_shared->zoom_transition_ms, (LONG)SendMessageW(slider, TBM_GETPOS, 0, 0));
            refresh_controls();
            return 0;
        }
        int axis = (int)GetDlgCtrlID(slider) - kSliderFirst;
        if (axis >= 0 && axis < 6) {
            float pose[kAdsJointCount][6];
            read_pose(pose);
            const int value = (int)SendMessageW(slider, TBM_GETPOS, 0, 0);
            pose[g_joint][axis] = axis < 3 ? value * 0.01f : (float)value;
            write_pose(pose);
            refresh_controls();
            return 0;
        }
        break;
    }
    case WM_CLOSE: DestroyWindow(hwnd); return 0;
    case WM_DESTROY:
        InterlockedExchange(&g_shared->editor_hover, 0);
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProcW(hwnd, msg, wp, lp);
}
} // namespace

int WINAPI wWinMain(HINSTANCE instance, HINSTANCE, PWSTR command_line, int)
{
    SetProcessDPIAware();
    wchar_t *end = nullptr;
    unsigned long pid = wcstoul(command_line, &end, 10);
    if (!pid || end == command_line) {
        MessageBoxW(nullptr, L"Start this editor with --ads-tweak-ui from black.exe.", L"BLACK ADS Tweak", MB_OK | MB_ICONERROR);
        return 1;
    }
    g_target_pid = (DWORD)pid;
    wchar_t name[64];
    swprintf_s(name, L"Local\\BlackAdsTweak_%lu", pid);
    HANDLE mapping = OpenFileMappingW(FILE_MAP_ALL_ACCESS, FALSE, name);
    if (!mapping) {
        MessageBoxW(nullptr, L"The BLACK loader is not running or its ADS editor mapping is unavailable.", L"BLACK ADS Tweak",
                    MB_OK | MB_ICONERROR);
        return 1;
    }
    g_shared = (AdsTweakShared *)MapViewOfFile(mapping, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(AdsTweakShared));
    if (!g_shared || g_shared->magic != 0x4253414B) {
        MessageBoxW(nullptr, L"The loader shared pose data has an unexpected format.", L"BLACK ADS Tweak", MB_OK | MB_ICONERROR);
        if (g_shared) UnmapViewOfFile(g_shared);
        CloseHandle(mapping);
        return 1;
    }

    INITCOMMONCONTROLSEX controls = {sizeof controls, ICC_BAR_CLASSES};
    InitCommonControlsEx(&controls);
    WNDCLASSW wc = {};
    wc.lpfnWndProc = wndproc;
    wc.hInstance = instance;
    wc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wc.lpszClassName = L"BlackAdsTweakWindow";
    RegisterClassW(&wc);
    HWND hwnd = CreateWindowExW(WS_EX_TOPMOST | WS_EX_TOOLWINDOW, wc.lpszClassName, L"BLACK ADS Joint Tweak",
                                WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU, 40, 30, 460, 730, nullptr, nullptr, instance, nullptr);
    if (!hwnd) {
        UnmapViewOfFile(g_shared);
        CloseHandle(mapping);
        return 1;
    }
    MSG msg;
    while (GetMessageW(&msg, nullptr, 0, 0) > 0) {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }
    UnmapViewOfFile(g_shared);
    CloseHandle(mapping);
    return 0;
}
