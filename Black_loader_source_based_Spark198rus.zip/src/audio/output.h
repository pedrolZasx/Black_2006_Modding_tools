// Host audio output: one 48 kHz stereo float stream fed by the DirectSound HLE mixer.
#pragma once

#include <cstddef>
#include <cstdint>

namespace audio_out {

constexpr uint32_t RATE = 48000;
constexpr uint32_t BLOCK = 480; // frames per submitted block (10 ms)

bool open();                  // false: no host audio (blocks_wanted then follows the clock, silent)
uint32_t blocks_wanted();     // how many more blocks the device can queue now (by the clock while it has none)
void submit(const float *lr); // one BLOCK of interleaved L/R samples (copied)
void simulate_lost();         // tests: act as if the device had gone (XAudio2's critical error)
// Mixes an extra sound (interleaved stereo, 48 kHz, must stay allocated) into the output; any thread.
// Speed of the GAME's sound while the world is in slow motion (1 = normal). Below 1 the mixer is asked for fewer blocks
// and the mix is played back slower (deeper pitch). The armory's own sounds (play_sfx) are added afterwards, so they
// stay at normal speed. Any thread.
void set_game_speed(float speed);
void play_sfx(const float *lr, size_t frames, float gain);
void play_sfx_loop(const float *lr, size_t frames, float gain); // start/update a looping voice keyed by its sample pointer
void stop_sfx_loop(const float *lr); // fade out and stop the matching loop

// Background music for the armory, mixed in after the slow-motion stretch so it always plays at normal speed.
// Tracks are interleaved stereo 16-bit 48 kHz and must stay allocated. The playlist is copied once and retained.
// Level of the GAME's sound (1 = normal). It glides to `level` over `seconds`; the armory sounds and music are not
// affected. Used to lower the game sound while the armory is open. Any thread.
void set_game_volume(float level, float seconds);

struct MusicCfg {
    float delay, fade_in, fade_out, gap, volume, close_fade; // seconds, volume 0..1
};
struct MusicTrack {
    const int16_t *lr;
    size_t frames;
};
void music_set_playlist(const MusicTrack *tracks, size_t count, const MusicCfg &cfg); // any thread; set once
void music_open(bool armory_open);                                   // any thread
void radio_set_playlist(const MusicTrack *tracks, size_t count, const MusicCfg &cfg);
void radio_enable(bool enabled);
void radio_pause(bool paused);
void radio_fade_out(float seconds);
bool radio_enabled();
int radio_current_track(); // -1 while waiting between songs
float radio_caption_alpha();
void radio_set_volume(float level);

} // namespace audio_out
