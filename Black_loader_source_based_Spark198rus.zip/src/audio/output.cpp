// XAudio2 (xaudio2_9.dll ships with Windows 10, loaded at runtime): a mastering voice and one float
// source voice that the mixer keeps QUEUED blocks ahead of the device.
//
// XAudio2 stops for good when its device goes away (sleep and wake with HDMI or USB audio, headphones unplugged,
// another default device): OnCriticalError, and the source voice takes no more buffers. The mixer then got no
// requests, the game's DirectSound buffers stopped playing and the game waited on its sound. So blocks_wanted
// watches for that (the error, or no block taken for a second), closes XAudio2 and opens it again on the default
// device once a second; meanwhile, and without XAudio2 at all, it asks for blocks by the clock (silent).
#include "audio/output.h"

#include "common.h"

#include <windows.h>
#include <xaudio2.h>

#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <vector>

namespace audio_out {
namespace {

constexpr uint32_t QUEUED = 6, RING = QUEUED + 1; // 60 ms ahead of the device

typedef HRESULT(WINAPI *PFN_Create)(IXAudio2 **, UINT32, XAUDIO2_PROCESSOR);
PFN_Create g_create;
IXAudio2 *g_xa;
IXAudio2MasteringVoice *g_master;
IXAudio2SourceVoice *g_src;
float g_ring[RING][BLOCK * 2];
uint32_t g_next;
FILE *g_wav;
uint32_t g_wav_frames;
std::atomic<HRESULT> g_error{S_OK};
ULONGLONG g_last_taken, g_retry_at; // GetTickCount64: the device last took a block; the next reopen
LARGE_INTEGER g_clock_start;
uint64_t g_clock_blocks; // asked for by the clock since g_clock_start (0: not running)
std::atomic<float> g_speed{1.0f};
std::vector<float> g_fifo; // game mix waiting to be played slowed (interleaved stereo)
double g_fpos;             // read position inside g_fifo, in frames

struct EngineCallback : IXAudio2EngineCallback {
    void STDMETHODCALLTYPE OnProcessingPassStart() override {}
    void STDMETHODCALLTYPE OnProcessingPassEnd() override {}
    void STDMETHODCALLTYPE OnCriticalError(HRESULT error) override { g_error = error; }
} g_callback;

void wav_header()
{
    uint32_t data = g_wav_frames * 4;
    struct {
        char riff[4]; uint32_t size; char wave[4], fmt[4]; uint32_t fmt_size;
        uint16_t tag, ch; uint32_t rate, bytes_per_s; uint16_t align, bits;
        char data[4]; uint32_t data_size;
    } h = {{'R', 'I', 'F', 'F'}, 36 + data, {'W', 'A', 'V', 'E'}, {'f', 'm', 't', ' '}, 16, 1, 2, RATE, RATE * 4, 4, 16,
           {'d', 'a', 't', 'a'}, data};
    fseek(g_wav, 0, SEEK_SET);
    fwrite(&h, sizeof h, 1, g_wav);
    fseek(g_wav, 0, SEEK_END);
}

void close_engine()
{
    if (g_src) g_src->DestroyVoice();
    if (g_master) g_master->DestroyVoice();
    if (g_xa) {
        g_xa->UnregisterForCallbacks(&g_callback);
        g_xa->StopEngine();
        g_xa->Release();
    }
    g_src = nullptr;
    g_master = nullptr;
    g_xa = nullptr;
}

HRESULT start_engine()
{
    g_error = S_OK;
    HRESULT hr = g_create(&g_xa, 0, XAUDIO2_DEFAULT_PROCESSOR);
    if (SUCCEEDED(hr)) hr = g_xa->RegisterForCallbacks(&g_callback);
    if (SUCCEEDED(hr)) hr = g_xa->CreateMasteringVoice(&g_master, 2, RATE);
    if (SUCCEEDED(hr) && g_cfg.background) g_master->SetVolume(0.0f); // tests: keep the timing, not the sound
    WAVEFORMATEX wf = {};
    wf.wFormatTag = WAVE_FORMAT_IEEE_FLOAT;
    wf.nChannels = 2;
    wf.nSamplesPerSec = RATE;
    wf.wBitsPerSample = 32;
    wf.nBlockAlign = 8;
    wf.nAvgBytesPerSec = RATE * 8;
    if (SUCCEEDED(hr)) hr = g_xa->CreateSourceVoice(&g_src, &wf, XAUDIO2_VOICE_NOPITCH);
    if (SUCCEEDED(hr)) hr = g_src->Start();
    if (FAILED(hr)) close_engine();
    g_last_taken = GetTickCount64();
    return hr;
}

// Blocks due by the clock (no device to pace the mixer). More than a second behind (the PC slept) is skipped,
// not mixed in a burst.
uint32_t clock_blocks()
{
    LARGE_INTEGER f, now;
    QueryPerformanceFrequency(&f);
    QueryPerformanceCounter(&now);
    if (!g_clock_blocks) {
        g_clock_start = now;
        g_clock_blocks = 1;
    }
    uint64_t due = (uint64_t)(now.QuadPart - g_clock_start.QuadPart) * RATE / BLOCK / f.QuadPart + 1;
    if (due > g_clock_blocks + RATE / BLOCK) g_clock_blocks = due - 1;
    uint32_t want = due > g_clock_blocks ? (uint32_t)std::min<uint64_t>(due - g_clock_blocks, 10) : 0;
    g_clock_blocks += want;
    return want;
}

} // namespace

bool open()
{
    if (!g_cfg.wav_path.empty() && !_wfopen_s(&g_wav, g_cfg.wav_path.c_str(), L"wb")) {
        wav_header();
        logf("[audio] recording the mix to a WAV file"); // its log time = the WAV's start, to line up captures
    }
    HMODULE m = LoadLibraryW(L"xaudio2_9.dll");
    if (!m) m = LoadLibraryW(L"xaudio2_8.dll");
    g_create = m ? (PFN_Create)GetProcAddress(m, "XAudio2Create") : nullptr;
    if (!g_create) {
        logf("[audio] XAudio2 not available: no sound");
        return false;
    }
    CoInitializeEx(nullptr, COINIT_MULTITHREADED); // XAudio2 needs COM on the creating thread (the mixer's)
    HRESULT hr = start_engine();
    if (FAILED(hr)) {
        logf("[audio] XAudio2 setup failed 0x%08lx: no sound", hr);
        g_create = nullptr;
        return false;
    }
    logf("[audio] XAudio2 output: %u Hz stereo, %u ms blocks, %u queued", RATE, BLOCK * 1000 / RATE, QUEUED);
    return true;
}

uint32_t blocks_wanted()
{
    if (!g_create) return clock_blocks();
    ULONGLONG now = GetTickCount64();
    if (g_src && (g_error != S_OK || now - g_last_taken > 1000)) {
        if (g_error != S_OK) logf("[audio] XAudio2 output failed (0x%08lx); opening it again", (unsigned long)g_error.load());
        else logf("[audio] XAudio2 output took no sound for %.1f s; opening it again", (now - g_last_taken) / 1000.0);
        close_engine();
        g_retry_at = now;
        g_clock_blocks = 0;
    }
    if (!g_src) {
        if (now >= g_retry_at) {
            g_retry_at = now + 1000;
            if (SUCCEEDED(start_engine())) logf("[audio] XAudio2 output open again");
        }
        if (!g_src) return clock_blocks();
    }
    XAUDIO2_VOICE_STATE st;
    g_src->GetState(&st, XAUDIO2_VOICE_NOSAMPLESPLAYED);
    static uint32_t underruns, submitted_before;
    if (st.BuffersQueued == 0 && g_next != submitted_before) { // the device ran dry since the last check: a gap
        if (++underruns <= 5 || underruns % 100 == 0) logf("[audio] output underrun #%u (the mixer fell behind)", underruns);
    }
    submitted_before = g_next;
    if (st.BuffersQueued < QUEUED) {
        g_last_taken = now;
        uint32_t need = QUEUED - st.BuffersQueued; // output blocks the device wants
        float sp = g_speed.load();
        if (sp >= 0.999f && g_fifo.empty()) return need;
        // slowed: an output block eats only sp * BLOCK game frames, so the mixer is asked for fewer blocks
        double frames = (double)need * sp * BLOCK + 2.0 - (double)(g_fifo.size() / 2) + g_fpos;
        if (frames <= 0) return 0;
        return std::min<uint32_t>(need, (uint32_t)((frames + BLOCK - 1) / BLOCK));
    }
    return 0;
}

void simulate_lost()
{
    logf("[audio] tests: acting as if the XAudio2 device had gone");
    g_error = XAUDIO2_E_DEVICE_INVALIDATED;
}

namespace {
struct SfxVoice {
    const float *data;
    size_t frames, pos;
    float gain, target_gain;
    bool loop, stopping;
};
std::mutex g_sfx_mu;
std::vector<SfxVoice> g_sfx;
std::atomic<int> g_sfx_n{0};

// ---- armory music --------------------------------------------------------------------------------------------------
constexpr size_t kMaxMusicTracks = 32;
MusicTrack g_music_tracks[kMaxMusicTracks] = {};
size_t g_music_count;
MusicCfg g_music_cfg;
std::atomic<bool> g_music_ready{false}; // published after the playlist and settings are filled
std::atomic<bool> g_music_on{false};
constexpr size_t kMaxRadioTracks = 64;
MusicTrack g_radio_tracks[kMaxRadioTracks] = {};
size_t g_radio_count = 0;
MusicCfg g_radio_cfg{};
std::atomic<bool> g_radio_ready{false}, g_radio_on{false}, g_radio_fading{false};
std::atomic<bool> g_radio_paused{false};
std::atomic<float> g_radio_close_fade{2.0f};
std::atomic<int> g_radio_track_index{-1};
std::atomic<float> g_radio_caption_alpha{0.0f};
std::atomic<float> g_radio_volume{0.8f};
std::atomic<float> g_vol_target{1.0f}, g_vol_rate{1.0f}, g_vol_current{1.0f}; // game volume: target, rate, current

void mix_music(float *out) // adds one block of the armory music; audio thread only
{
    if (!g_music_ready.load(std::memory_order_acquire) || !g_music_count) return;
    const MusicCfg &c = g_music_cfg;
    const double dt = (double)BLOCK / RATE;
    static int phase; // 0 initial delay, 1 playing, 2 silent gap before the next track
    static double t;
    static size_t pos;
    static size_t track_idx;
    static bool was_on, closing;
    static double close_t;
    bool on = g_music_on.load();
    if (on && !was_on) { // opening: restart the playlist and its initial delay
        phase = 0;
        t = 0;
        pos = 0;
        track_idx = 0;
        closing = false;
        close_t = 0;
    } else if (!on && was_on) { // closing: fade the current track without starting another
        closing = true;
        close_t = 0;
    }
    was_on = on;

    float close_gain = 1.0f;
    if (closing) {
        close_t += dt;
        close_gain = (float)std::max(0.0, 1.0 - close_t / std::max(c.close_fade, 0.05f));
    }
    if (!on && (!closing || close_gain <= 0.0f)) { // closed and faded out: restart at the first track next time
        phase = 0;
        t = 0;
        pos = 0;
        track_idx = 0;
        closing = false;
        return;
    }
    if (closing && phase != 1) return; // don't begin a delayed track or the next track while closing
    if (phase == 0) {
        t += dt;
        if (t < c.delay) return;
        phase = 1;
        pos = 0;
    } else if (phase == 2) {
        t += dt;
        if (t < c.gap) return;
        track_idx = (track_idx + 1) % g_music_count;
        phase = 1;
        pos = 0;
    }
    const MusicTrack &track = g_music_tracks[track_idx];
    if (!track.lr || !track.frames) { phase = 2; t = 0; return; }
    const double len = (double)track.frames / RATE, fi = std::max(c.fade_in, 0.01f), fo = std::max(c.fade_out, 0.01f);
    for (uint32_t i = 0; i < BLOCK; i++) {
        if (pos >= track.frames) { // finished: silence, then the next track (or this one again)
            if (closing) {
                phase = 2;
                t = 0;
                return;
            }
            phase = 2;
            t = 0;
            return;
        }
        double ts = (double)pos / RATE;
        float g = (float)(std::min(1.0, ts / fi) * std::min(1.0, std::max(0.0, (len - ts) / fo))) * c.volume * close_gain;
        out[i * 2] += track.lr[pos * 2] * (1.0f / 32768.0f) * g;
        out[i * 2 + 1] += track.lr[pos * 2 + 1] * (1.0f / 32768.0f) * g;
        pos++;
    }
}

void mix_radio(float *out) // radio playlist; audio thread only
{
    if (!g_radio_ready.load(std::memory_order_acquire) || !g_radio_count) return;
    // Pause freezes the playlist clock and sample cursor. Do not run the off->on transition
    // while the pause menu is open: that would restart track one.
    if (g_radio_paused.load(std::memory_order_acquire)) return;
    const MusicCfg &c = g_radio_cfg;
    const double dt = (double)BLOCK / RATE;
    static bool was_on = false, stopping = false;
    static int phase = 0; // 0 initial delay, 1 playing, 2 gap between tracks
    static double t = 0.0, stop_t = 0.0;
    static size_t pos = 0, track_idx = 0;
    bool on = g_radio_on.load(std::memory_order_acquire);
    if (on && !was_on) {
        phase = 0; t = 0; pos = 0; track_idx = 0; stopping = false; stop_t = 0;
        g_radio_track_index.store(-1, std::memory_order_release);
        g_radio_caption_alpha.store(0.0f, std::memory_order_release);
    } else if (!on && was_on) {
        stopping = true; stop_t = 0;
    }
    was_on = on;
    if (!on && !stopping) return;
    float stop_gain = 1.0f;
    if (stopping) {
        stop_t += dt;
        stop_gain = (float)std::max(0.0, 1.0 - stop_t / std::max(g_radio_close_fade.load(std::memory_order_relaxed), 0.05f));
        if (stop_gain <= 0.0f) { phase = 0; t = 0; pos = 0; track_idx = 0; stopping = false; g_radio_track_index.store(-1, std::memory_order_release); g_radio_caption_alpha.store(0.0f, std::memory_order_release); g_radio_fading.store(false, std::memory_order_release); return; }
    }
    if (phase == 0) {
        t += dt;
        if (t < c.delay) return;
        phase = 1; t = 0; pos = 0; g_radio_track_index.store((int)track_idx, std::memory_order_release);
        g_radio_caption_alpha.store(0.0f, std::memory_order_release);
    } else if (phase == 2) {
        if (!on) return;
        t += dt;
        g_radio_caption_alpha.store(0.0f, std::memory_order_release);
        if (t < c.gap) return;
        track_idx = (track_idx + 1) % g_radio_count;
        phase = 1; t = 0; pos = 0; g_radio_track_index.store((int)track_idx, std::memory_order_release);
        g_radio_caption_alpha.store(0.0f, std::memory_order_release);
    }
    const MusicTrack &track = g_radio_tracks[track_idx];
    if (!track.lr || !track.frames) { phase = 2; t = 0; g_radio_caption_alpha.store(0.0f, std::memory_order_release); return; }
    const double len = (double)track.frames / RATE;
    const double fi = std::max(c.fade_in, 0.01f), fo = std::max(c.fade_out, 0.01f);
    const float volume = g_radio_volume.load(std::memory_order_relaxed) * c.volume;
    for (uint32_t i = 0; i < BLOCK; ++i) {
        if (pos >= track.frames) { phase = 2; t = 0; g_radio_caption_alpha.store(0.0f, std::memory_order_release); return; }
        const double ts = (double)pos / RATE;
        const float g = (float)(std::min(1.0, ts / fi) * std::min(1.0, std::max(0.0, (len - ts) / fo))) * volume * stop_gain;
        out[i * 2] += track.lr[pos * 2] * (1.0f / 32768.0f) * g;
        out[i * 2 + 1] += track.lr[pos * 2 + 1] * (1.0f / 32768.0f) * g;
        ++pos;
    }
    const double caption_t = (double)pos / RATE;
    const float caption_gain = caption_t < 5.0 ? (float)(caption_t / 5.0)
                                : caption_t < 10.0 ? (float)((10.0 - caption_t) / 5.0)
                                                   : 0.0f;
    g_radio_caption_alpha.store(caption_gain * stop_gain, std::memory_order_release);
}

void mix_sfx(float *blk) // adds the playing extra sounds to one block
{
    std::lock_guard<std::mutex> lk(g_sfx_mu);
    for (SfxVoice &v : g_sfx) {
        for (size_t i = 0; i < BLOCK; ++i) {
            if (!v.loop && v.pos >= v.frames) break;
            const float step = 1.0f / (RATE * 0.06f); // smooth rain-loop start/stop and volume changes over 60 ms
            if (v.gain < v.target_gain) v.gain = std::min(v.target_gain, v.gain + step);
            else if (v.gain > v.target_gain) v.gain = std::max(v.target_gain, v.gain - step);
            const size_t p = v.pos;
            blk[i * 2] += v.data[p * 2] * v.gain;
            blk[i * 2 + 1] += v.data[p * 2 + 1] * v.gain;
            if (++v.pos >= v.frames) v.pos = v.loop ? 0 : v.frames;
        }
    }
    g_sfx.erase(std::remove_if(g_sfx.begin(), g_sfx.end(), [](const SfxVoice &v) {
        return (!v.loop && v.pos >= v.frames) || (v.loop && v.stopping && v.gain <= 0.0005f);
    }), g_sfx.end());
    g_sfx_n = (int)g_sfx.size();
}
} // namespace

void music_set_playlist(const MusicTrack *tracks, size_t count, const MusicCfg &cfg)
{
    if (!tracks || !count) return;
    count = std::min(count, kMaxMusicTracks);
    for (size_t i = 0; i < count; ++i) g_music_tracks[i] = tracks[i];
    g_music_count = count;
    g_music_cfg = cfg;
    g_music_ready.store(true, std::memory_order_release);
}

void radio_set_playlist(const MusicTrack *tracks, size_t count, const MusicCfg &cfg)
{
    if (!tracks || !count) { g_radio_ready.store(false, std::memory_order_release); return; }
    count = std::min(count, kMaxRadioTracks);
    for (size_t i = 0; i < count; ++i) g_radio_tracks[i] = tracks[i];
    g_radio_cfg = cfg;
    g_radio_count = count;
    g_radio_ready.store(true, std::memory_order_release);
}

void radio_enable(bool enabled)
{
    if (enabled) {
        g_radio_close_fade.store(g_radio_cfg.close_fade, std::memory_order_release);
        g_radio_fading.store(false, std::memory_order_release);
        g_radio_on.store(true, std::memory_order_release);
    } else if (g_radio_on.exchange(false, std::memory_order_acq_rel)) {
        g_radio_close_fade.store(g_radio_cfg.close_fade, std::memory_order_release);
        g_radio_fading.store(true, std::memory_order_release);
    }
}
void radio_fade_out(float seconds)
{
    g_radio_close_fade.store(std::max(seconds, 0.05f), std::memory_order_release);
    g_radio_paused.store(false, std::memory_order_release);
    if (g_radio_on.exchange(false, std::memory_order_acq_rel)) g_radio_fading.store(true, std::memory_order_release);
}
void radio_pause(bool paused) { g_radio_paused.store(paused, std::memory_order_release); }
bool radio_enabled() { return (g_radio_on.load(std::memory_order_acquire) || g_radio_fading.load(std::memory_order_acquire)) && g_radio_ready.load(std::memory_order_acquire); }
int radio_current_track() { return g_radio_track_index.load(std::memory_order_acquire); }
float radio_caption_alpha() { return g_radio_caption_alpha.load(std::memory_order_acquire); }
void radio_set_volume(float level) { g_radio_volume.store(std::clamp(level, 0.0f, 2.0f), std::memory_order_release); }

void set_game_volume(float level, float seconds)
{
    level = std::max(0.0f, std::min(1.0f, level));
    float cur = g_vol_current.load();
    g_vol_rate = std::max(0.01f, std::fabs(level - cur)) / std::max(seconds, 0.05f);
    g_vol_target = level;
}

void music_open(bool armory_open) { g_music_on = armory_open; }

void set_game_speed(float speed) { g_speed = std::max(0.1f, std::min(1.0f, speed)); }

void play_sfx(const float *lr, size_t frames, float gain)
{
    if (!lr || !frames) return;
    std::lock_guard<std::mutex> lk(g_sfx_mu);
    if (g_sfx.size() < 16) g_sfx.push_back({lr, frames, 0, gain, gain, false, false});
    g_sfx_n = (int)g_sfx.size();
}

void play_sfx_loop(const float *lr, size_t frames, float gain)
{
    if (!lr || !frames) return;
    std::lock_guard<std::mutex> lk(g_sfx_mu);
    for (SfxVoice &v : g_sfx) {
        if (v.loop && v.data == lr) {
            v.target_gain = std::clamp(gain, 0.0f, 4.0f);
            v.stopping = false;
            return;
        }
    }
    if (g_sfx.size() < 16) g_sfx.push_back({lr, frames, 0, 0.0f, std::clamp(gain, 0.0f, 4.0f), true, false});
    g_sfx_n = (int)g_sfx.size();
}

void stop_sfx_loop(const float *lr)
{
    if (!lr) return;
    std::lock_guard<std::mutex> lk(g_sfx_mu);
    for (SfxVoice &v : g_sfx) {
        if (v.loop && v.data == lr) {
            v.target_gain = 0.0f;
            v.stopping = true;
        }
    }
}

static void output_block(const float *lr0); // one device block (adds the armory sounds, records, queues)

void submit(const float *game)
{
    float sp = g_speed.load();
    if (sp >= 0.999f) {
        if (!g_fifo.empty()) { g_fifo.clear(); g_fpos = 0; } // back to normal speed
        output_block(game);
        return;
    }
    g_fifo.insert(g_fifo.end(), game, game + BLOCK * 2);
    // play the queued game sound back at `sp` speed (linear interpolation) for as many device blocks as are due
    for (;;) {
        XAUDIO2_VOICE_STATE st = {};
        if (g_src) g_src->GetState(&st, XAUDIO2_VOICE_NOSAMPLESPLAYED);
        if (g_src && st.BuffersQueued >= QUEUED) break;
        size_t frames = g_fifo.size() / 2;
        if (g_fpos + (double)BLOCK * sp + 2.0 > (double)frames) break;
        float out[BLOCK * 2];
        for (uint32_t i = 0; i < BLOCK; i++) {
            size_t k = (size_t)g_fpos;
            float fr = (float)(g_fpos - (double)k);
            out[i * 2] = g_fifo[k * 2] + (g_fifo[k * 2 + 2] - g_fifo[k * 2]) * fr;
            out[i * 2 + 1] = g_fifo[k * 2 + 1] + (g_fifo[k * 2 + 3] - g_fifo[k * 2 + 1]) * fr;
            g_fpos += sp;
        }
        size_t used = (size_t)g_fpos;
        g_fifo.erase(g_fifo.begin(), g_fifo.begin() + used * 2);
        g_fpos -= (double)used;
        output_block(out);
        if (!g_src) break; // no device: the clock paces us, one block per call
    }
    if (g_fifo.size() > (size_t)RATE * 2) { g_fifo.clear(); g_fpos = 0; } // safety: never grow without bound
}

static void output_block(const float *lr0)
{
    float mixed[BLOCK * 2];
    const float *lr = lr0;
    static float vol = 1.0f; // current game volume (glides to g_vol_target)
    const float vol_target = g_vol_target.load();
    const bool ducked = vol != vol_target || vol < 0.999f;
    if (ducked || g_sfx_n.load() > 0 || g_music_ready.load(std::memory_order_acquire) || ((g_radio_on.load() || g_radio_fading.load()) && g_radio_ready.load())) { // game volume, armory sounds and music
        memcpy(mixed, lr0, sizeof mixed);
        if (ducked) {
            const float step = g_vol_rate.load() / RATE;
            for (uint32_t i = 0; i < BLOCK; i++) {
                vol = vol < vol_target ? std::min(vol_target, vol + step) : std::max(vol_target, vol - step);
                mixed[i * 2] *= vol;
                mixed[i * 2 + 1] *= vol;
            }
            g_vol_current = vol;
        }
        if (g_sfx_n.load() > 0) mix_sfx(mixed);
        mix_music(mixed);
        mix_radio(mixed);
        lr = mixed;
    }
    if (g_wav) {
        int16_t pcm[BLOCK * 2];
        for (uint32_t i = 0; i < BLOCK * 2; i++) pcm[i] = (int16_t)(std::max(-1.0f, std::min(1.0f, lr[i])) * 32767.0f);
        fwrite(pcm, sizeof pcm, 1, g_wav);
        g_wav_frames += BLOCK;
        if (g_wav_frames % (RATE / 2) == 0) wav_header(); // keep the header valid if the process is killed
    }
    if (!g_src) return;
    float *b = g_ring[g_next];
    g_next = (g_next + 1) % RING;
    memcpy(b, lr, sizeof g_ring[0]);
    XAUDIO2_BUFFER xb = {};
    xb.AudioBytes = sizeof g_ring[0];
    xb.pAudioData = (const BYTE *)b;
    g_src->SubmitSourceBuffer(&xb);
}

} // namespace audio_out
