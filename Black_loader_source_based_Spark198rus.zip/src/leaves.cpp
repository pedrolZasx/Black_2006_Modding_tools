﻿#include "leaves.h"
#include "common.h"
#include <windows.h>
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <random>
#include <string>
#include <vector>

namespace leaves {
namespace {
struct Settings {
    bool enabled=false;
    std::string texture="fx\\leaf.png";
    int count=90;
    float radius=22.f, height=14.f, size=.34f, fall=.28f;
    float wind[2]={.45f,.12f};
    float flutter=1.6f, randomness=.8f, rotation=2.8f, opacity=.85f;
    float fade_in=1.2f, fade_out=1.0f;
};
struct Motion { float p[3], vx, vz, phase, freq, bob, rot, rot_speed, size, alpha; };
Settings g_s;
std::vector<Motion> g_motion;
std::vector<Particle> g_out;
std::mt19937 g_rng{0x4C454146};
std::chrono::steady_clock::time_point g_last{};
bool g_have_t=false, g_have_file=false;
FILETIME g_stamp{};
DWORD g_check_at=0;
int g_level=-2;
float g_time=0, g_opacity=0;

float rnd(float a,float b){return std::uniform_real_distribution<float>(a,b)(g_rng);}
std::string trim(std::string s){size_t a=s.find_first_not_of(" \t\r\n"),b=s.find_last_not_of(" \t\r\n");return a==s.npos?std::string():s.substr(a,b-a+1);}
bool boolean(const char *v){return _stricmp(v,"0")&&_stricmp(v,"false")&&_stricmp(v,"off")&&_stricmp(v,"no");}
void apply(Settings &s,const std::string &k,const std::string &v){
    const float a=(float)atof(v.c_str()); float x=0,z=0;
    if(k=="enabled")s.enabled=boolean(v.c_str());
    else if(k=="texture")s.texture=v;
    else if(k=="count")s.count=std::clamp(atoi(v.c_str()),0,1200);
    else if(k=="radius")s.radius=std::clamp(a,3.f,80.f);
    else if(k=="height")s.height=std::clamp(a,2.f,50.f);
    else if(k=="size")s.size=std::clamp(a,.03f,3.f);
    else if(k=="fall_speed")s.fall=std::clamp(a,0.f,4.f);
    else if(k=="wind"&&sscanf_s(v.c_str(),"%f %f",&x,&z)==2){s.wind[0]=std::clamp(x,-20.f,20.f);s.wind[1]=std::clamp(z,-20.f,20.f);}
    else if(k=="flutter")s.flutter=std::clamp(a,0.f,12.f);
    else if(k=="randomness")s.randomness=std::clamp(a,0.f,3.f);
    else if(k=="rotation_speed")s.rotation=std::clamp(a,0.f,20.f);
    else if(k=="opacity")s.opacity=std::clamp(a,0.f,1.f);
    else if(k=="fade_in")s.fade_in=std::clamp(a,.05f,20.f);
    else if(k=="fade_out")s.fade_out=std::clamp(a,.05f,20.f);
}
Settings read_settings(int level,bool &ok){
    Settings s; const std::wstring path=g_cfg.port_dir+L"\\weather.ini";
    FILE *f=nullptr; _wfopen_s(&f,path.c_str(),L"r"); ok=f!=nullptr; if(!f)return s;
    char wanted[40]; sprintf_s(wanted,"leaves_level_%02d",std::max(0,level));
    std::string section; char line[512];
    while(fgets(line,sizeof line,f)){
        if(char *h=strchr(line,'#'))*h=0;
        char *p=line; while(*p==' '||*p=='\t')++p;
        if(*p=='['){char *e=strchr(p+1,']');if(e){*e=0;section=trim(p+1);for(char &c:section)c=(char)tolower((unsigned char)c);}continue;}
        if(section!="leaves"&&section!=wanted)continue;
        char *eq=strchr(p,'=');if(!eq)continue;*eq=0;
        apply(s,trim(p),trim(eq+1));
    }
    fclose(f); return s;
}
void reload(int level){
    bool ok=false; Settings s=read_settings(level,ok); if(!ok)return;
    const bool reset=level!=g_level||s.count!=(int)g_motion.size(); g_s=std::move(s); g_level=level;
    if(reset){g_motion.resize((size_t)g_s.count);g_out.resize((size_t)g_s.count);g_have_t=false;}
    logf("[leaves] level %02d: %s, %d particles, radius %.1f m, texture %s",level,g_s.enabled?"on":"off",g_s.count,g_s.radius,g_s.texture.c_str());
}
void refresh(int level){
    DWORD now=GetTickCount(); if(level==g_level&&now<g_check_at)return; g_check_at=now+500;
    WIN32_FILE_ATTRIBUTE_DATA a{}; const std::wstring path=g_cfg.port_dir+L"\\weather.ini";
    if(!GetFileAttributesExW(path.c_str(),GetFileExInfoStandard,&a)){if(level!=g_level)reload(level);return;}
    if(level!=g_level||!g_have_file||CompareFileTime(&a.ftLastWriteTime,&g_stamp)!=0){g_stamp=a.ftLastWriteTime;g_have_file=true;reload(level);}
}
void spawn(Motion &m,const rain::Frame &c,bool first){
    const float a=rnd(0.f,6.2831853f), r=g_s.radius*sqrtf(rnd(.05f,1.f));
    m.p[0]=c.cam[0]+cosf(a)*r; m.p[2]=c.cam[2]+sinf(a)*r;
    m.p[1]=c.cam[1]+(first?rnd(-g_s.height*.35f,g_s.height*.8f):rnd(g_s.height*.25f,g_s.height));
    m.phase=rnd(0.f,6.2831853f);m.freq=rnd(.45f,1.5f);m.bob=rnd(.3f,1.3f);
    m.vx=g_s.wind[0]+rnd(-g_s.randomness,g_s.randomness);m.vz=g_s.wind[1]+rnd(-g_s.randomness,g_s.randomness);
    m.rot=rnd(0.f,6.2831853f);m.rot_speed=rnd(-g_s.rotation,g_s.rotation);m.size=g_s.size*rnd(.65f,1.35f);m.alpha=rnd(.45f,1.f);
}
}

bool frame(const rain::Frame &camera,int level,Frame &out){
    if(level<0)return false; refresh(level);
    const auto now=std::chrono::steady_clock::now();float dt=g_have_t?std::chrono::duration<float>(now-g_last).count():0.f;g_last=now;g_have_t=true;dt=std::clamp(dt,0.f,.08f);g_time+=dt;
    const float target=g_s.enabled?g_s.opacity:0.f;
    if(g_opacity<target)g_opacity=std::min(target,g_opacity+dt/g_s.fade_in);
    else if(g_opacity>target)g_opacity=std::max(target,g_opacity-dt/g_s.fade_out);
    if(g_opacity<=.001f||g_motion.empty())return false;
    for(size_t i=0;i<g_motion.size();++i){
        Motion &m=g_motion[i]; if(m.size<=0)spawn(m,camera,true);
        const float ph=g_time*m.freq+m.phase;
        m.p[0]+=(m.vx+sinf(ph)*g_s.flutter)*dt;
        m.p[2]+=(m.vz+cosf(ph*.73f+m.phase)*g_s.flutter)*dt;
        m.p[1]+=sinf(ph*1.7f+m.phase)*m.bob*dt-g_s.fall*dt;
        m.rot+=m.rot_speed*dt;
        const float dx=m.p[0]-camera.cam[0],dz=m.p[2]-camera.cam[2],dy=m.p[1]-camera.cam[1];
        if(dx*dx+dz*dz>g_s.radius*g_s.radius*1.45f||dy < -g_s.height*.55f)spawn(m,camera,false);
        const float edge=std::sqrt(dx*dx+dz*dz)/g_s.radius;
        const float vertical=std::fabs(dy)/(g_s.height*.9f);
        const float fade=std::clamp((1.18f-edge)*3.f,0.f,1.f)*std::clamp((1.18f-vertical)*3.f,0.f,1.f);
        g_out[i]={{m.p[0],m.p[1],m.p[2]},m.size,m.rot,m.alpha*fade};
    }
    out.texture=g_s.texture;out.opacity=g_opacity;out.particles=g_out.data();out.count=(int)g_out.size();return true;
}
}
