#include "common.h"
#include "weapon_tracer.h"
#include "ui/armory.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <mutex>

namespace {
constexpr uint32_t kAllocHook = 0x001DB854;
constexpr uint32_t kUpdateCall = 0x001E2903;
constexpr int kWeaponCount = 17;
struct Record { uint32_t address = 0; int weapon = -1; bool active = false; float p[3]{}; float d[3]{}; };
struct Profile { bool enabled = true; bool motion_blur = true; float color[3] = {1.f, .72f, .22f}; float thickness = 2.f; float length = 7.f; float travel_distance = 180.f; };
std::array<Record, 16> g_records{};
std::array<Profile, kWeaponCount> g_profiles{};
std::array<bool, kWeaponCount> g_logged_weapon{};
std::mutex g_lock;
DWORD g_checked = 0;
FILETIME g_stamp{};
bool g_loaded = false;
wchar_t g_ini[MAX_PATH]{};

void ini_path() {
    if (g_ini[0]) return;
    GetModuleFileNameW(nullptr, g_ini, MAX_PATH);
    wchar_t *slash = wcsrchr(g_ini, L'\\');
    if (slash) wcscpy_s(slash + 1, MAX_PATH - (slash + 1 - g_ini), L"weapon_tracer.ini");
}
bool read_text(const char *section, const char *key, char *out, size_t cap) {
    out[0] = 0;
    const std::wstring ws = widen(section), wk = widen(key);
    wchar_t value[256]{};
    DWORD n = GetPrivateProfileStringW(ws.c_str(), wk.c_str(), L"", value, (DWORD)std::min(cap, size_t(256)), g_ini);
    if (!n) return false;
    std::string text = narrow(std::wstring(value, n));
    strncpy_s(out, cap, text.c_str(), _TRUNCATE);
    return true;
}
float read_float(const char *section, const char *key, float fallback) {
    char text[128]; if (!read_text(section, key, text, sizeof text)) return fallback;
    char *end = nullptr; float v = strtof(text, &end);
    return end != text && std::isfinite(v) ? v : fallback;
}
void reload_profiles() {
    DWORD now = GetTickCount(); if (now - g_checked < 1000) return; g_checked = now;
    ini_path(); WIN32_FILE_ATTRIBUTE_DATA a{};
    FILETIME stamp{};
    if (GetFileAttributesExW(g_ini, GetFileExInfoStandard, &a)) stamp = a.ftLastWriteTime;
    if (g_loaded && CompareFileTime(&stamp, &g_stamp) == 0) return;
    g_loaded = true; g_stamp = stamp;
    Profile base{};
    base.enabled = read_float("tracer", "enabled", 1.f) != 0;
    base.motion_blur = read_float("tracer", "motion_blur", 1.f) != 0;
    base.thickness = std::clamp(read_float("tracer", "thickness", 2.f), .5f, 20.f);
    base.length = std::clamp(read_float("tracer", "length", 7.f), .1f, 100.f);
    base.travel_distance = std::clamp(read_float("tracer", "travel_distance", 180.f), 0.f, 10000.f);
    char color[128];
    if (read_text("tracer", "color", color, sizeof color)) {
        float r, g, b;
        if (sscanf_s(color, "%f,%f,%f", &r, &g, &b) == 3 && std::isfinite(r) && std::isfinite(g) && std::isfinite(b)) {
            base.color[0] = std::clamp(r, 0.f, 4.f); base.color[1] = std::clamp(g, 0.f, 4.f); base.color[2] = std::clamp(b, 0.f, 4.f);
        }
    }
    for (int i = 0; i < kWeaponCount; ++i) {
        g_profiles[i] = base; char section[32]; sprintf_s(section, "weapon_%02d", i);
        char value[128];
        if (read_text(section, "enabled", value, sizeof value)) g_profiles[i].enabled = strtof(value, nullptr) != 0;
        if (read_text(section, "motion_blur", value, sizeof value)) g_profiles[i].motion_blur = strtof(value, nullptr) != 0;
        g_profiles[i].thickness = std::clamp(read_float(section, "thickness", base.thickness), .5f, 20.f);
        g_profiles[i].length = std::clamp(read_float(section, "length", base.length), .1f, 100.f);
        g_profiles[i].travel_distance = std::clamp(read_float(section, "travel_distance", base.travel_distance), 0.f, 10000.f);
        if (read_text(section, "color", value, sizeof value)) {
            float r, g, b;
            if (sscanf_s(value, "%f,%f,%f", &r, &g, &b) == 3 && std::isfinite(r) && std::isfinite(g) && std::isfinite(b)) {
                g_profiles[i].color[0] = std::clamp(r, 0.f, 4.f); g_profiles[i].color[1] = std::clamp(g, 0.f, 4.f); g_profiles[i].color[2] = std::clamp(b, 0.f, 4.f);
            }
        }
    }
}
void write_jump(uint8_t *at, const void *to) {
    DWORD old = 0; if (!VirtualProtect(at, 5, PAGE_EXECUTE_READWRITE, &old)) return;
    at[0] = 0xE9; *(int32_t *)(at + 1) = (int32_t)((const uint8_t *)to - (at + 5));
    FlushInstructionCache(GetCurrentProcess(), at, 5); DWORD ignored; VirtualProtect(at, 5, old, &ignored);
}
void write_call(uint8_t *at, const void *to) {
    DWORD old = 0; if (!VirtualProtect(at, 5, PAGE_EXECUTE_READWRITE, &old)) return;
    at[0] = 0xE8; *(int32_t *)(at + 1) = (int32_t)((const uint8_t *)to - (at + 5));
    FlushInstructionCache(GetCurrentProcess(), at, 5); DWORD ignored; VirtualProtect(at, 5, old, &ignored);
}
bool patch_bytes(uint32_t address, const uint8_t *expected, size_t size) {
    auto *at = (uint8_t *)(uintptr_t)address;
    if (memcmp(at, expected, size) != 0) { logf("[tracer] patch signature mismatch at %08x", address); return false; }
    return true;
}
}

void weapon_tracer_alloc_hook();
void weapon_tracer_update_hook();

extern "C" void __cdecl weapon_tracer_projectile_created(uint32_t address) {
    if (!address) return;
    int weapon = armory::current_weapon_id();
    float range = weapon_tracer::travel_distance(weapon);
    if (range > 0.f) *(float *)(uintptr_t)(address + 0x78) = range;
    std::lock_guard<std::mutex> guard(g_lock);
    for (Record &r : g_records) if (r.address == address || !r.active) {
        r = {}; r.address = address; r.weapon = weapon; r.active = true;
        if (weapon >= 0 && weapon < kWeaponCount && !g_logged_weapon[weapon]) {
            g_logged_weapon[weapon] = true;
            logf("[tracer] projectile observed for weapon ID %d", weapon);
        }
        return;
    }
}
extern "C" void __cdecl weapon_tracer_projectile_updated(uint32_t address) {
    if (!address) return;
    const uint8_t *p = (const uint8_t *)(uintptr_t)address;
    std::lock_guard<std::mutex> guard(g_lock);
    for (Record &r : g_records) if (r.address == address) {
        if (!p[0x88]) { r.active = false; r.address = 0; return; }
        const float *pos = (const float *)(p + 0x50), *dir = (const float *)(p + 0x60);
        for (int i = 0; i < 3; ++i) { r.p[i] = pos[i]; r.d[i] = dir[i]; }
        r.active = r.weapon >= 0 && r.weapon < kWeaponCount;
        return;
    }
}

namespace weapon_tracer {
void install_patch() {
    static const uint8_t alloc_sig[5] = {0xB0,0x01,0x5E,0x8B,0xE5};
    static const uint8_t update_sig[5] = {0xE8,0xD8,0xFD,0xFF,0xFF};
    if (!patch_bytes(kAllocHook, alloc_sig, sizeof alloc_sig)) return;
    if (!patch_bytes(kUpdateCall, update_sig, sizeof update_sig)) return;
    write_jump((uint8_t *)(uintptr_t)kAllocHook, (const void *)weapon_tracer_alloc_hook);
    write_call((uint8_t *)(uintptr_t)kUpdateCall, (const void *)weapon_tracer_update_hook);
    logf("[tracer] projectile hooks installed");
}
bool segment(int index, Segment &out) {
    if (index < 0 || index >= (int)g_records.size()) return false;
    std::lock_guard<std::mutex> guard(g_lock); const Record &r = g_records[index];
    if (!r.active) return false;
    memcpy(out.position, r.p, sizeof out.position); memcpy(out.direction, r.d, sizeof out.direction); out.weapon_id = r.weapon;
    return true;
}
Settings settings(int weapon_id) {
    reload_profiles(); if (weapon_id < 0 || weapon_id >= kWeaponCount) weapon_id = 0;
    const Profile &p = g_profiles[weapon_id];
    return {p.enabled, p.motion_blur, {p.color[0],p.color[1],p.color[2]}, p.thickness, p.length};
}
float travel_distance(int weapon_id) {
    reload_profiles(); if (weapon_id < 0 || weapon_id >= kWeaponCount) weapon_id = 0;
    return g_profiles[weapon_id].travel_distance;
}
} // namespace weapon_tracer

__declspec(naked) void weapon_tracer_alloc_hook() {
    __asm {
        pushfd
        pushad
        push esi
        call weapon_tracer_projectile_created
        add esp, 4
        popad
        popfd
        mov al, 1
        pop esi
        mov esp, ebp
        pop ebp
        ret 14h
    }
}
__declspec(naked) void weapon_tracer_update_hook() {
    __asm {
        push dword ptr [esp+4]
        mov edx, 001E26E0h
        call edx
        pushfd
        pushad
        push esi
        call weapon_tracer_projectile_updated
        add esp, 4
        popad
        popfd
        ret 4
    }
}
