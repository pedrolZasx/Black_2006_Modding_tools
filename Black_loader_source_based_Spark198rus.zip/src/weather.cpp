#include "weather.h"

#include "audio/output.h"
#include "common.h"
#include "ui/sfx.h"
#include "weather_core.h"

#include <windows.h>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <mutex>
#include <new>
#include <set>
#include <string>
#include <thread>
#include <vector>

namespace weather {
namespace {

// ---- thunder sounds ------------------------------------------------------------------------------------------------
// Every .wav in <sound_folder> is a thunder for big strikes; .wav files in <sound_folder>\weak are for weak strikes
// (when there are none, weak strikes use the big ones, quieter). They are decoded to 48 kHz stereo floats on a
// background thread and then stay allocated (the audio mixer plays straight from this memory). Files dropped into the
// folder while the game runs are picked up when weather.ini is saved.
struct Wav {
    std::vector<float> lr;
    std::wstring name;
};
std::mutex g_snd_mu;
std::vector<Wav *> g_big, g_weak;
std::set<std::wstring> g_seen;
size_t g_snd_bytes;
std::atomic<bool> g_scan_busy{false};
constexpr size_t kMaxFileBytes = 32u * 1024u * 1024u;

Settings g_s;
bool g_loaded;
Rng g_rng{std::random_device{}()};
std::wstring g_ini_path;

std::wstring widen(const std::string &s)
{
    if (s.empty()) return std::wstring();
    int n = MultiByteToWideChar(CP_ACP, 0, s.c_str(), (int)s.size(), nullptr, 0);
    std::wstring w((size_t)n, L'\0');
    MultiByteToWideChar(CP_ACP, 0, s.c_str(), (int)s.size(), &w[0], n);
    return w;
}

std::wstring resolve_folder(const std::string &f)
{
    std::wstring w = widen(f);
    bool absolute = (w.size() > 1 && w[1] == L':') || (!w.empty() && (w[0] == L'\\' || w[0] == L'/'));
    std::wstring p = absolute ? w : g_cfg.port_dir + L"\\" + w;
    while (p.size() > 1 && (p.back() == L'\\' || p.back() == L'/')) p.pop_back();
    return p;
}

std::string narrow(const std::wstring &w)
{
    if (w.empty()) return std::string();
    int n = WideCharToMultiByte(CP_ACP, 0, w.c_str(), (int)w.size(), nullptr, 0, nullptr, nullptr);
    std::string s((size_t)n, '\0');
    WideCharToMultiByte(CP_ACP, 0, w.c_str(), (int)w.size(), &s[0], n, nullptr, nullptr);
    return s;
}

void scan_folder(const std::wstring &dir, std::vector<Wav *> &dst, size_t budget, const wchar_t *mask = L"*.wav")
{
    std::vector<std::wstring> names;
    WIN32_FIND_DATAW fd;
    HANDLE h = FindFirstFileW((dir + L"\\" + mask).c_str(), &fd);
    if (h == INVALID_HANDLE_VALUE) return;
    do {
        if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) names.push_back(fd.cFileName);
    } while (FindNextFileW(h, &fd));
    FindClose(h);
    std::sort(names.begin(), names.end());
    for (const std::wstring &n : names) {
        std::wstring full = dir + L"\\" + n;
        {
            std::lock_guard<std::mutex> lk(g_snd_mu);
            if (!g_seen.insert(full).second) continue; // already loaded
        }
        FILE *f = _wfopen(full.c_str(), L"rb");
        if (!f) continue;
        fseek(f, 0, SEEK_END);
        long sz = ftell(f);
        fseek(f, 0, SEEK_SET);
        std::vector<uint8_t> bytes;
        bool ok = sz > 44 && (size_t)sz <= kMaxFileBytes;
        if (ok) {
            bytes.resize((size_t)sz);
            ok = fread(bytes.data(), 1, bytes.size(), f) == bytes.size();
        }
        fclose(f);
        if (!ok) {
            logf("[weather] thunder %s: unreadable or over %u MB, skipped", narrow(n).c_str(), (unsigned)(kMaxFileBytes >> 20));
            continue;
        }
        Wav *w = new (std::nothrow) Wav();
        if (!w) continue;
        w->name = n;
        bool dec = false;
        try {
            dec = sfx::decode_wav(bytes.data(), bytes.size(), w->lr, 1.0f);
        } catch (...) {
            dec = false;
        }
        size_t need = w->lr.size() * sizeof(float);
        std::lock_guard<std::mutex> lk(g_snd_mu);
        if (!dec) {
            logf("[weather] thunder %s: not a 16-bit PCM / 32-bit float mono or stereo wav, skipped", narrow(n).c_str());
            delete w;
        } else if (g_snd_bytes + need > budget) {
            logf("[weather] thunder %s: over the sound_budget_mb limit, skipped", narrow(n).c_str());
            delete w;
        } else {
            g_snd_bytes += need;
            dst.push_back(w);
            logf("[weather] thunder %s: %.1f s", narrow(n).c_str(), (double)(w->lr.size() / 2) / audio_out::RATE);
        }
    }
}

// Makes <folder> and <folder>\\weak next to black.exe on the first start, with a short note on what goes in them.
void ensure_folders()
{
    std::wstring dir = resolve_folder(g_s.sound_folder);
    bool fresh = GetFileAttributesW(dir.c_str()) == INVALID_FILE_ATTRIBUTES;
    CreateDirectoryW(dir.c_str(), nullptr);
    CreateDirectoryW((dir + L"\\weak").c_str(), nullptr);
    if (!fresh) return;
    FILE *f = _wfopen((dir + L"\\README.txt").c_str(), L"w");
    if (!f) return;
    fputs("Thunder sounds for the storm (see weather.ini).\n\n"
          "Put .wav files here (16-bit PCM or 32-bit float, mono or stereo, any sample rate).\n"
          "  this folder        : played after a BIG flash. One is picked at random each time.\n"
          "  weak\\ subfolder   : played after a weak flash (optional; when it is empty the weak flash uses the files from\n"
          "                       this folder, quieter - weak_thunder_volume in weather.ini).\n\n"
          "The delay between the big flash and the sound is thunder_delay in weather.ini, in milliseconds.\n"
          "A long rumble with its crack right at the start works best: the file starts playing exactly when the delay is over.\n",
          f);
    fclose(f);
}

void rescan_sounds()
{
    if (!g_s.sound || g_scan_busy.exchange(true)) return;
    std::wstring dir = resolve_folder(g_s.sound_folder);
    size_t budget = (size_t)(std::max(g_s.sound_budget_mb, 1.0f) * 1024.0f * 1024.0f);
    try {
        std::thread([dir, budget]() {
            scan_folder(dir, g_big, budget);
            scan_folder(dir + L"\\weak", g_weak, budget);
            bool needs_effects_fallback = false;
            {
                std::lock_guard<std::mutex> lk(g_snd_mu);
                needs_effects_fallback = g_big.empty();
            }
            // The game's normal effects folder is also a convenient place for user-provided thunder1.wav files.
            // Keep this fallback filtered so unrelated weapon and ambience effects never become thunder.
            bool used_effects_fallback = needs_effects_fallback;
            if (needs_effects_fallback) {
                std::vector<std::wstring> effects_dirs;
                effects_dirs.push_back(g_cfg.port_dir + L"\\effects");
                size_t xbe_slash = g_cfg.xbe_path.find_last_of(L"\\/");
                if (xbe_slash != std::wstring::npos) {
                    std::wstring game_effects = g_cfg.xbe_path.substr(0, xbe_slash) + L"\\effects";
                    if (_wcsicmp(game_effects.c_str(), effects_dirs.front().c_str()) != 0)
                        effects_dirs.push_back(game_effects);
                }
                for (const std::wstring &effects : effects_dirs) {
                    scan_folder(effects, g_big, budget, L"thunder*.wav");
                    scan_folder(effects + L"\\weak", g_weak, budget, L"thunder*.wav");
                }
            }
            size_t nb, nw;
            {
                std::lock_guard<std::mutex> lk(g_snd_mu);
                nb = g_big.size();
                nw = g_weak.size();
            }
            logf("[weather] thunder folder %s%s: %u big, %u weak sound(s)", narrow(dir).c_str(),
                 used_effects_fallback ? " (effects fallback checked)" : "", (unsigned)nb, (unsigned)nw);
            g_scan_busy = false;
        }).detach();
    } catch (...) {
        g_scan_busy = false;
    }
}

Wav *pick(bool big)
{
    static Wav *last_big, *last_weak;
    std::lock_guard<std::mutex> lk(g_snd_mu);
    std::vector<Wav *> &list = (!big && !g_weak.empty()) ? g_weak : g_big;
    if (list.empty()) return nullptr;
    Wav *&last = big ? last_big : last_weak;
    Wav *w = list[g_rng() % list.size()];
    if (list.size() > 1)
        for (int i = 0; w == last && i < 8; i++) w = list[g_rng() % list.size()]; // not the same one twice in a row
    last = w;
    return w;
}

// ---- weather.ini ---------------------------------------------------------------------------------------------------
void write_default_ini(const std::wstring &path)
{
    FILE *f = _wfopen(path.c_str(), L"w");
    if (!f) return;
    fputs(
        "# Thunderstorm for the BLACK port. Saved changes apply within a second, while the game runs.\n"
        "# F9 = test strike now (big: small, small, BIG + thunder). Shift+F9 = a weak flash.\n"
        "# Two numbers = a range (min max): every strike picks a random value in it.\n"
        "\n"
        "[general]\n"
        "enabled = 1            # 0 = no storm at all\n"
        "levels = all           # all, or only these levels, e.g. levels = 1 3 5 (level_01, level_03, level_05)\n"
        "strength = 1.0         # master brightness of every flash\n"
        "color = 0.78 0.86 1.0  # flash colour (r g b), cold blue-white\n"
        "interval = 6 25        # seconds between strikes\n"
        "first_strike = 3 8     # seconds from entering a level to the first strike\n"
        "big_chance = 55        # % of strikes that are the strong pattern; the rest are weak flashes\n"
        "attack = 10            # ms a flash needs to reach full brightness (smaller = sharper)\n"
        "\n"
        "[strong strike: small flashes, then a quick BIG flash]\n"
        "small_count = 2 2          # how many small flashes come first\n"
        "small_intensity = 0.22 0.42\n"
        "small_length = 55 90       # ms each small flash takes to fade\n"
        "small_gap = 70 150         # ms from the start of one small flash to the start of the next\n"
        "big_delay = 90 200         # ms from the last small flash to the big one (smaller = quicker)\n"
        "big_intensity = 0.95 1.25\n"
        "big_length = 180 320       # ms the big flash takes to fade\n"
        "flicker_chance = 45        # % chance of a faint flicker right after the big flash\n"
        "flicker_intensity = 0.15 0.35\n"
        "\n"
        "[weak strike: faint flash, no big one]\n"
        "weak_count = 1 2\n"
        "weak_intensity = 0.06 0.20\n"
        "weak_length = 80 170\n"
        "weak_gap = 90 220\n"
        "\n"
        "[how the light looks on the map]\n"
        "flash_floor = 0.22     # how much even a black surface lights up (0..1)\n"
        "flash_gain = 1.2       # how much the existing colours brighten\n"
        "far_fade = 0.35        # 0..1: distant surfaces get less light\n"
        "flash_range = 80       # metres where far_fade is complete\n"
        "normal_strength = 0.5  # 0 = flat light, 1 = surfaces facing the camera light up more\n"
        "sky_gain = 1.0         # brightness of the sky / very far pixels\n"
        "gun_flash = 1          # 1 = the first-person gun is lit by the flash too\n"
        "\n"
        "[thunder sound]\n"
        "sound = 1\n"
        "sound_folder = thunder        # folder with the .wav files, next to black.exe (or a full path)\n"
        "                              # thunder\\*.wav = big strikes, thunder\\weak\\*.wav = weak strikes (optional)\n"
        "thunder_delay = 350 1600      # ms AFTER the big flash starts until the thunder plays\n"
        "thunder_volume = 1.0\n"
        "weak_sound = 1                # weak flashes get a (quieter) thunder too\n"
        "weak_thunder_delay = 700 2400 # ms after a weak flash\n"
        "weak_thunder_volume = 0.35\n"
        "sound_budget_mb = 48          # all thunder wavs together stay in memory; bigger files are skipped\n"
        "\n"
        "[rain]\n"
        "enabled = 1                  # 0 = no rain; rain settings live in this same weather.ini\n"
        "sound = 1                    # loop the rain ambience while rain is active in a mission\n"
        "sound_file = rain\\rain.wav  # WAV next to black.exe in the rain folder\n"
        "sound_volume = 0.80          # 0..4\n"
        "count = 2200                 # number of drops\n"
        "radius = 12                 # metres around the camera (drops themselves stay in world space)\n"
        "below = 5\n"
        "above = 9\n"
        "speed = 9.5 12.5\n"
        "length = 0.45 0.85\n"
        "alpha = 0.28 0.55\n"
        "wind = 3.5 1.5\n"
        "wind_variation = 2.0        # random per-drop sideways wind in m/s\n"
        "blend_chance = 100\n"
        "blend_amount = 0.20 0.78\n"
        "blend_alpha = 0.35 0.75\n"
        "width = 1.3\n"
        "color = 0.78 0.84 0.95\n"
        "near_fade = 1.0\n"
        "amb_min = 0.30\n"
        "amb_gain = 0.90\n"
        "\n[leaves]\n"
        "enabled = 0                  # enable leaves only on selected missions with [leaves_level_NN]\n"
        "texture = fx\\leaf.png      # transparent leaf PNG next to black.exe\n"
        "count = 90\nradius = 22\nheight = 14\nsize = 0.34\nfall_speed = 0.28\n"
        "wind = 0.45 0.12\nflutter = 1.6\nrandomness = 0.8\nrotation_speed = 2.8\n"
        "opacity = 0.85\nfade_in = 1.2\nfade_out = 1.0\n",
        f);
    fclose(f);
}

bool two(const char *v, Range &r)
{
    float a = 0, b = 0;
    int n = sscanf(v, "%f %f", &a, &b);
    if (n < 1) return false;
    r = Range(a, n >= 2 ? b : a);
    return true;
}

Settings parse_ini(const std::wstring &path, bool &ok)
{
    Settings s;
    FILE *f = _wfopen(path.c_str(), L"r");
    ok = f != nullptr;
    if (!f) return s;
    char line[512];
    std::string section;
    auto trim = [](std::string &t) {
        size_t a = t.find_first_not_of(" \t\r\n"), b = t.find_last_not_of(" \t\r\n");
        t = a == std::string::npos ? std::string() : t.substr(a, b - a + 1);
    };
    while (fgets(line, sizeof line, f)) {
        if (char *h = strchr(line, '#')) *h = 0;
        char *p = line;
        while (*p == ' ' || *p == '\t') ++p;
        if (*p == '[') {
            char *end = strchr(p + 1, ']');
            if (end) { *end = 0; section = p + 1; trim(section); }
            continue;
        }
        char *eq = strchr(p, '=');
        if (!eq) continue;
        *eq = 0;
        std::string key = p, val = eq + 1;
        trim(key);
        trim(val);
        if (key.empty()) continue;
        const bool general = section == "general" &&
            (key == "enabled" || key == "levels" || key == "strength" || key == "color" || key == "interval" ||
             key == "first_strike" || key == "big_chance" || key == "attack");
        const bool strong = section == "strong strike: small flashes, then a quick BIG flash" &&
            (key == "small_count" || key == "small_intensity" || key == "small_length" || key == "small_gap" ||
             key == "big_delay" || key == "big_intensity" || key == "big_length" || key == "flicker_chance" || key == "flicker_intensity");
        const bool weak = section == "weak strike: faint flash, no big one" &&
            (key == "weak_count" || key == "weak_intensity" || key == "weak_length" || key == "weak_gap");
        const bool lighting = section == "how the light looks on the map" &&
            (key == "flash_floor" || key == "flash_gain" || key == "far_fade" || key == "flash_range" ||
             key == "normal_strength" || key == "sky_gain" || key == "gun_flash");
        const bool thunder = section == "thunder sound" &&
            (key == "sound" || key == "sound_folder" || key == "thunder_delay" || key == "thunder_volume" ||
             key == "weak_sound" || key == "weak_thunder_delay" || key == "weak_thunder_volume" || key == "sound_budget_mb");
        if (!general && !strong && !weak && !lighting && !thunder) continue;
        const char *v = val.c_str();
        float a = (float)atof(v), c[3] = {0, 0, 0};
        Range r;
        if (key == "enabled") s.enabled = a != 0;
        else if (key == "levels") {
            s.levels.clear();
            if (_stricmp(v, "all") && _stricmp(v, "-1"))
                for (const char *p = v; *p;) {
                    while (*p == ' ' || *p == ',' || *p == '\t') p++;
                    if (*p >= '0' && *p <= '9') s.levels.push_back(atoi(p));
                    while (*p && *p != ' ' && *p != ',' && *p != '\t') p++;
                }
        } else if (key == "strength") s.strength = std::clamp(a, 0.0f, 4.0f);
        else if (key == "color") {
            if (sscanf(v, "%f %f %f", &c[0], &c[1], &c[2]) == 3) std::copy(c, c + 3, s.color);
        } else if (key == "interval" && two(v, r)) s.interval = Range(std::max(r.lo, 0.5f), std::max(r.hi, 0.5f));
        else if (key == "first_strike" && two(v, r)) s.first_strike = r;
        else if (key == "big_chance") s.big_chance = std::clamp(a, 0.0f, 100.0f);
        else if (key == "attack") s.attack = std::clamp(a, 1.0f, 200.0f);
        else if (key == "small_count" && two(v, r)) s.small_count = Range(std::clamp(r.lo, 0.0f, 8.0f), std::clamp(r.hi, 0.0f, 8.0f));
        else if (key == "small_intensity" && two(v, r)) s.small_intensity = r;
        else if (key == "small_length" && two(v, r)) s.small_length = r;
        else if (key == "small_gap" && two(v, r)) s.small_gap = r;
        else if (key == "big_delay" && two(v, r)) s.big_delay = r;
        else if (key == "big_intensity" && two(v, r)) s.big_intensity = r;
        else if (key == "big_length" && two(v, r)) s.big_length = r;
        else if (key == "flicker_chance") s.flicker_chance = std::clamp(a, 0.0f, 100.0f);
        else if (key == "flicker_intensity" && two(v, r)) s.flicker_intensity = r;
        else if (key == "weak_count" && two(v, r)) s.weak_count = Range(std::clamp(r.lo, 1.0f, 8.0f), std::clamp(r.hi, 1.0f, 8.0f));
        else if (key == "weak_intensity" && two(v, r)) s.weak_intensity = r;
        else if (key == "weak_length" && two(v, r)) s.weak_length = r;
        else if (key == "weak_gap" && two(v, r)) s.weak_gap = r;
        else if (key == "flash_floor") s.flash_floor = std::clamp(a, 0.0f, 2.0f);
        else if (key == "flash_gain") s.flash_gain = std::clamp(a, 0.0f, 6.0f);
        else if (key == "far_fade") s.far_fade = std::clamp(a, 0.0f, 1.0f);
        else if (key == "flash_range") s.flash_range = std::clamp(a, 1.0f, 1000.0f);
        else if (key == "normal_strength") s.normal_strength = std::clamp(a, 0.0f, 1.0f);
        else if (key == "sky_gain") s.sky_gain = std::clamp(a, 0.0f, 4.0f);
        else if (key == "gun_flash") s.gun_flash = std::clamp(a, 0.0f, 1.0f);
        else if (key == "sound") s.sound = a != 0;
        else if (key == "sound_folder") {
            if (val.size() >= 2 && val.front() == '"' && val.back() == '"') val = val.substr(1, val.size() - 2);
            if (!val.empty()) s.sound_folder = val;
        } else if (key == "thunder_delay" && two(v, r)) s.thunder_delay = Range(std::max(r.lo, 0.0f), std::max(r.hi, 0.0f));
        else if (key == "thunder_volume") s.thunder_volume = std::clamp(a, 0.0f, 4.0f);
        else if (key == "weak_sound") s.weak_sound = a != 0;
        else if (key == "weak_thunder_delay" && two(v, r)) s.weak_thunder_delay = Range(std::max(r.lo, 0.0f), std::max(r.hi, 0.0f));
        else if (key == "weak_thunder_volume") s.weak_thunder_volume = std::clamp(a, 0.0f, 4.0f);
        else if (key == "sound_budget_mb") s.sound_budget_mb = std::clamp(a, 1.0f, 256.0f);
    }
    fclose(f);
    return s;
}

void refresh_settings()
{
    static FILETIME stamp;
    static uint32_t next_check;
    if (g_ini_path.empty()) {
        g_ini_path = g_cfg.port_dir + L"\\weather.ini";
        if (GetFileAttributesW(g_ini_path.c_str()) == INVALID_FILE_ATTRIBUTES) write_default_ini(g_ini_path);
    }
    uint32_t fr = g_frame_count.load();
    if (g_loaded && fr < next_check) return;
    next_check = fr + 30;
    WIN32_FILE_ATTRIBUTE_DATA a;
    if (!GetFileAttributesExW(g_ini_path.c_str(), GetFileExInfoStandard, &a)) {
        if (!g_loaded) { g_loaded = true; ensure_folders(); rescan_sounds(); } // no file and cannot write one: built-in defaults
        return;
    }
    if (g_loaded && !CompareFileTime(&a.ftLastWriteTime, &stamp)) return;
    stamp = a.ftLastWriteTime;
    bool ok = false;
    Settings s = parse_ini(g_ini_path, ok);
    if (!ok) return;
    g_s = s;
    g_loaded = true;
    logf("[weather] settings from %ls: %s, strikes every %.0f-%.0f s, %.0f%% strong, thunder %s %.0f-%.0f ms after the big flash, folder %s",
         g_ini_path.c_str(),
         g_s.enabled ? "on" : "off", g_s.interval.lo, g_s.interval.hi, g_s.big_chance, g_s.sound ? "on" : "off", g_s.thunder_delay.lo,
         g_s.thunder_delay.hi, g_s.sound_folder.c_str());
    ensure_folders();
    rescan_sounds();
}

// ---- the storm -----------------------------------------------------------------------------------------------------
struct Pending {
    double at; // ms
    Wav *wav;
    float volume;
};
bool g_armed;               // a schedule exists for the current level
double g_next;              // ms: next strike
double g_last_t;            // ms: previous frame
double g_test_until;        // ms: after an F9 test strike the level filter is ignored until then
bool g_strike_on;
Strike g_strike;
std::vector<Pending> g_pending;
int g_level_seen = -2;
std::atomic<int> g_force{0}; // 1 = big strike, 2 = weak strike (F9)

double now_ms()
{
    using namespace std::chrono;
    return duration<double, std::milli>(steady_clock::now().time_since_epoch()).count();
}

bool level_allowed()
{
    int lv = g_current_level.load();
    if (lv < 0) return false; // no level opened yet: still in the menus / intro
    if (g_s.levels.empty()) return true;
    return std::find(g_s.levels.begin(), g_s.levels.end(), lv) != g_s.levels.end();
}

void start_strike(double t, bool big)
{
    g_strike = make_strike(g_s, big, g_rng, t);
    g_strike_on = true;
    bool snd = g_s.sound && (big || g_s.weak_sound);
    double at = 0;
    const char *file = "no sound";
    std::string fname;
    if (snd) {
        Wav *w = pick(big);
        if (w) {
            at = g_strike.big_start + rnd(g_rng, big ? g_s.thunder_delay : g_s.weak_thunder_delay);
            g_pending.push_back({at, w, big ? g_s.thunder_volume : g_s.weak_thunder_volume});
            fname = narrow(w->name);
            file = fname.c_str();
        } else file = "no wav in the thunder folder";
    }
    const char *what = big ? "big flash" : "flash";
    if (snd && at > 0) logf("[weather] %s strike: %d flash(es), %s at +%.0f ms, thunder %.0f ms later (%s)", big ? "strong" : "weak",
                            g_strike.flashes, what, g_strike.big_start - t, at - g_strike.big_start, file);
    else logf("[weather] %s strike: %d flash(es), %s", big ? "strong" : "weak", g_strike.flashes, file);
}

} // namespace

void trigger(bool big) { g_force = big ? 1 : 2; }

bool frame(Look &out)
{
    refresh_settings();
    double t = now_ms();
    // a stall (loading, pause, window drag): the storm clock waits too, so no flash or thunder is lost
    if (g_last_t > 0 && t - g_last_t > 250.0) {
        double gap = t - g_last_t - 17.0;
        g_next += gap;
        for (Pending &p : g_pending) p.at += gap;
        for (Pulse &p : g_strike.pulses) p.start += gap;
        g_strike.end += gap;
        g_strike.big_start += gap;
    }
    g_last_t = t;

    int lv = g_current_level.load();
    int force = g_force.exchange(0);
    if (force) g_test_until = t + 6000.0;
    bool allowed = g_s.enabled && (level_allowed() || t < g_test_until);
    if (!allowed && !force) {
        g_armed = false;
        g_strike_on = false;
        g_pending.clear();
        g_level_seen = lv;
        return false;
    }
    if (!g_armed || lv != g_level_seen) {
        g_armed = true;
        g_level_seen = lv;
        g_strike_on = false;
        g_next = t + 1000.0 * rnd(g_rng, g_s.first_strike);
    }
    if (force) start_strike(t, force == 1);
    else if (!g_strike_on && t >= g_next) start_strike(t, chance(g_rng, g_s.big_chance));

    double level = 0;
    if (g_strike_on) {
        level = level_at(g_strike, t, g_s.attack);
        if (t > g_strike.end) {
            g_strike_on = false;
            g_next = t + 1000.0 * rnd(g_rng, g_s.interval);
        }
    }
    for (size_t i = 0; i < g_pending.size();) { // thunder whose time has come
        if (t >= g_pending[i].at) {
            Wav *w = g_pending[i].wav;
            audio_out::play_sfx(w->lr.data(), w->lr.size() / 2, g_pending[i].volume);
            g_pending.erase(g_pending.begin() + (std::ptrdiff_t)i);
        } else i++;
    }
    if (level < 0.002) return false;
    out.level = (float)level;
    for (int i = 0; i < 3; i++) out.rgb[i] = g_s.color[i] * g_s.strength;
    out.floor = g_s.flash_floor;
    out.gain = g_s.flash_gain;
    out.gun = g_s.gun_flash;
    out.range = g_s.flash_range;
    out.far_fade = g_s.far_fade;
    out.normal_strength = g_s.normal_strength;
    out.sky_gain = g_s.sky_gain;
    return true;
}

} // namespace weather
