// Draw calls and state application. State lives in the Xbox arrays (render_state(), texture_state())
// because game code writes them directly; it is translated to D3D9 at each draw (with a cache of what
// was last sent).

#include <intrin.h>
#include "d3d/draw.h"

#include "ads_tweak.h"
#include "d3d/device.h"
#include "d3d/dispatch.h"
#include "d3d/host.h"
#include "d3d/pshader.h"
#include "d3d/pushbuf.h"
#include "d3d/state.h"
#include "d3d/vshader.h"
#include "d3d/nv2a_vsh.h"
#include "fov.h"
#include "common.h"
#include "input/freecam.h"
#include "perf.h"
#include "wind.h"
#include "fire_lights.h"
#include "ui/image.h"

#include <wincodec.h>

#include <algorithm>
#include <cmath>
#include <cstring>
#include <unordered_map>
#include <unordered_set>
#include <vector>

// measured from the game's own view-projection matrix (capture_scene_matrix below); declared in common.h
std::atomic<float> g_scene_tan_h{0.0f}, g_scene_tan_v{0.0f}, g_scene_near{0.0f};

namespace xd3d {

namespace {
bool g_fp_arms_draw_active = false;
IDirect3DTexture9 *g_fp_arms_texture = nullptr;
bool g_fp_arms_texture_load_attempted = false;
bool g_fp_gun_draw_active = false;
IDirect3DTexture9 *g_fp_gun_texture = nullptr;
bool g_fp_gun_texture_load_attempted = false;
bool g_fp_skinning_draw_active = false;

// Keep the draw ordinal for identifying the rigid attachment drawn after the skinned pair. Do not use it
// to label gun vs arms: AK1 stores arms first, while GK1/PST store the gun first. Across these DBs, the
// arms occupy the low vertex-index range (starting at slot 0), and the gun uses the higher range.
constexpr uint32_t kFpPartGun = 0, kFpPartArms = 1;
constexpr uint32_t kFpLastSkinnedPartOrdinal = 1;
uint32_t g_fp_part_ordinal = 0;
uint32_t g_fp_part_frame = ~0u;
const uint16_t *g_fp_part_first_indices = nullptr;
Resource *g_fp_native_gun_texture = nullptr;
const uint16_t *g_fp_native_gun_indices = nullptr;
VertexBuffer *g_fp_native_gun_vertices = nullptr;
const uint16_t *g_fp_current_gun_indices = nullptr;
VertexBuffer *g_fp_current_gun_vertices = nullptr;

// BLACK's type-4 first-person material handler queues its per-stage resource in
// 0x0056EF30; 0x0056EB60 is texture-stage-state slot 6 (mip bias), not a resource pointer.
// The queued resource is normally committed by the XBE's deferred-state flush. If the
// loader's HLE shadow missed that commit, mirror the actual resource before this draw.
// This is based on the XBE material state, not mesh size or a weapon-specific count.
void sync_first_person_material_textures()
{
    constexpr uintptr_t kXboxRamBegin = 0x80000000u;
    constexpr uintptr_t kXboxRamEnd = 0x84000000u;
    auto *xbe_stages = (uint32_t *)(uintptr_t)0x0056EF30u;
    for (uint32_t stage = 0; stage < 4; ++stage) {
        const uint32_t address = xbe_stages[stage];
        if (address < kXboxRamBegin || address >= kXboxRamEnd) {
            if (debug_frame_active())
                logf("[fp-native-texture] frame %u: stage %u queued value %08x is not an Xbox RAM resource; HLE currently %p",
                     g_frame_count.load() + 1, stage, address, g_st.textures[stage]);
            continue;
        }
        auto *resource = (Resource *)(uintptr_t)address;
        const uint32_t type = resource_type(resource);
        if (debug_frame_active())
            logf("[fp-native-texture] frame %u: stage %u XBE queued %08x type %u; HLE currently %p",
                 g_frame_count.load() + 1, stage, address, type, g_st.textures[stage]);
        if (type != RTYPE_TEXTURE && type != RTYPE_SURFACE) continue;
        if (g_st.textures[stage] == resource) continue;
        Resource *previous = g_st.textures[stage];
        g_st.textures[stage] = resource;
        if (g_dev) ((Resource **)(g_dev + DEV_TEXTURES))[stage] = resource;
        if (debug_frame_active())
            logf("[fp-native-texture] frame %u: stage %u synced queued XBE texture %08x (type %u), previous %p",
                 g_frame_count.load() + 1, stage, address, type, previous);
    }
}

// The alpha of tex0 is the environment-map reflectivity mask of the weapon pixel shader (combiner stage 1 adds
// env map * tex0.a to diffuse * tex0). An override PNG with no real mask (every pixel alpha 255) would turn the
// whole model into a mirror, so its alpha is replaced by this value: 0 = matte ... 255 = full reflection.
constexpr uint8_t kFpOpaqueMaskAlpha = 0;
}

bool fp_arms_texture_override_active() { return g_fp_arms_draw_active; }
bool fp_gun_texture_override_active() { return g_fp_gun_draw_active; }

IDirect3DTexture9 *rt_texture_for(const PixelContainer *tex, uint32_t draw_serial, bool linear); // device.cpp
uint32_t g_draw_serial; // increments per draw (render-target snapshots are shared within a draw)
uint32_t backbuffer_data();
uint32_t depthbuffer_data();
// --debug-frame N[-M]: true while frame N (or any frame up to M) is being built
bool debug_frame_active()
{
    uint32_t f = g_frame_count + 1;
    if (!g_cfg.debug_frame) return false;
    return g_cfg.debug_frame_end ? (f >= g_cfg.debug_frame && f <= g_cfg.debug_frame_end) : f == g_cfg.debug_frame;
}

// ---- enum conversions ----

D3DCMPFUNC conv_cmp(uint32_t v) { return (v >= 0x200 && v <= 0x207) ? (D3DCMPFUNC)(v - 0x200 + 1) : D3DCMP_ALWAYS; }

D3DBLEND conv_blend(uint32_t v)
{
    switch (v) {
    case 0: return D3DBLEND_ZERO;
    case 1: return D3DBLEND_ONE;
    case 0x300: return D3DBLEND_SRCCOLOR;
    case 0x301: return D3DBLEND_INVSRCCOLOR;
    case 0x302: return D3DBLEND_SRCALPHA;
    case 0x303: return D3DBLEND_INVSRCALPHA;
    case 0x304: return D3DBLEND_DESTALPHA;
    case 0x305: return D3DBLEND_INVDESTALPHA;
    case 0x306: return D3DBLEND_DESTCOLOR;
    case 0x307: return D3DBLEND_INVDESTCOLOR;
    case 0x308: return D3DBLEND_SRCALPHASAT;
    case 0x8001: case 0x8003: return D3DBLEND_BLENDFACTOR;
    case 0x8002: case 0x8004: return D3DBLEND_INVBLENDFACTOR;
    default: return D3DBLEND_ONE;
    }
}

D3DBLENDOP conv_blendop(uint32_t v)
{
    switch (v) {
    case 0x800A: return D3DBLENDOP_SUBTRACT;
    case 0x800B: return D3DBLENDOP_REVSUBTRACT;
    case 0x8007: return D3DBLENDOP_MIN;
    case 0x8008: return D3DBLENDOP_MAX;
    default: return D3DBLENDOP_ADD;
    }
}

D3DSTENCILOP conv_stencilop(uint32_t v)
{
    switch (v) {
    case 0: return D3DSTENCILOP_ZERO;
    case 0x1E01: return D3DSTENCILOP_REPLACE;
    case 0x1E02: return D3DSTENCILOP_INCRSAT;
    case 0x1E03: return D3DSTENCILOP_DECRSAT;
    case 0x150A: return D3DSTENCILOP_INVERT;
    case 0x8507: return D3DSTENCILOP_INCR;
    case 0x8508: return D3DSTENCILOP_DECR;
    default: return D3DSTENCILOP_KEEP;
    }
}

D3DTEXTUREOP conv_texop(uint32_t v)
{
    static const D3DTEXTUREOP map[] = {
        D3DTOP_DISABLE, D3DTOP_DISABLE, D3DTOP_SELECTARG1, D3DTOP_SELECTARG2, D3DTOP_MODULATE, D3DTOP_MODULATE2X,
        D3DTOP_MODULATE4X, D3DTOP_ADD, D3DTOP_ADDSIGNED, D3DTOP_ADDSIGNED2X, D3DTOP_SUBTRACT, D3DTOP_ADDSMOOTH,
        D3DTOP_BLENDDIFFUSEALPHA, D3DTOP_BLENDCURRENTALPHA, D3DTOP_BLENDTEXTUREALPHA, D3DTOP_BLENDFACTORALPHA,
        D3DTOP_BLENDTEXTUREALPHAPM, D3DTOP_PREMODULATE, D3DTOP_MODULATEALPHA_ADDCOLOR, D3DTOP_MODULATECOLOR_ADDALPHA,
        D3DTOP_MODULATEINVALPHA_ADDCOLOR, D3DTOP_MODULATEINVCOLOR_ADDALPHA, D3DTOP_DOTPRODUCT3, D3DTOP_MULTIPLYADD,
        D3DTOP_LERP, D3DTOP_BUMPENVMAP, D3DTOP_BUMPENVMAPLUMINANCE};
    return v < sizeof map / sizeof map[0] ? map[v] : D3DTOP_MODULATE;
}

D3DTEXTUREADDRESS conv_address(uint32_t v)
{
    switch (v) {
    case 2: return D3DTADDRESS_MIRROR;
    case 3: case 5: return D3DTADDRESS_CLAMP;
    case 4: return D3DTADDRESS_BORDER;
    default: return D3DTADDRESS_WRAP;
    }
}

DWORD conv_colorwrite(uint32_t v)
{
    DWORD r = 0;
    if (v & 0x00010000) r |= D3DCOLORWRITEENABLE_RED;
    if (v & 0x00000100) r |= D3DCOLORWRITEENABLE_GREEN;
    if (v & 0x00000001) r |= D3DCOLORWRITEENABLE_BLUE;
    if (v & 0x01000000) r |= D3DCOLORWRITEENABLE_ALPHA;
    return r;
}

static D3DCULL conv_cull(uint32_t cull)
{
    if (cull == 0) return D3DCULL_NONE;
    return cull == 0x900 ? D3DCULL_CW : D3DCULL_CCW;
}

// ---- defaults (what the original CreateDevice sets up) ----

static float as_float(uint32_t v)
{
    float f;
    memcpy(&f, &v, 4);
    return f;
}

static uint32_t f2u(float f)
{
    uint32_t v;
    memcpy(&v, &f, 4);
    return v;
}

void init_default_states()
{
    uint32_t *rs = render_state();
    rs[XRS_ZFUNC] = 0x203;
    rs[XRS_ALPHAFUNC] = 0x207;
    rs[XRS_SRCBLEND] = 1;
    rs[XRS_DESTBLEND] = 0;
    rs[XRS_ZWRITEENABLE] = 1;
    rs[XRS_SHADEMODE] = 0x1D01;
    rs[XRS_COLORWRITEENABLE] = 0x01010101;
    rs[XRS_STENCILZFAIL] = rs[XRS_STENCILPASS] = rs[XRS_STENCILFAIL] = 0x1E00;
    rs[XRS_STENCILFUNC] = 0x207;
    rs[XRS_STENCILMASK] = rs[XRS_STENCILWRITEMASK] = 0xFFFFFFFF;
    rs[XRS_BLENDOP] = 0x8006;
    rs[XRS_FOGEND] = f2u(1.0f);
    rs[XRS_FOGDENSITY] = f2u(1.0f);
    rs[XRS_LIGHTING] = 1;
    rs[XRS_LOCALVIEWER] = 1;
    rs[XRS_COLORVERTEX] = 1;
    rs[XRS_SPECULARMATERIALSOURCE] = 2;
    rs[XRS_DIFFUSEMATERIALSOURCE] = 1;
    rs[XRS_POINTSIZE] = f2u(1.0f);
    rs[XRS_FILLMODE] = rs[XRS_BACKFILLMODE] = 0x1B02;
    rs[XRS_ZENABLE] = 1;
    rs[XRS_FRONTFACE] = 0x900;
    rs[XRS_CULLMODE] = 0x901;
    rs[XRS_TEXTUREFACTOR] = 0xFFFFFFFF;
    rs[XRS_MULTISAMPLEMASK] = 0xFFFFFFFF;
    for (int s = 0; s < 4; s++) {
        uint32_t *ts = texture_state(s);
        ts[0] = ts[1] = ts[2] = 1;   // ADDRESSU/V/W = WRAP
        ts[3] = ts[4] = 2;           // MAG/MIN = LINEAR
        ts[5] = 0;                   // MIPFILTER = NONE
        ts[8] = 1;                   // MAXANISOTROPY
        ts[12] = s == 0 ? 4 : 1;     // COLOROP: MODULATE / DISABLE
        ts[14] = 2;                  // COLORARG1 = TEXTURE
        ts[15] = 1;                  // COLORARG2 = CURRENT
        ts[16] = s == 0 ? 2 : 1;     // ALPHAOP: SELECTARG1 / DISABLE
        ts[18] = 2;                  // ALPHAARG1 = TEXTURE
        ts[19] = 1;                  // ALPHAARG2 = CURRENT
        ts[20] = 1;                  // RESULTARG = CURRENT
        ts[28] = (uint32_t)s;        // TEXCOORDINDEX
    }
}

// ---- state application ----

namespace {

uint32_t g_rs_sent[XRS_MAX];
bool g_rs_valid[XRS_MAX];
uint32_t g_ts_sent[4][32];
bool g_ts_valid[4][32];
IDirect3DBaseTexture9 *g_tex_sent[4];

template <typename F> void on_change(uint32_t state, F apply)
{
    uint32_t v = render_state()[state];
    if (g_rs_valid[state] && g_rs_sent[state] == v) return;
    g_rs_valid[state] = true;
    g_rs_sent[state] = v;
    apply(v);
}

void apply_render_states(IDirect3DDevice9 *d)
{
    auto set = [&](D3DRENDERSTATETYPE s, DWORD v) { d->SetRenderState(s, v); };
    on_change(XRS_ZENABLE, [&](uint32_t v) { set(D3DRS_ZENABLE, v); });
    on_change(XRS_ZFUNC, [&](uint32_t v) { set(D3DRS_ZFUNC, conv_cmp(v)); });
    on_change(XRS_ZWRITEENABLE, [&](uint32_t v) { set(D3DRS_ZWRITEENABLE, v != 0); });
    on_change(XRS_ALPHATESTENABLE, [&](uint32_t v) { set(D3DRS_ALPHATESTENABLE, v != 0); });
    on_change(XRS_ALPHAFUNC, [&](uint32_t v) { set(D3DRS_ALPHAFUNC, conv_cmp(v)); });
    on_change(XRS_ALPHAREF, [&](uint32_t v) { set(D3DRS_ALPHAREF, v & 0xFF); });
    on_change(XRS_ALPHABLENDENABLE, [&](uint32_t v) { set(D3DRS_ALPHABLENDENABLE, v != 0); });
    on_change(XRS_SRCBLEND, [&](uint32_t v) { set(D3DRS_SRCBLEND, conv_blend(v)); });
    on_change(XRS_DESTBLEND, [&](uint32_t v) { set(D3DRS_DESTBLEND, conv_blend(v)); });
    on_change(XRS_BLENDOP, [&](uint32_t v) { set(D3DRS_BLENDOP, conv_blendop(v)); });
    on_change(XRS_BLENDCOLOR, [&](uint32_t v) { set(D3DRS_BLENDFACTOR, v); });
    on_change(XRS_DITHERENABLE, [&](uint32_t v) { set(D3DRS_DITHERENABLE, v != 0); });
    on_change(XRS_SHADEMODE, [&](uint32_t v) { set(D3DRS_SHADEMODE, v == 0x1D00 ? D3DSHADE_FLAT : D3DSHADE_GOURAUD); });
    on_change(XRS_COLORWRITEENABLE, [&](uint32_t v) { set(D3DRS_COLORWRITEENABLE, conv_colorwrite(v)); });
    on_change(XRS_STENCILENABLE, [&](uint32_t v) { set(D3DRS_STENCILENABLE, v != 0); });
    on_change(XRS_STENCILFUNC, [&](uint32_t v) { set(D3DRS_STENCILFUNC, conv_cmp(v)); });
    on_change(XRS_STENCILREF, [&](uint32_t v) { set(D3DRS_STENCILREF, v); });
    on_change(XRS_STENCILMASK, [&](uint32_t v) { set(D3DRS_STENCILMASK, v); });
    on_change(XRS_STENCILWRITEMASK, [&](uint32_t v) { set(D3DRS_STENCILWRITEMASK, v); });
    on_change(XRS_STENCILFAIL, [&](uint32_t v) { set(D3DRS_STENCILFAIL, conv_stencilop(v)); });
    on_change(XRS_STENCILZFAIL, [&](uint32_t v) { set(D3DRS_STENCILZFAIL, conv_stencilop(v)); });
    on_change(XRS_STENCILPASS, [&](uint32_t v) { set(D3DRS_STENCILPASS, conv_stencilop(v)); });
    on_change(XRS_CULLMODE, [&](uint32_t v) { set(D3DRS_CULLMODE, conv_cull(v)); });
    on_change(XRS_FILLMODE, [&](uint32_t v) {
        set(D3DRS_FILLMODE, v == 0x1B00 ? D3DFILL_POINT : v == 0x1B01 ? D3DFILL_WIREFRAME : D3DFILL_SOLID);
    });
    on_change(XRS_FOGENABLE, [&](uint32_t v) { set(D3DRS_FOGENABLE, v != 0); });
    on_change(XRS_FOGSTART, [&](uint32_t v) { set(D3DRS_FOGSTART, v); });
    on_change(XRS_FOGEND, [&](uint32_t v) { set(D3DRS_FOGEND, v); });
    on_change(XRS_FOGDENSITY, [&](uint32_t v) { set(D3DRS_FOGDENSITY, v); });
    on_change(XRS_FOGCOLOR, [&](uint32_t v) { set(D3DRS_FOGCOLOR, v); });
    on_change(XRS_RANGEFOGENABLE, [&](uint32_t v) { set(D3DRS_RANGEFOGENABLE, v != 0); });
    on_change(XRS_LIGHTING, [&](uint32_t v) { set(D3DRS_LIGHTING, v != 0); });
    on_change(XRS_SPECULARENABLE, [&](uint32_t v) { set(D3DRS_SPECULARENABLE, v != 0); });
    on_change(XRS_LOCALVIEWER, [&](uint32_t v) { set(D3DRS_LOCALVIEWER, v != 0); });
    on_change(XRS_COLORVERTEX, [&](uint32_t v) { set(D3DRS_COLORVERTEX, v != 0); });
    on_change(XRS_SPECULARMATERIALSOURCE, [&](uint32_t v) { set(D3DRS_SPECULARMATERIALSOURCE, v); });
    on_change(XRS_DIFFUSEMATERIALSOURCE, [&](uint32_t v) { set(D3DRS_DIFFUSEMATERIALSOURCE, v); });
    on_change(XRS_AMBIENTMATERIALSOURCE, [&](uint32_t v) { set(D3DRS_AMBIENTMATERIALSOURCE, v); });
    on_change(XRS_EMISSIVEMATERIALSOURCE, [&](uint32_t v) { set(D3DRS_EMISSIVEMATERIALSOURCE, v); });
    on_change(XRS_AMBIENT, [&](uint32_t v) { set(D3DRS_AMBIENT, v); });
    on_change(XRS_NORMALIZENORMALS, [&](uint32_t v) { set(D3DRS_NORMALIZENORMALS, v != 0); });
    on_change(XRS_TEXTUREFACTOR, [&](uint32_t v) { set(D3DRS_TEXTUREFACTOR, v); });
    on_change(XRS_POINTSIZE, [&](uint32_t v) { set(D3DRS_POINTSIZE, v); });
}

template <typename F> void ts_on_change(int s, int t, F apply)
{
    uint32_t v = texture_state(s)[t];
    if (g_ts_valid[s][t] && g_ts_sent[s][t] == v) return;
    g_ts_valid[s][t] = true;
    g_ts_sent[s][t] = v;
    apply(v);
}

void apply_texture_stages(IDirect3DDevice9 *d, bool fixed_function_pixels)
{
    for (int s = 0; s < 4; s++) {
        IDirect3DBaseTexture9 *t = nullptr;
        if (s == 0 && g_fp_arms_draw_active && g_fp_arms_texture) {
            t = g_fp_arms_texture;
        } else if (s == 0 && g_fp_gun_draw_active && g_fp_gun_texture) {
            t = g_fp_gun_texture;
        } else if (Resource *r = g_st.textures[s]) {
            const uint32_t *ts = texture_state(s); // MAGFILTER 3, MINFILTER 4: 2 = LINEAR and up
            t = rt_texture_for((const PixelContainer *)r, g_draw_serial, ts[3] >= 2 || ts[4] >= 2);
            if (debug_frame_active() && (r->Data == backbuffer_data() || r->Data == depthbuffer_data() || t)) {
                uint32_t w, h, dd, l;
                pixel_container_dims((PixelContainer *)r, &w, &h, &dd, &l);
                logf("[rt] frame %u: stage %d samples %s (texture %p data 0x%08x %ux%u fmt 0x%x)", g_frame_count.load(), s,
                     r->Data == backbuffer_data() ? "the BACK BUFFER" : r->Data == depthbuffer_data() ? "the DEPTH BUFFER" : "a render target",
                     r, r->Data, w, h, (((PixelContainer *)r)->Format >> FMT_FORMAT_SHIFT) & 0xFF);
            }
            if (!t) t = host_texture(r, g_st.palettes[s]);
        }
        // Other paths can change the host D3D binding without going through this cache.
        // Force the first-person replacement onto stage 0 for the matching weapon draw,
        // especially across render-target transitions during weapon animations.
        const bool force_fp_texture = s == 0 && (g_fp_arms_draw_active || g_fp_gun_draw_active);
        if (force_fp_texture || t != g_tex_sent[s]) {
            d->SetTexture(s, t);
            g_tex_sent[s] = t;
        }
        if (force_fp_texture && debug_frame_active()) {
            IDirect3DBaseTexture9 *bound = nullptr;
            HRESULT hr = d->GetTexture(0, &bound);
            logf("[fp-arm-bind] frame %u: requested %p, host-bound %p, match %s, GetTexture hr 0x%08x",
                 g_frame_count.load() + 1, (void *)t, (void *)bound,
                 SUCCEEDED(hr) && bound == t ? "yes" : "no", (uint32_t)hr);
            if (bound) bound->Release();
        }
        ts_on_change(s, 0, [&](uint32_t v) { d->SetSamplerState(s, D3DSAMP_ADDRESSU, conv_address(v)); });
        ts_on_change(s, 1, [&](uint32_t v) { d->SetSamplerState(s, D3DSAMP_ADDRESSV, conv_address(v)); });
        ts_on_change(s, 2, [&](uint32_t v) { d->SetSamplerState(s, D3DSAMP_ADDRESSW, conv_address(v)); });
        ts_on_change(s, 3, [&](uint32_t v) { d->SetSamplerState(s, D3DSAMP_MAGFILTER, v > 3 ? D3DTEXF_LINEAR : v); });
        ts_on_change(s, 4, [&](uint32_t v) { d->SetSamplerState(s, D3DSAMP_MINFILTER, v > 3 ? D3DTEXF_LINEAR : v); });
        ts_on_change(s, 5, [&](uint32_t v) { d->SetSamplerState(s, D3DSAMP_MIPFILTER, v > 2 ? D3DTEXF_LINEAR : v); });
        ts_on_change(s, 6, [&](uint32_t v) { d->SetSamplerState(s, D3DSAMP_MIPMAPLODBIAS, v); });
        ts_on_change(s, 7, [&](uint32_t v) { d->SetSamplerState(s, D3DSAMP_MAXMIPLEVEL, v); });
        ts_on_change(s, 8, [&](uint32_t v) { d->SetSamplerState(s, D3DSAMP_MAXANISOTROPY, v ? v : 1); });
        ts_on_change(s, 29, [&](uint32_t v) { d->SetSamplerState(s, D3DSAMP_BORDERCOLOR, v); });
        if (force_fp_texture) {
            // The override image is a plain mipmapped 0..1 texture. The game's stage-0 sampler state can belong to something else
            // (during the reload / equip animations a render target is on stage 0 with the clamp mode, filter, mip level or
            // mip bias of that pass), which would show the arm as one flat colour. Use sane values in that case only,
            // so the normal poses keep exactly the game's own state.
            const uint32_t *gs = texture_state(0);
            Resource *g0 = g_st.textures[0];
            const bool g0_is_rt = g0 && (resource_type(g0) == RTYPE_TEXTURE || resource_type(g0) == RTYPE_SURFACE) &&
                                  (is_render_target_texture((const PixelContainer *)g0) || ((PixelContainer *)g0)->Size != 0);
            if (debug_frame_active())
                logf("[fp-arm-sampler] frame %u: game stage-0 state addrU %u addrV %u mag %u min %u mip %u lodbias 0x%08x maxmip %u; "
                     "game tex0 is %s -> %s",
                     g_frame_count.load() + 1, gs[0], gs[1], gs[3], gs[4], gs[5], gs[6], gs[7],
                     g0_is_rt ? "a render target / linear texture" : "a normal texture",
                     g0_is_rt ? "forcing wrap, linear, mip bias 0, max mip 0" : "keeping the game's sampler state");
            if (g0_is_rt) {
                d->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
                d->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);
                d->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
                d->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
                d->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
                d->SetSamplerState(0, D3DSAMP_MIPMAPLODBIAS, 0);
                d->SetSamplerState(0, D3DSAMP_MAXMIPLEVEL, 0);
                d->SetSamplerState(0, D3DSAMP_MAXANISOTROPY, 1);
                // the cache must not think the game's values are still on the device
                for (int t : {0, 1, 3, 4, 5, 6, 7, 8}) g_ts_valid[0][t] = false;
            }
        }
        if (!fixed_function_pixels) continue;
        ts_on_change(s, 12, [&](uint32_t v) { d->SetTextureStageState(s, D3DTSS_COLOROP, conv_texop(v)); });
        ts_on_change(s, 13, [&](uint32_t v) { d->SetTextureStageState(s, D3DTSS_COLORARG0, v); });
        ts_on_change(s, 14, [&](uint32_t v) { d->SetTextureStageState(s, D3DTSS_COLORARG1, v); });
        ts_on_change(s, 15, [&](uint32_t v) { d->SetTextureStageState(s, D3DTSS_COLORARG2, v); });
        ts_on_change(s, 16, [&](uint32_t v) { d->SetTextureStageState(s, D3DTSS_ALPHAOP, conv_texop(v)); });
        ts_on_change(s, 17, [&](uint32_t v) { d->SetTextureStageState(s, D3DTSS_ALPHAARG0, v); });
        ts_on_change(s, 18, [&](uint32_t v) { d->SetTextureStageState(s, D3DTSS_ALPHAARG1, v); });
        ts_on_change(s, 19, [&](uint32_t v) { d->SetTextureStageState(s, D3DTSS_ALPHAARG2, v); });
        ts_on_change(s, 20, [&](uint32_t v) { d->SetTextureStageState(s, D3DTSS_RESULTARG, v); });
        ts_on_change(s, 21, [&](uint32_t v) { d->SetTextureStageState(s, D3DTSS_TEXTURETRANSFORMFLAGS, v); });
        ts_on_change(s, 28, [&](uint32_t v) { d->SetTextureStageState(s, D3DTSS_TEXCOORDINDEX, v); });
    }
}

// A pixel shader that failed to translate: approximate with "texture stage 0 modulated by diffuse".
void apply_pixel_shader_fallback(IDirect3DDevice9 *d)
{
    static bool noted;
    if (!noted) {
        noted = true;
        logf("[d3d] note: untranslatable pixel shader drawn as texture x diffuse");
    }
    bool tex = g_tex_sent[0] != nullptr;
    d->SetTextureStageState(0, D3DTSS_COLOROP, tex ? D3DTOP_MODULATE : D3DTOP_SELECTARG2);
    d->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
    d->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
    d->SetTextureStageState(0, D3DTSS_ALPHAOP, tex ? D3DTOP_MODULATE : D3DTOP_SELECTARG2);
    d->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
    d->SetTextureStageState(0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE);
    d->SetTextureStageState(1, D3DTSS_COLOROP, D3DTOP_DISABLE);
    d->SetTextureStageState(1, D3DTSS_ALPHAOP, D3DTOP_DISABLE);
    // the stage-state cache no longer matches what the device has
    for (int s = 0; s < 2; s++)
        for (int t = 12; t < 21; t++) g_ts_valid[s][t] = false;
}

uint32_t fvf_stride(uint32_t fvf)
{
    uint32_t n = 0;
    switch (fvf & D3DFVF_POSITION_MASK) {
    case D3DFVF_XYZ: n = 12; break;
    case D3DFVF_XYZRHW: n = 16; break;
    case D3DFVF_XYZB1: n = 16; break;
    case D3DFVF_XYZB2: n = 20; break;
    case D3DFVF_XYZB3: n = 24; break;
    case D3DFVF_XYZB4: n = 28; break;
    case D3DFVF_XYZB5: n = 32; break;
    }
    if (fvf & D3DFVF_NORMAL) n += 12;
    if (fvf & D3DFVF_PSIZE) n += 4;
    if (fvf & D3DFVF_DIFFUSE) n += 4;
    if (fvf & D3DFVF_SPECULAR) n += 4;
    uint32_t tc = (fvf >> 8) & 0xF;
    for (uint32_t i = 0; i < tc; i++) {
        static const uint32_t sizes[4] = {8, 12, 16, 4};
        n += sizes[(fvf >> (16 + 2 * i)) & 3];
    }
    return n;
}

struct Prim {
    D3DPRIMITIVETYPE type;
    uint32_t count;     // primitives
    bool quads;         // QUADLIST: needs index expansion
};

Prim conv_prim(uint32_t xprim, uint32_t verts)
{
    switch (xprim) {
    case XPT_POINTLIST: return {D3DPT_POINTLIST, verts, false};
    case XPT_LINELIST: return {D3DPT_LINELIST, verts / 2, false};
    case XPT_LINELOOP: case XPT_LINESTRIP: return {D3DPT_LINESTRIP, verts > 1 ? verts - 1 : 0, false};
    case XPT_TRIANGLELIST: return {D3DPT_TRIANGLELIST, verts / 3, false};
    case XPT_TRIANGLESTRIP: case XPT_QUADSTRIP: return {D3DPT_TRIANGLESTRIP, verts > 2 ? verts - 2 : 0, false};
    case XPT_TRIANGLEFAN: case XPT_POLYGON: return {D3DPT_TRIANGLEFAN, verts > 2 ? verts - 2 : 0, false};
    case XPT_QUADLIST: return {D3DPT_TRIANGLELIST, verts / 4 * 2, true};
    default: return {D3DPT_TRIANGLELIST, 0, false};
    }
}

std::vector<uint16_t> g_quad_indices;
std::vector<uint16_t> g_tmp_indices;

const uint16_t *quad_indices(uint32_t quads)
{
    if (g_quad_indices.size() < quads * 6) {
        g_quad_indices.resize(quads * 6);
        for (uint32_t q = 0; q < quads; q++) {
            uint16_t b = (uint16_t)(q * 4);
            uint16_t *p = &g_quad_indices[q * 6];
            p[0] = b; p[1] = b + 1; p[2] = b + 2; p[3] = b; p[4] = b + 2; p[5] = b + 3;
        }
    }
    return g_quad_indices.data();
}

// ---- programmable vertex path: Xbox elements -> one float4 per register ----

// Decode one Xbox D3DVSDT_* element to float4 (missing components default to 0,0,0,1).
void decode_element(uint8_t t, const uint8_t *p, float *o)
{
    o[0] = o[1] = o[2] = 0.0f;
    o[3] = 1.0f;
    uint32_t n = t >> 4;
    auto sext = [](uint32_t v, int bits) { return (int32_t)(v << (32 - bits)) >> (32 - bits); };
    switch (t & 0xF) {
    case 0x2: // FLOATn (0x72 = FLOAT2H: x, y, w)
        if (t == 0x72) {
            memcpy(o, p, 8);
            memcpy(&o[3], p + 8, 4);
        } else if (n >= 1 && n <= 4) {
            memcpy(o, p, n * 4);
        }
        break;
    case 0x0: // D3DCOLOR (ARGB dword) -> RGBA
        if (t == 0x40) {
            uint32_t c;
            memcpy(&c, p, 4);
            o[0] = ((c >> 16) & 255) / 255.0f;
            o[1] = ((c >> 8) & 255) / 255.0f;
            o[2] = (c & 255) / 255.0f;
            o[3] = (c >> 24) / 255.0f;
        }
        break;
    case 0x5: // SHORTn
        for (uint32_t i = 0; i < n; i++) o[i] = (float)((const int16_t *)p)[i];
        break;
    case 0x1: // NORMSHORTn
        for (uint32_t i = 0; i < n; i++) o[i] = ((const int16_t *)p)[i] / 32767.0f;
        break;
    case 0x4: // PBYTEn (unsigned normalized)
        for (uint32_t i = 0; i < n; i++) o[i] = p[i] / 255.0f;
        break;
    case 0x6: { // NORMPACKED3: 11:11:10 signed normalized
        uint32_t v;
        memcpy(&v, p, 4);
        o[0] = sext(v & 0x7FF, 11) / 1023.0f;
        o[1] = sext((v >> 11) & 0x7FF, 11) / 1023.0f;
        o[2] = sext(v >> 22, 10) / 511.0f;
        break;
    }
    }
}

// Decode `count` elements of one type, `sstride` bytes apart, into float4s `ostride` floats apart.
void decode_run(uint8_t t, const uint8_t *p, uint32_t sstride, float *o, uint32_t ostride, uint32_t count)
{
    switch (t) {
    case 0x12: // FLOAT1
        for (uint32_t v = 0; v < count; v++, p += sstride, o += ostride) {
            o[0] = *(const float *)p;
            o[1] = o[2] = 0.0f;
            o[3] = 1.0f;
        }
        return;
    case 0x22: // FLOAT2
        for (uint32_t v = 0; v < count; v++, p += sstride, o += ostride) {
            const float *f = (const float *)p;
            o[0] = f[0];
            o[1] = f[1];
            o[2] = 0.0f;
            o[3] = 1.0f;
        }
        return;
    case 0x32: // FLOAT3
        for (uint32_t v = 0; v < count; v++, p += sstride, o += ostride) {
            const float *f = (const float *)p;
            o[0] = f[0];
            o[1] = f[1];
            o[2] = f[2];
            o[3] = 1.0f;
        }
        return;
    case 0x42: // FLOAT4
        for (uint32_t v = 0; v < count; v++, p += sstride, o += ostride) {
            const float *f = (const float *)p;
            o[0] = f[0];
            o[1] = f[1];
            o[2] = f[2];
            o[3] = f[3];
        }
        return;
    case 0x40: // D3DCOLOR (ARGB) -> RGBA
        for (uint32_t v = 0; v < count; v++, p += sstride, o += ostride) {
            uint32_t c = *(const uint32_t *)p;
            constexpr float k = 1.0f / 255.0f;
            o[0] = ((c >> 16) & 255) * k;
            o[1] = ((c >> 8) & 255) * k;
            o[2] = (c & 255) * k;
            o[3] = (c >> 24) * k;
        }
        return;
    case 0x16: // NORMPACKED3: 11:11:10 signed normalized
        for (uint32_t v = 0; v < count; v++, p += sstride, o += ostride) {
            uint32_t c = *(const uint32_t *)p;
            o[0] = ((int32_t)(c << 21) >> 21) * (1.0f / 1023.0f);
            o[1] = ((int32_t)(c << 10) >> 21) * (1.0f / 1023.0f);
            o[2] = ((int32_t)c >> 22) * (1.0f / 511.0f);
            o[3] = 1.0f;
        }
        return;
    default:
        for (uint32_t v = 0; v < count; v++, p += sstride, o += ostride) decode_element(t, p, o);
    }
}

std::vector<float> g_conv; // only grows: a resize per draw zero-filled it every time
std::unordered_map<const VertexShader *, IDirect3DVertexDeclaration9 *> g_decls;
IDirect3DVertexDeclaration9 *g_decl_imm16; // immediate mode: all 16 attributes

IDirect3DVertexDeclaration9 *decl_for(const VertexShader *vs)
{
    auto it = g_decls.find(vs);
    if (it != g_decls.end()) return it->second;
    D3DVERTEXELEMENT9 el[33];
    uint32_t n = 0, seen = 0;
    for (uint32_t i = 0; i < vs->num_elements; i++) {
        uint8_t reg = vs->elements[i].reg;
        if (seen & (1u << reg)) continue;
        seen |= 1u << reg;
        el[n] = {0, (WORD)(16 * i), D3DDECLTYPE_FLOAT4, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, reg};
        n++;
    }
    el[n] = D3DDECL_END();
    IDirect3DVertexDeclaration9 *d = nullptr;
    if (FAILED(host3d::dev()->CreateVertexDeclaration(el, &d))) logf("[d3d] CreateVertexDeclaration failed for shader %p", vs);
    g_decls[vs] = d;
    return d;
}

IDirect3DVertexDeclaration9 *decl_imm16()
{
    if (!g_decl_imm16) {
        D3DVERTEXELEMENT9 el[17];
        for (BYTE i = 0; i < 16; i++) el[i] = {0, (WORD)(16 * i), D3DDECLTYPE_FLOAT4, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, i};
        el[16] = D3DDECL_END();
        host3d::dev()->CreateVertexDeclaration(el, &g_decl_imm16);
    }
    return g_decl_imm16;
}

// Immediate-mode vertices hold all 16 attribute slots as float4 (256 bytes), but D3D9 vertex strides go up to
// 255: Intel's driver overran its vertex buffer with 256 (a laptop crashed at the start of the first level in
// DrawPrimitiveUP). Draws send only the slots the game wrote or the shader declares, with a declaration per set.
std::unordered_map<uint32_t, IDirect3DVertexDeclaration9 *> g_decl_imm;
std::vector<float> g_imm_pack;

IDirect3DVertexDeclaration9 *decl_imm(uint32_t mask)
{
    IDirect3DVertexDeclaration9 *&d = g_decl_imm[mask];
    if (!d) {
        D3DVERTEXELEMENT9 el[17];
        BYTE n = 0;
        for (BYTE i = 0; i < 16; i++)
            if (mask & (1u << i)) {
                el[n] = {0, (WORD)(16 * n), D3DDECLTYPE_FLOAT4, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, i};
                n++;
            }
        el[n] = D3DDECL_END();
        if (FAILED(host3d::dev()->CreateVertexDeclaration(el, &d))) logf("[d3d] CreateVertexDeclaration failed for immediate mask 0x%x", mask);
    }
    return d;
}

const uint8_t *stream_data(uint32_t stream);

// Convert vertices [first, first+count) of the current streams (or user data for stream 0) for `vs`.
// Returns the stride of the converted vertices (16 bytes per declaration element).
uint32_t convert_vertices(const VertexShader *vs, uint32_t first, uint32_t count, const uint8_t *up, uint32_t up_stride)
{
    perf::Scope perf_scope(perf::kConvert);
    uint32_t ne = vs->num_elements, stride = 16 * ne;
    if (g_conv.size() < (size_t)count * ne * 4) g_conv.resize((size_t)count * ne * 4);
    for (uint32_t e = 0; e < ne; e++) {
        const VertexElement &el = vs->elements[e];
        const uint8_t *base;
        uint32_t s_stride;
        if (up && el.stream == 0) {
            base = up;
            s_stride = up_stride;
        } else {
            base = stream_data(el.stream);
            s_stride = g_st.streams[el.stream].stride ? g_st.streams[el.stream].stride : vs->stream_stride[el.stream];
        }
        float *o = &g_conv[e * 4];
        if (!base) {
            for (uint32_t v = 0; v < count; v++, o += ne * 4) { o[0] = o[1] = o[2] = 0; o[3] = 1; }
            continue;
        }
        decode_run(el.xtype, base + (size_t)first * s_stride + el.offset, s_stride, o, ne * 4, count);
    }
    return stride;
}

// Linear (pitch) textures are addressed with texel coordinates on the NV2A; D3D9 wants 0..1.
void linear_texture_scale(int stage, float *sx, float *sy)
{
    *sx = *sy = 1.0f;
    // The first-person arm/gun override image is a normal 0..1 D3D texture and replaces whatever the game has on stage 0.
    // The game's own stage-0 texture must not decide the UV scale: the arms draw never sets tex0 itself, and during some
    // animations (equip, silencer ...) BLACK leaves a small linear render target there, which scaled every UV by
    // 1/width, 1/height (all UVs ~0 = one corner texel of the image).
    if (stage == 0 && (g_fp_arms_draw_active || g_fp_gun_draw_active)) return;
    Resource *r = g_st.textures[stage];
    if (!r) return;
    auto *pc = (PixelContainer *)r;
    if (resource_type(r) != RTYPE_TEXTURE && resource_type(r) != RTYPE_SURFACE) return;
    if (!pc->Size) return; // swizzled: normalized coordinates
    uint32_t w, h, dd, l;
    pixel_container_dims(pc, &w, &h, &dd, &l);
    *sx = 1.0f / (float)w;
    *sy = 1.0f / (float)h;
}


// ---- diagnostic: find the game's world -> screen matrix in the vertex shader constants --------------------------
// For a few frames (about 15 s, 30 s, 45 s, 60 s after start, once a level is loaded) every draw's constants are searched for
// four consecutive registers that map a world point 10 m in front of the camera, and points 3 m to its right / above, the way
// a view-projection matrix would. Matches are logged as "[probe]" lines. Nothing is changed.
static void probe_projection_matrix()
{
    static uint32_t last_window = 0;
    static int logged = 0;
    if (g_current_level.load() < 0) return;
    const uint32_t f = g_frame_count.load();
    const uint32_t window = f / 900;
    if (window < 1 || window > 4 || f % 900 > 1) return;
    if (window != last_window) { last_window = window; logged = 0; }
    if (logged >= 30) return;
    float rp[8];
    if (!freecam::render_pose(rp)) return;
    const float x = rp[0], y = rp[1], z = rp[2], w = rp[3];
    const float len = sqrtf(x * x + y * y + z * z + w * w);
    if (len < 0.5f || len > 1.5f) return;
    const float q[4] = {x / len, y / len, z / len, w / len};
    const float rt[3] = {-(1 - 2 * (q[1] * q[1] + q[2] * q[2])), -(2 * (q[0] * q[1] + q[3] * q[2])), -(2 * (q[0] * q[2] - q[3] * q[1]))};
    const float up[3] = {2 * (q[0] * q[1] - q[3] * q[2]), 1 - 2 * (q[0] * q[0] + q[2] * q[2]), 2 * (q[1] * q[2] + q[3] * q[0])};
    const float fw[3] = {2 * (q[0] * q[2] + q[3] * q[1]), 2 * (q[1] * q[2] - q[3] * q[0]), 1 - 2 * (q[0] * q[0] + q[1] * q[1])};
    float p[3][4];
    for (int j = 0; j < 3; j++) {
        p[0][j] = rp[4 + j] + fw[j] * 10.0f;
        p[1][j] = p[0][j] + rt[j] * 3.0f;
        p[2][j] = p[0][j] + up[j] * 3.0f;
    }
    p[0][3] = p[1][3] = p[2][3] = 1.0f;
    for (int i = 0; i + 3 < 192 && logged < 30; i++) {
        for (int v = 0; v < 2; v++) {
            float sx[3], sy[3], sw[3];
            bool ok = true;
            for (int k = 0; k < 3 && ok; k++) {
                float o[4];
                for (int c = 0; c < 4; c++) {
                    if (v == 0) {
                        o[c] = 0;
                        for (int j = 0; j < 4; j++) o[c] += g_st.vs_constants[i + c][j] * p[k][j];
                    } else {
                        o[c] = 0;
                        for (int j = 0; j < 4; j++) o[c] += g_st.vs_constants[i + j][c] * p[k][j];
                    }
                }
                sw[k] = o[3];
                if (!(sw[k] > 0.5f)) { ok = false; break; }
                sx[k] = o[0] / sw[k];
                sy[k] = o[1] / sw[k];
            }
            if (!ok || !(sw[0] > 6.0f && sw[0] < 14.0f)) continue;
            const float dx1 = sx[1] - sx[0], dy1 = sy[1] - sy[0], dx2 = sx[2] - sx[0], dy2 = sy[2] - sy[0];
            if (fabsf(dx1) > 1e-3f && fabsf(dy1) < 0.1f * fabsf(dx1) && fabsf(dy2) > 1e-3f && fabsf(dx2) < 0.1f * fabsf(dy2)) {
                logf("[probe] f %u c%d(slot %d) %s: w=%.2f centre=(%.3f,%.3f) 3m right -> (%.3f,%.3f) 3m up -> (%.3f,%.3f)", f, i - 96, i,
                     v ? "cols" : "rows", sw[0], sx[0], sy[0], dx1, dy1, dx2, dy2);
                logged++;
            }
        }
    }
}



// The probe found the game's view-projection matrix in vertex constant slots 10..13 (c-86..c-83), as dp4 rows on world
// positions. Each draw, check that those four registers really map the point 10 m ahead of the camera to the screen centre,
// and if so measure the true half-width / half-height tangents (and the near plane) from where points 3 m to the right /
// above land. The light pass then uses these exact numbers instead of the guessed FOV and aspect.
static void capture_scene_matrix()
{
    float rp[8];
    if (!freecam::render_pose(rp)) return;
    const float len = sqrtf(rp[0] * rp[0] + rp[1] * rp[1] + rp[2] * rp[2] + rp[3] * rp[3]);
    if (len < 0.5f || len > 1.5f) return;
    const float x = rp[0] / len, y = rp[1] / len, z = rp[2] / len, w = rp[3] / len;
    const float rt[3] = {-(1 - 2 * (y * y + z * z)), -(2 * (x * y + w * z)), -(2 * (x * z - w * y))};
    const float up[3] = {2 * (x * y - w * z), 1 - 2 * (x * x + z * z), 2 * (y * z + w * x)};
    const float fw[3] = {2 * (x * z + w * y), 2 * (y * z - w * x), 1 - 2 * (x * x + y * y)};
    float p[3][4], o[3][4];
    for (int j = 0; j < 3; j++) {
        p[0][j] = rp[4 + j] + fw[j] * 10.0f;
        p[1][j] = p[0][j] + rt[j] * 3.0f;
        p[2][j] = p[0][j] + up[j] * 3.0f;
    }
    p[0][3] = p[1][3] = p[2][3] = 1.0f;
    for (int k = 0; k < 3; k++)
        for (int c = 0; c < 4; c++) {
            o[k][c] = 0;
            for (int j = 0; j < 4; j++) o[k][c] += g_st.vs_constants[10 + c][j] * p[k][j];
        }
    if (!(o[0][3] > 6.0f && o[0][3] < 14.0f && o[1][3] > 0.5f && o[2][3] > 0.5f)) return;
    const float x0 = o[0][0] / o[0][3], y0 = o[0][1] / o[0][3];
    if (fabsf(x0) > 0.02f || fabsf(y0) > 0.02f) return;
    const float dx1 = o[1][0] / o[1][3] - x0, dy1 = o[1][1] / o[1][3] - y0;
    const float dx2 = o[2][0] / o[2][3] - x0, dy2 = o[2][1] / o[2][3] - y0;
    if (!(fabsf(dx1) > 1e-3f && fabsf(dy2) > 1e-3f && fabsf(dy1) < 0.1f * fabsf(dx1) && fabsf(dx2) < 0.1f * fabsf(dy2))) return;
    const float th = 3.0f / (o[0][3] * fabsf(dx1)), tv = 3.0f / (o[0][3] * fabsf(dy2));
    if (!(th > 0.2f && th < 3.0f && tv > 0.1f && tv < 3.0f)) return;
    g_scene_tan_h.store(th);
    g_scene_tan_v.store(tv);
    const float nr = (1.0f - o[0][2] / o[0][3]) * o[0][3]; // infinite far plane: z/w = 1 - near / z
    g_scene_near.store((nr > 0.01f && nr < 2.0f) ? nr : 0.0f);
    static bool logged;
    if (!logged) {
        logged = true;
        logf("[scene] projection measured: tan_h %.4f (hfov %.1f) tan_v %.4f (aspect %.3f) near %.3f (z/w %.5f)", th,
             2.0f * atanf(th) * 57.2957795f, tv, th / tv, nr, o[0][2] / o[0][3]);
    }
}

// All 200 registers on every draw (~1.3 ms a frame in busy scenes). Sending only the registers that changed
// since the last upload broke the picture: the device then held values that were never sent to those
// registers (seen with GetVertexShaderConstantF), not explained by the shaders' def constants; not solved yet.
void upload_vs_constants(IDirect3DDevice9 *d)
{
    capture_scene_matrix();
    float saved_skin[kAdsJointCount * 3][4];
    const bool adjust_skin = g_fp_skinning_draw_active && ads_tweak_pose_weight() > 0.0f;
    if (adjust_skin) {
        memcpy(saved_skin, &g_st.vs_constants[60][0], sizeof saved_skin);
        ads_tweak_apply(&g_st.vs_constants[60], kAdsJointCount * 3);
    }
    d->SetVertexShaderConstantF(0, &g_st.vs_constants[0][0], 192);
    if (adjust_skin) memcpy(&g_st.vs_constants[60][0], saved_skin, sizeof saved_skin);
    float k[36] = {};
    host_viewport_transform(k, k + 4);
    for (int s = 0; s < 4; s++) {
        linear_texture_scale(s, &k[8 + s * 4], &k[9 + s * 4]);
        k[10 + s * 4] = k[11 + s * 4] = 1.0f;
    }
    // c198 fog start/end/density, c199 fog-mode weights (linear, exp, exp2, none)
    const uint32_t *rs = render_state();
    memcpy(&k[24], &rs[XRS_FOGSTART], 4);
    memcpy(&k[25], &rs[XRS_FOGEND], 4);
    memcpy(&k[26], &rs[XRS_FOGDENSITY], 4);
    switch (rs[XRS_FOGTABLEMODE]) {
    case D3DFOG_LINEAR: k[28] = 1.0f; break;
    case D3DFOG_EXP: k[29] = 1.0f; break;
    case D3DFOG_EXP2: k[30] = 1.0f; break;
    default: k[31] = 1.0f; break;
    }
    k[32] = k[33] = fov_viewmodel_scale(); // c200: the first-person gun keeps the game's FOV
    k[34] = k[35] = 1.0f;
    d->SetVertexShaderConstantF(192, k, 9);
}

// Fixed-function path: express the same scaling as a texture transform (when the game sets none).
void apply_fvf_texture_scale(IDirect3DDevice9 *d)
{
    for (int s = 0; s < 4; s++) {
        float sx, sy;
        linear_texture_scale(s, &sx, &sy);
        bool scaled = sx != 1.0f || sy != 1.0f;
        if (texture_state(s)[21] != 0) continue; // game uses its own texture transform
        D3DMATRIX m = {};
        m._11 = sx;
        m._22 = sy;
        m._33 = m._44 = 1.0f;
        d->SetTransform((D3DTRANSFORMSTATETYPE)(D3DTS_TEXTURE0 + s), &m);
        d->SetTextureStageState(s, D3DTSS_TEXTURETRANSFORMFLAGS, scaled ? D3DTTFF_COUNT2 : D3DTTFF_DISABLE);
    }
}

enum class Path { None, Fvf, Prog };
struct DrawCtx {
    Path path = Path::None;
    uint32_t fvf = 0;
    VertexShader *vs = nullptr;
};

// --debug-draws N: describe the first N draws (vertex data, constants, key states).
std::atomic<int> g_debug_draws{-1};

struct FirstPersonDrawKey {
    const uint16_t *indices;
    VertexBuffer *vertices;
    bool operator==(const FirstPersonDrawKey &other) const { return indices == other.indices && vertices == other.vertices; }
};
struct FirstPersonDrawKeyHash {
    size_t operator()(const FirstPersonDrawKey &key) const
    {
        return (reinterpret_cast<uintptr_t>(key.indices) >> 4) ^ (reinterpret_cast<uintptr_t>(key.vertices) >> 3);
    }
};
std::unordered_map<FirstPersonDrawKey, Resource *, FirstPersonDrawKeyHash> g_first_person_diffuse;
std::unordered_set<uint64_t> g_first_person_texture_dumps;
std::unordered_set<uint64_t> g_level_texture_dumps;
uint32_t g_level_texture_dump_id = 0;
bool g_texture_manifest_initialized = false;

void dump_bound_level_textures()
{
    if (g_cfg.texture_dump_dir.empty()) return;
    CreateDirectoryW(g_cfg.texture_dump_dir.c_str(), nullptr);
    for (int stage = 0; stage < 4; ++stage) {
        Resource *r = g_st.textures[stage];
        if (!r || !r->Data || r->Data == backbuffer_data() || r->Data == depthbuffer_data() ||
            resource_type(r) == RTYPE_SURFACE) continue;
        auto *pc = (PixelContainer *)r;
        uint32_t w = 0, h = 0, d = 0, levels = 0, pitch = 0;
        pixel_container_dims(pc, &w, &h, &d, &levels);
        texture_level_offset(pc, 0, 0, &pitch, &w, &h);
        if (!w || !h || w > 8192 || h > 8192 || (uint64_t)w * h > 32000000) continue;
        uint32_t fmt = (pc->Format >> FMT_FORMAT_SHIFT) & 0xFF;
        Palette *palette = g_st.palettes[stage];
        uint64_t key = ((uint64_t)(uintptr_t)r >> 4) ^ ((uint64_t)r->Data << 17) ^
                       ((uint64_t)(uintptr_t)palette >> 3) ^ ((uint64_t)fmt << 57) ^ ((uint64_t)w << 32) ^ h;
        if (!g_level_texture_dumps.insert(key).second) continue;
        wchar_t name[160];
        swprintf(name, 160, L"\\tex_%04u_s%d_r%08X_d%08X_%ux%u_f%02X.bmp", ++g_level_texture_dump_id,
                 stage, (uint32_t)(uintptr_t)r, r->Data, w, h, fmt);
        std::wstring path = g_cfg.texture_dump_dir + name;
        if (dump_texture_preview(r, palette, path)) {
            logf("[texture-dump] id %u stage %d resource %p data 0x%08x format 0x%x %ux%u palette %p -> %s",
                 g_level_texture_dump_id, stage, r, r->Data, fmt, w, h, palette, narrow(path).c_str());
            std::wstring manifest = g_cfg.texture_dump_dir + L"\\manifest.csv";
            FILE *csv = nullptr;
            if (!_wfopen_s(&csv, manifest.c_str(), g_texture_manifest_initialized ? L"a" : L"w")) {
                if (!g_texture_manifest_initialized) {
                    fputs("id,stage,resource,data,format,width,height,palette,file\n", csv);
                    g_texture_manifest_initialized = true;
                }
                fprintf(csv, "%u,%d,0x%08X,0x%08X,0x%02X,%u,%u,%p,%ls\n", g_level_texture_dump_id,
                        stage, (uint32_t)(uintptr_t)r, r->Data, fmt, w, h, palette, name + 1);
                fclose(csv);
            }
        } else {
            g_level_texture_dumps.erase(key);
            logf("[texture-dump] could not export texture stage %d resource %p data 0x%08x format 0x%x %ux%u",
                 stage, r, r->Data, fmt, w, h);
        }
    }
}

void dump_first_person_texture(Resource *r, Palette *palette, int stage, uint32_t width, uint32_t height, uint32_t pitch,
                               uint32_t format, size_t bytes)
{
    if (!r || !r->Data || g_cfg.screenshot_dir.empty()) return;
    uint64_t key = ((uint64_t)(uintptr_t)r << 16) ^ (uintptr_t)palette;
    if (!g_first_person_texture_dumps.insert(key).second) return;
    CreateDirectoryW(g_cfg.screenshot_dir.c_str(), nullptr);
    wchar_t name[160];
    swprintf(name, 160, L"\\fp_texture_s%d_r%08X_d%08X.bin", stage, (uint32_t)(uintptr_t)r, r->Data);
    std::wstring path = g_cfg.screenshot_dir + name;
    FILE *fp = nullptr;
    if (!_wfopen_s(&fp, path.c_str(), L"wb")) {
        fwrite(phys_to_virt(r->Data), 1, bytes, fp);
        fclose(fp);
        logf("[fp-texture-dump] stage %d resource %p data 0x%08x format 0x%x size %ux%u pitch %u bytes %zu -> %s",
             stage, r, r->Data, format, width, height, pitch, bytes, narrow(path).c_str());
    }
    if (palette && palette->Data) {
        swprintf(name, 160, L"\\fp_texture_s%d_palette_r%08X_d%08X.bin", stage, (uint32_t)(uintptr_t)palette, palette->Data);
        path = g_cfg.screenshot_dir + name;
        fp = nullptr;
        if (!_wfopen_s(&fp, path.c_str(), L"wb")) {
            fwrite(phys_to_virt(palette->Data), 1, 256 * sizeof(uint32_t), fp);
            fclose(fp);
            logf("[fp-texture-dump] stage %d palette %p data 0x%08x bytes 1024 -> %s", stage, palette, palette->Data,
                 narrow(path).c_str());
        }
    }
}

// The game code above a draw: return addresses into the XBE's game code found on the stack (values right after a
// call instruction), nearest first. A heuristic, like the profiler's: stale values happen.
std::string game_callers(const uint32_t *sp)
{
    const uint32_t *top = (const uint32_t *)((NT_TIB *)NtCurrentTeb())->StackBase;
    std::string out;
    int found = 0;
    for (const uint32_t *p = sp; p < top && p < sp + 0x800 && found < 5; p++) {
        uint32_t v = *p;
        if (v < 0x00011005 || v >= 0x00269000) continue; // game code (.text and the libraries before D3D)
        const uint8_t *c = (const uint8_t *)(uintptr_t)v;
        bool call = c[-5] == 0xE8 || (c[-2] == 0xFF && (c[-1] & 0x38) == 0x10) || (c[-3] == 0xFF && (c[-2] & 0x38) == 0x10) ||
                    (c[-6] == 0xFF && (c[-5] & 0x38) == 0x10);
        if (!call) continue;
        out += (found++ ? " < " : "") + sym_name(v);
    }
    return out;
}

uint32_t debug_sample_hash(const uint8_t *data, size_t bytes)
{
    if (!data || bytes < 4) return 0;
    const uint32_t *words = (const uint32_t *)data;
    uint32_t n = (uint32_t)(bytes / 4), step = n > 8192 ? n / 4096 : 1;
    uint32_t h = 2166136261u;
    for (uint32_t i = 0; i < n; i += step) h = (h ^ words[i]) * 16777619u;
    return h;
}

void debug_draw(const char *what, const DrawCtx &ctx, uint32_t prim, uint32_t count, const float *verts, uint32_t stride_floats,
                const uint16_t *indices = nullptr, uint32_t min_index = 0, uint32_t max_index = 0)
{
    dump_bound_level_textures();
    if (g_debug_draws < 0) g_debug_draws = (int)g_cfg.debug_draws;
    bool this_frame = debug_frame_active();
    if (g_debug_draws <= 0 && !this_frame) return;
    if (!this_frame) g_debug_draws--;
    // Frame ranges normally trace only 2D draws. Include first-person model draws by their
    // specific gun/arm call path, not index count: replacement meshes can change their topology.
    // The first-person model uses two nearby caller paths during weapon actions.
    // Trace both so action/transition draws are not dropped when the call path changes.
    std::string callers;
    bool fp_mesh_range_draw = false;
    if (this_frame && g_cfg.debug_frame_end && !strcmp(what, "DrawIndexedVertices")) {
        callers = game_callers((const uint32_t *)_AddressOfReturnAddress());
        fp_mesh_range_draw = callers.find("0x001ee981") != std::string::npos ||
                             callers.find("0x001eeb30") != std::string::npos;
    }
    if (this_frame && g_cfg.debug_frame_end && !strcmp(what, "DrawIndexedVertices") && !fp_mesh_range_draw) return;
    if (this_frame && g_cfg.debug_frame_end) logf("[draw] --- frame %u", g_frame_count.load() + 1);
    const uint32_t *rs = render_state();
    logf("[draw] %s prim %u count %u, %s 0x%x, ps 0x%x, tex0 %p", what, prim, count, ctx.path == Path::Prog ? "vs" : "fvf",
         g_st.vertex_shader, g_st.pixel_shader, g_st.textures[0]);
    if (fp_mesh_range_draw) logf("[draw]   first-person textures: tex0 %p tex1 %p tex2 %p", g_st.textures[0], g_st.textures[1], g_st.textures[2]);
    if (fp_mesh_range_draw && indices && ctx.vs) {
        logf("[draw]   mesh input: index_data %p count %u min %u max %u hash 0x%08x", indices, count, min_index, max_index,
             debug_sample_hash((const uint8_t *)indices, (size_t)count * sizeof(uint16_t)));
        bool seen_stream[16] = {};
        for (uint32_t i = 0; i < ctx.vs->num_elements; i++) {
            const VertexElement &el = ctx.vs->elements[i];
            if (el.stream >= 16) continue;
            uint32_t stride = g_st.streams[el.stream].stride ? g_st.streams[el.stream].stride : ctx.vs->stream_stride[el.stream];
            const uint8_t *base = stream_data(el.stream);
            VertexBuffer *vb = g_st.streams[el.stream].vb;
            if (!seen_stream[el.stream]) {
                seen_stream[el.stream] = true;
                size_t bytes = stride ? (size_t)(max_index - min_index + 1) * stride : 0;
                logf("[draw]   mesh stream %u: vb %p data 0x%08x stride %u range %u..%u hash 0x%08x", el.stream, vb,
                     vb ? vb->Data : 0, stride, min_index, max_index,
                     base && stride ? debug_sample_hash(base + (size_t)min_index * stride, bytes) : 0);
            }
            logf("[draw]   mesh attr v%u stream %u type 0x%02x offset %u", el.reg, el.stream, el.xtype, el.offset);
        }
        for (int stage = 0; stage < 3; stage++) {
            Resource *r = g_st.textures[stage];
            if (!r || !r->Data) continue;
            auto *pc = (PixelContainer *)r;
            uint32_t pitch = 0, w = 0, h = 0;
            texture_level_offset(pc, 0, 0, &pitch, &w, &h);
            const FormatInfo &fi = format_info((pc->Format >> FMT_FORMAT_SHIFT) & 0xFF);
            size_t bytes = fi.compressed ? (size_t)pitch * ((h + 3) / 4) : (size_t)pitch * h;
            logf("[draw]   texture %d: resource %p data 0x%08x format 0x%x size %ux%u pitch %u hash 0x%08x", stage, r,
                 r->Data, (pc->Format >> FMT_FORMAT_SHIFT) & 0xFF, w, h, pitch,
                 debug_sample_hash((const uint8_t *)phys_to_virt(r->Data), bytes));
            Palette *palette = g_st.palettes[stage];
            if (palette && palette->Data)
                logf("[draw]   palette %d: resource %p data 0x%08x hash 0x%08x", stage, palette, palette->Data,
                     debug_sample_hash((const uint8_t *)phys_to_virt(palette->Data), 256 * sizeof(uint32_t)));
            dump_first_person_texture(r, palette, stage, w, h, pitch, (pc->Format >> FMT_FORMAT_SHIFT) & 0xFF, bytes);
        }
    }
    if (this_frame) {
        if (callers.empty()) callers = game_callers((const uint32_t *)_AddressOfReturnAddress());
        logf("[draw]   from %s", callers.c_str());
    }
    logf("[draw]   z %u func 0x%x write %u | blend %u 0x%x/0x%x op 0x%x | atest %u func 0x%x ref %u | cull 0x%x | cwrite 0x%x | stencil %u",
         rs[XRS_ZENABLE], rs[XRS_ZFUNC], rs[XRS_ZWRITEENABLE], rs[XRS_ALPHABLENDENABLE], rs[XRS_SRCBLEND], rs[XRS_DESTBLEND],
         rs[XRS_BLENDOP], rs[XRS_ALPHATESTENABLE], rs[XRS_ALPHAFUNC], rs[XRS_ALPHAREF], rs[XRS_CULLMODE], rs[XRS_COLORWRITEENABLE],
         rs[XRS_STENCILENABLE]);
    if (g_st.pixel_shader) { // the combiner program as it is in render states 0-56
        uint32_t n = rs[53] & 0xFF;
        logf("[draw]   psh: combiners 0x%x texmodes 0x%x final 0x%08x 0x%08x c0 0x%08x c1 0x%08x fc0 0x%08x fc1 0x%08x", rs[53],
             rs[XRS_PSTEXTUREMODES], rs[8], rs[9], rs[10], rs[18], rs[43], rs[44]);
        for (uint32_t i = 0; i < n && i < 8; i++)
            logf("[draw]   psh stage %u: rgb in 0x%08x out 0x%08x | alpha in 0x%08x out 0x%08x", i, rs[34 + i], rs[45 + i], rs[i], rs[26 + i]);
    }
    if (!g_st.pixel_shader)
        for (int s = 0; s < 2; s++) {
            const uint32_t *ts = texture_state(s);
            logf("[draw]   stage %d: color op %u args 0x%x 0x%x | alpha op %u args 0x%x 0x%x | tfactor 0x%08x", s, ts[12], ts[14], ts[15],
                 ts[16], ts[18], ts[19], rs[XRS_TEXTUREFACTOR]);
        }
    float vp[8];
    viewport_transform(vp, vp + 4);
    logf("[draw]   viewport scale %g %g %g offset %g %g %g; c58 %g %g %g %g; c59 %g %g %g %g", vp[0], vp[1], vp[2], vp[4], vp[5],
         vp[6], g_st.vs_constants[58][0], g_st.vs_constants[58][1], g_st.vs_constants[58][2], g_st.vs_constants[58][3],
         g_st.vs_constants[59][0], g_st.vs_constants[59][1], g_st.vs_constants[59][2], g_st.vs_constants[59][3]);
    if (ctx.path == Path::Prog) {
        for (int c : {96, 97, 190, 191, 0, 1, 2, 3, 10, 11, 12, 13, 18, 21, 22, 23, 24, 25})
            logf("[draw]   c%d (slot %d) = %g %g %g %g", c - 96, c, g_st.vs_constants[c][0], g_st.vs_constants[c][1],
                 g_st.vs_constants[c][2], g_st.vs_constants[c][3]);
        if (fp_mesh_range_draw)
            for (int c = 0; c <= 18; c++)
                logf("[draw]   material c%d = %g %g %g %g", c, g_st.vs_constants[c][0], g_st.vs_constants[c][1],
                     g_st.vs_constants[c][2], g_st.vs_constants[c][3]);
        if (fp_mesh_range_draw)
            for (int c = 60; c <= 191; c++)
                logf("[draw]   skin c%d = %g %g %g %g", c, g_st.vs_constants[c][0], g_st.vs_constants[c][1],
                     g_st.vs_constants[c][2], g_st.vs_constants[c][3]);
    }
    if (verts && stride_floats == 64) // immediate mode: position and texture coordinates (attributes 0, 9-12)
        for (uint32_t v = 0; v < count && v < 4; v++) {
            const float *a = verts + v * 64;
            logf("[draw]   v%u: pos %g %g %g %g | t0 %g %g %g %g | t1 %g %g %g %g | t2 %g %g %g %g", v, a[0], a[1], a[2], a[3], a[36],
                 a[37], a[38], a[39], a[40], a[41], a[42], a[43], a[44], a[45], a[46], a[47]);
        }
    else if (verts)
        for (uint32_t v = 0; v < count && v < 3; v++) {
            std::string s;
            for (uint32_t f = 0; f < stride_floats && f < 16; f++) {
                char b[24];
                snprintf(b, sizeof b, "%s%g", (f && f % 4 == 0) ? " | " : (f ? " " : ""), verts[v * stride_floats + f]);
                s += b;
            }
            logf("[draw]   v%u: %s", v, s.c_str());
        }
}

// Set up state for a draw. Returns false (and counts a skipped draw) if it cannot be drawn.
// The shaders and vertex input last sent to the device. Drivers do not all filter repeats, and Intel's spent
// ~2 ms a frame on them. Fullscreen passes change these and restore them with a state block, so these stay valid.
IDirect3DPixelShader9 *g_ps_sent = (IDirect3DPixelShader9 *)~0u;
IDirect3DVertexShader9 *g_vs_sent = (IDirect3DVertexShader9 *)~0u;
IDirect3DVertexDeclaration9 *g_decl_sent; // null after SetFVF
DWORD g_fvf_sent = ~0u;                   // ~0 after SetVertexDeclaration
DWORD g_fog_table_sent = ~0u;

void set_ps(IDirect3DDevice9 *d, IDirect3DPixelShader9 *ps)
{
    if (ps != g_ps_sent) d->SetPixelShader(g_ps_sent = ps);
}

void set_vs(IDirect3DDevice9 *d, IDirect3DVertexShader9 *vs)
{
    if (vs != g_vs_sent) d->SetVertexShader(g_vs_sent = vs);
}

void set_fvf(IDirect3DDevice9 *d, DWORD fvf)
{
    if (fvf == g_fvf_sent && !g_decl_sent) return;
    d->SetFVF(g_fvf_sent = fvf);
    g_decl_sent = nullptr;
}

void set_decl(IDirect3DDevice9 *d, IDirect3DVertexDeclaration9 *decl)
{
    if (decl == g_decl_sent) return;
    d->SetVertexDeclaration(g_decl_sent = decl);
    g_fvf_sent = ~0u;
}

} // namespace

// After a fullscreen pass: set everything again at the next draw instead of trusting the state block's restore
// (a laptop with Intel graphics crashed in a vertex copy inside D3D9 after the cache was added).
void forget_sent_shaders()
{
    g_ps_sent = (IDirect3DPixelShader9 *)~0u;
    g_vs_sent = (IDirect3DVertexShader9 *)~0u;
    g_decl_sent = nullptr;
    g_fvf_sent = ~0u;
}

void forget_sent_state()
{
    forget_sent_shaders();
    memset(g_rs_valid, 0, sizeof g_rs_valid);
    memset(g_ts_valid, 0, sizeof g_ts_valid);
    for (IDirect3DBaseTexture9 *&t : g_tex_sent) t = nullptr; // Reset unbinds every texture
    g_fog_table_sent = ~0u;
}

namespace {

bool g_ground_draw = false;
int g_fire_rows[4] = {-1, -1, -1, -1}; // constant slots of the fire shader's object->clip matrix (-1 = v0 is world space)
// Finds the 4 DP4 instructions that multiply v0 by a constant matrix into oPos. Slots stay -1 when the shader is not of that form.
void fire_find_matrix(const VertexShader *vs, int rows[4])
{
    rows[0] = rows[1] = rows[2] = rows[3] = -1;
    int mul_reg = -1, mul_const = -1;
    for (uint32_t i = 0; i < vs->program_insts; i++) {
        VshInst in;
        vsh_decode(vs->program + i * 4, in);
        if (in.mac == MAC_NOP && in.ilu == ILU_NOP) { if (in.final) break; continue; }
        if (in.mac == MAC_DP4 && in.out_o_mask && in.out_orb && !in.out_mux && in.out_address == VSH_OPOS && !in.a0x) {
            const bool v0a = in.a.mux == MUX_V && in.v == 0, v0b = in.b.mux == MUX_V && in.v == 0;
            const bool ca = in.a.mux == MUX_C, cb = in.b.mux == MUX_C;
            if ((v0a && cb) || (v0b && ca))
                for (int c = 0; c < 4; c++) if (in.out_o_mask & (8 >> c)) rows[c] = in.cnst;
        }
        // Some particle shaders form clip position with component-wise scale + offset:
        // rN = v0 * cScale; oPos = rN + cOffset.
        if (in.mac == MAC_MUL && in.out_mac_mask == 0xF && !in.a0x && !in.a.neg && !in.b.neg) {
            const bool v0a = in.a.mux == MUX_V && in.v == 0 && in.b.mux == MUX_C;
            const bool v0b = in.b.mux == MUX_V && in.v == 0 && in.a.mux == MUX_C;
            if (v0a || v0b) { mul_reg = in.out_r; mul_const = in.cnst; }
        }
        if (mul_reg >= 0 && in.mac == MAC_ADD && in.out_o_mask == 0xF && in.out_orb && !in.out_mux &&
            in.out_address == VSH_OPOS && !in.a0x && in.a.mux == MUX_R && in.a.reg == mul_reg &&
            in.c.mux == MUX_C && !in.c.neg) {
            rows[0] = -2; rows[1] = mul_const; rows[2] = in.cnst; rows[3] = -2;
            return;
        }
        if (in.final) break;
    }
    if (rows[0] < 0 || rows[1] < 0 || rows[2] < 0 || rows[3] < 0) rows[0] = rows[1] = rows[2] = rows[3] = -1;
}
uint32_t g_fire_hash = 0; // shader hash of the current draw when it is a fire shader (fire_lights.ini), else 0
int g_pos_off = -1; // byte offset of v0 in the converted vertex (float4 per element)
int g_wind_dup = 0, g_wind_cls = 0; // extra copies of the current (tree / light ray / grass) draw, see wind.h
float g_wind_seed = 0.0f; // stable per vegetation draw; breaks identical sway on instanced meshes

uint32_t wind_patch_hash(const uint8_t *base, uint32_t first, uint32_t count, uint32_t stride)
{
    uint32_t h = 2166136261u;
    auto mix = [&](const void *data, size_t bytes) {
        const uint8_t *p = (const uint8_t *)data;
        for (size_t i = 0; i < bytes; ++i) { h ^= p[i]; h *= 16777619u; }
    };
    if (base && count && stride)
        // Use only the first vertex, matching the original stable patch key. Later
        // vertices and transform state can vary with camera/animation updates and
        // would make the wind phase jump while the player moves.
        mix(base + (size_t)first * stride, std::min<size_t>(stride, 16));
    if (g_st.streams[0].vb) mix(&g_st.streams[0].vb->Data, sizeof(g_st.streams[0].vb->Data));
    if (VertexShader *vs = vs_from_handle(g_st.vertex_shader)) mix(&vs->hash, sizeof(vs->hash));
    return h;
}

void set_wind_draw_seed(IDirect3DDevice9 *d, const uint8_t *base, uint32_t first, uint32_t count, uint32_t stride)
{
    if (!d || !g_wind_cls || !base || !count || !stride) return;
    const uint32_t h = wind_patch_hash(base, first, count, stride);
    g_wind_seed = (float)(h >> 8) * (1.0f / 16777216.0f);
    const float e[4] = {0.0f, 0.0f, 0.0f, g_wind_seed};
    d->SetVertexShaderConstantF(205, e, 1);
}

bool begin_draw(DrawCtx &ctx)
{
    IDirect3DDevice9 *d = host3d::dev();
    if (!d) return false;
    g_wind_dup = 0;
    g_wind_cls = 0;
    g_wind_seed = 0.0f;
    g_fire_hash = 0;
    g_ground_draw = false;
    g_draw_serial++;
    apply_render_states(d);
    bool ps = g_st.pixel_shader != 0;
    apply_texture_stages(d, !ps); // may copy a render target (outside the scene) first
    host3d::begin_scene();
    IDirect3DPixelShader9 *hps = ps ? ps_host_shader() : nullptr;
    set_ps(d, hps);
    if (hps) upload_ps_constants(d);
    else if (ps) apply_pixel_shader_fallback(d);
    uint32_t h = g_st.vertex_shader;
    if (vs_is_fvf(h)) {
        if (h) {
            set_vs(d, nullptr);
            set_fvf(d, h);
            apply_fvf_texture_scale(d);
            ctx.path = Path::Fvf;
            ctx.fvf = h;
        }
    } else if (VertexShader *vs = vs_from_handle(h)) {
        // The BLACK HUD aim point uses this material. Keep it for hip-fire, but hide
        // only this draw once the Modern ADS pose has crossed its aiming midpoint.
        // The remaining HUD draws (ammo, health, etc.) use their own shaders/materials.
        if (vs->hash == 0x65D7C245u && g_ads_modern_mode && ads_tweak_pose_weight() >= 0.5f) {
            g_st.draws_skipped++;
            return false;
        }
        if (IDirect3DVertexShader9 *hv = vs_host_shader(vs)) {
            if (wind::blink_hides(vs->hash)) { g_st.draws_skipped++; return false; }
            g_pos_off = -1;
            for (uint32_t i = 0; i < vs->num_elements; i++)
                if (vs->elements[i].reg == 0) { g_pos_off = (int)(16 * i); break; }
            g_ground_draw = vs->is_ground && wind::ground_wanted();
            if (fire_lights::is_fire_shader(vs->hash)) {
                g_fire_hash = vs->hash;
                fire_find_matrix(vs, g_fire_rows);
                static uint32_t logged = 0;
                if (logged != vs->hash) { logged = vs->hash; logf("[fire] shader %08X program:\n%s", vs->hash, vsh_disasm(vs->program, vs->program_insts).c_str()); logf("[fire] shader %08X: object->clip transform (%d %d %d %d; -2 = scale/offset, -1 = none)", vs->hash, g_fire_rows[0], g_fire_rows[1], g_fire_rows[2], g_fire_rows[3]); }
            }
            set_vs(d, hv);
            upload_vs_constants(d);
            {
                const uint32_t *wrs = render_state();
                const bool at = wrs[XRS_ALPHATESTENABLE] != 0, ab = wrs[XRS_ALPHABLENDENABLE] != 0;
                int cls = 0;
                if (vs->wind_active) { // c201..c205: wind for this draw (gate 0 when the draw is not foliage)
                    float wk[20] = {};
                    wind::draw_constants(at, ab, g_fp_skinning_draw_active || g_fp_gun_draw_active || g_fp_arms_draw_active, vs->wind_force, &cls, wk);
                    d->SetVertexShaderConstantF(201, wk, 5);
                }
                if (cls) {
                    g_wind_dup = wind::copies(cls) - 1;
                    g_wind_cls = cls;
                    if (cls == 3) wind::grass_sway_constants(d, &g_st.vs_constants[0][0]);
                }
                wind::scan_note(vs->hash, vs->program_insts, cls, at, ab, vs->wind_active);
            }
            ctx.path = Path::Prog;
            ctx.vs = vs;
        }
    }
    if (ctx.path == Path::None) {
        g_st.draws_skipped++;
        return false;
    }
    // Vertex shaders compute the fog factor themselves (oFog -> table function): D3D9 vertex fog.
    DWORD fog_table = ctx.path == Path::Prog ? D3DFOG_NONE : render_state()[XRS_FOGTABLEMODE];
    if (fog_table != g_fog_table_sent) {
        d->SetRenderState(D3DRS_FOGTABLEMODE, fog_table);
        g_fog_table_sent = fog_table;
    }
    g_st.draws++;
    return true;
}

// Density copies (trees / light rays / grass): re-draw the draw that was just issued, shifted sideways by wind.ini [density]. The shift of a patch comes
// from the bytes of its first vertex, so it is the same every frame (no shimmer) and different from patch to patch. With ground snapping (wind.ini
// [shaders] ground=) the copy is built on the CPU: every vertex moves sideways and then up / down by the ground height difference.
std::vector<uint8_t> g_snap_buf;

struct GrpH { float ymin, h0; };
std::unordered_map<uint64_t, GrpH> g_grp;   // per (x,z) group of the current draw: lowest y and ground height under it
std::unordered_map<uint64_t, float> g_grp_dy;
std::vector<uint64_t> g_vkey;
std::vector<float> g_h0_unused;          // ground height under every ORIGINAL vertex of the current draw (-1e30 = none); computed once per draw, only when a copy needs computing
uint32_t g_dup_frame = 0xFFFFFFFFu, g_dup_all = 0, g_dup_snap = 0; // per-frame budgets (wind.ini [density] copy_cap / snap_budget)

// Snapped copies are cached: grass and ground are static, so the per-vertex height offset of a copy of a patch is computed once and then only re-applied
// (a plain add per vertex) instead of searching the ground triangles every frame. snap_budget limits how many vertices are COMPUTED per frame (cache misses),
// so a new area fills in over a few frames instead of causing one long stall.
struct SnapEntry { std::vector<float> dy; bool complete = false; uint8_t tries = 0; uint32_t last_try = 0; };
std::unordered_map<uint64_t, SnapEntry> g_snap_cache;
int g_snap_cache_level = -2;
size_t g_snap_cache_floats = 0;

template <class F>
void grass_copies_draw(IDirect3DDevice9 *d, const uint8_t *base, uint32_t vfirst, uint32_t vcount, uint32_t stride, F &&issue)
{
    if (g_wind_dup <= 0 || !base || !vcount) return;
    const float zero[4] = {0.0f, 0.0f, 0.0f, g_wind_seed};
    // Anti-lag budgets: every copy re-sends the whole patch, so cap the extra vertices per frame. Later draws get fewer copies instead of stalling the frame.
    const uint32_t frame = g_frame_count.load();
    if (frame != g_dup_frame) { g_dup_frame = frame; g_dup_all = 0; g_dup_snap = 0; }
    int ncopies = g_wind_dup;
    const uint32_t cap = (uint32_t)wind::copy_cap();
    if (cap) {
        const uint32_t room = g_dup_all >= cap ? 0u : cap - g_dup_all;
        ncopies = (int)std::min<uint32_t>((uint32_t)ncopies, room / vcount);
    }
    if (ncopies <= 0) { g_wind_dup = 0; return; }
    g_dup_all += vcount * (uint32_t)ncopies;
    const uint8_t *first = base + (size_t)vfirst * stride;
    // Keep density placement on the original stable first-vertex key. The richer
    // per-draw wind seed includes object state and must never drive copy positions,
    // or the extra grass can jump as that state changes between draws.
    uint32_t h = 2166136261u;
    for (uint32_t i = 0; i < (stride < 16 ? stride : 16); ++i) { h ^= first[i]; h *= 16777619u; }
    const bool snap = wind::ground_wanted() && g_pos_off >= 0 && (uint32_t)g_pos_off + 12 <= stride;
    uint64_t patch_key = 0;
    bool h0_ready = false;
    if (snap) {
        const int lv = g_current_level.load();
        if (lv != g_snap_cache_level) { g_snap_cache_level = lv; g_snap_cache.clear(); g_snap_cache_floats = 0; }
        if (g_snap_cache_floats > 24u * 1024u * 1024u) { g_snap_cache.clear(); g_snap_cache_floats = 0; } // ~96 MB: start over rather than grow forever
        // patch identity: first vertex (16 bytes), last vertex position, vertex count, stride
        patch_key = 1469598103934665603ull;
        auto mix = [&](const void *src, size_t n) { const uint8_t *q = (const uint8_t *)src; for (size_t k = 0; k < n; k++) patch_key = (patch_key ^ q[k]) * 1099511628211ull; };
        mix(first, stride < 16 ? stride : 16);
        mix(first + (size_t)(vcount - 1) * stride + g_pos_off, 12);
        mix(&vcount, 4); mix(&stride, 4);
    }
    for (int i = 1; i <= ncopies; i++) {
        float e[4];
        wind::offset(g_wind_cls, i, h, e);
        e[3] = g_wind_seed;
        const float *dy = nullptr;
        if (snap) {
            SnapEntry &en = g_snap_cache[patch_key * 1099511628211ull + (uint64_t)i * 0x9E3779B97F4A7C15ull];
            const bool fresh = en.dy.size() != vcount;
            const bool retry = !fresh && !en.complete && en.tries < 6 && frame - en.last_try >= 90; // ground may not have been collected yet
            if (fresh || retry) {
                const uint32_t sb = (uint32_t)wind::snap_budget();
                if (!sb || g_dup_snap + vcount <= sb) { // within this frame's compute budget
                    g_dup_snap += vcount;
                    if (!h0_ready) { // ground height under the original vertices does not depend on the copy: look it up once per draw
                        // Vertices that share an x / z (bottom and tip of a grass blade) get ONE ground height, measured from the lowest of them. Looking it up per
                        // vertex from its own height picked a different ground layer for the tips, which stretched the blades upward.
                        g_grp.clear();
                        g_vkey.resize(vcount);
                        for (uint32_t v = 0; v < vcount; v++) {
                            const float *p = (const float *)(first + (size_t)v * stride + g_pos_off);
                            uint32_t xb, zb; memcpy(&xb, &p[0], 4); memcpy(&zb, &p[2], 4);
                            const uint64_t key = ((uint64_t)xb << 32) | zb;
                            g_vkey[v] = key;
                            auto it = g_grp.find(key);
                            if (it == g_grp.end()) g_grp.emplace(key, GrpH{p[1], -1e30f});
                            else if (p[1] < it->second.ymin) it->second.ymin = p[1];
                        }
                        for (auto &kv : g_grp) {
                            float x, z, h0;
                            const uint32_t xb = (uint32_t)(kv.first >> 32), zb = (uint32_t)kv.first;
                            memcpy(&x, &xb, 4); memcpy(&z, &zb, 4);
                            kv.second.h0 = wind::ground_height(x, z, kv.second.ymin, &h0) ? h0 : -1e30f;
                        }
                        h0_ready = true;
                    }
                    if (fresh) g_snap_cache_floats += vcount;
                    en.dy.assign(vcount, 0.0f);
                    bool all = true;
                    g_grp_dy.clear();
                    for (uint32_t v = 0; v < vcount; v++) {
                        const uint64_t key = g_vkey[v];
                        auto f = g_grp_dy.find(key);
                        if (f == g_grp_dy.end()) {
                            float dyv = 0.0f;
                            const float h0 = g_grp[key].h0;
                            if (h0 > -1e29f) {
                                float x, z, h1;
                                const uint32_t xb = (uint32_t)(key >> 32), zb = (uint32_t)key;
                                memcpy(&x, &xb, 4); memcpy(&z, &zb, 4);
                                // search for the copy's ground near the ORIGINAL ground height (not near the vertex height), and ignore jumps (other floors, walls)
                                if (wind::ground_height(x + e[0], z + e[2], h0, &h1) && fabsf(h1 - h0) <= 2.0f) dyv = h1 - h0;
                                else all = false;
                            } else all = false;
                            f = g_grp_dy.emplace(key, dyv).first;
                        }
                        en.dy[v] = f->second;
                    }
                    en.tries++;
                    en.last_try = frame;
                    en.complete = all || en.tries >= 6;
                }
            }
            if (en.dy.size() == vcount) dy = en.dy.data();
        }
        if (dy) {
            g_snap_buf.assign(first, first + (size_t)vcount * stride);
            for (uint32_t v = 0; v < vcount; v++) {
                float *p = (float *)&g_snap_buf[(size_t)v * stride + g_pos_off];
                p[0] += e[0]; p[1] += dy[v]; p[2] += e[2];
            }
            d->SetVertexShaderConstantF(205, zero, 1);
            issue(g_snap_buf.data() - (size_t)vfirst * stride);
        } else {
            d->SetVertexShaderConstantF(205, e, 1); // no snap data (yet): plain sideways copy
            issue(base);
        }
    }
    d->SetVertexShaderConstantF(205, zero, 1);
    g_wind_dup = 0;
}

// Ground collection: the triangles of a ground draw (world space) for the height lookup above. Draws are remembered by a cheap signature.
// `base` is addressed by absolute vertex index, but only vertices [vfirst, nverts) exist in memory (indexed draws convert just their min..max range),
// so nothing below vfirst may be read.
void ground_ingest(const uint8_t *base, uint32_t stride, uint32_t type, uint32_t tris, const uint16_t *idx, uint32_t nverts, uint32_t vfirst = 0)
{
    if (vfirst >= nverts) return;
    if (g_pos_off < 0 || (uint32_t)g_pos_off + 12 > stride || !tris || !nverts) return;
    auto vtx = [&](uint32_t i) { return (const float *)(base + (size_t)i * stride + g_pos_off); };
    uint64_t sig = 1469598103934665603ull ^ ((uint64_t)nverts << 20) ^ tris;
    for (uint32_t k = 0; k < 4; k++) {
        const float *p = vtx(k == 3 ? nverts - 1 : vfirst + ((nverts - vfirst) * k) / 3);
        for (int j = 0; j < 3; j++) { uint32_t u; memcpy(&u, p + j, 4); sig = (sig ^ u) * 1099511628211ull; }
    }
    if (wind::ground_seen_draw(sig)) return;
    for (uint32_t t = 0; t < tris; t++) {
        uint32_t i0, i1, i2;
        if (type == D3DPT_TRIANGLESTRIP) { i0 = t; i1 = t + 1; i2 = t + 2; }
        else if (type == D3DPT_TRIANGLEFAN) { i0 = 0; i1 = t + 1; i2 = t + 2; }
        else { i0 = t * 3; i1 = t * 3 + 1; i2 = t * 3 + 2; }
        if (idx) { i0 = idx[i0]; i1 = idx[i1]; i2 = idx[i2]; }
        if (i0 >= nverts || i1 >= nverts || i2 >= nverts || i0 < vfirst || i1 < vfirst || i2 < vfirst) continue;
        wind::ground_add_tri(vtx(i0), vtx(i1), vtx(i2));
    }
}

void draw_up(uint32_t xprim, uint32_t verts, const void *data, uint32_t stride)
{
    Prim p = conv_prim(xprim, verts);
    if (!p.count) return;
    perf::add_draw(verts, verts * stride);
    IDirect3DDevice9 *d = host3d::dev();
    auto issue = [&](const void *vd) {
        if (p.quads)
            d->DrawIndexedPrimitiveUP(p.type, 0, verts, p.count, quad_indices(verts / 4), D3DFMT_INDEX16, vd, stride);
        else
            d->DrawPrimitiveUP(p.type, p.count, vd, stride);
    };
    set_wind_draw_seed(d, (const uint8_t *)data, 0, verts, stride);
    issue(data);
    grass_copies_draw(d, (const uint8_t *)data, 0, verts, stride, issue);
    if (g_fire_hash) fire_lights::ingest(g_fire_hash, (const uint8_t *)data, stride, g_pos_off, verts, g_st.vs_constants, g_fire_rows);
    if (g_ground_draw) ground_ingest((const uint8_t *)data, stride, p.type, p.count, p.quads ? quad_indices(verts / 4) : nullptr, verts);
}

void draw_indexed_up(uint32_t xprim, uint32_t nidx, const uint16_t *idx, const void *verts, uint32_t stride)
{
    if (!nidx) return;
    uint32_t mn = 0xFFFF, mx = 0;
    for (uint32_t i = 0; i < nidx; i++) {
        if (idx[i] < mn) mn = idx[i];
        if (idx[i] > mx) mx = idx[i];
    }
    Prim p = conv_prim(xprim, nidx);
    if (!p.count) return;
    perf::add_draw(mx - mn + 1, (mx - mn + 1) * stride);
    if (p.quads) {
        g_tmp_indices.resize(p.count * 3);
        for (uint32_t q = 0; q < nidx / 4; q++) {
            const uint16_t *s = idx + q * 4;
            uint16_t *o = &g_tmp_indices[q * 6];
            o[0] = s[0]; o[1] = s[1]; o[2] = s[2]; o[3] = s[0]; o[4] = s[2]; o[5] = s[3];
        }
        idx = g_tmp_indices.data();
    }
    IDirect3DDevice9 *d = host3d::dev();
    auto issue = [&](const void *vd) { d->DrawIndexedPrimitiveUP(p.type, mn, mx - mn + 1, p.count, idx, D3DFMT_INDEX16, vd, stride); };
    set_wind_draw_seed(d, (const uint8_t *)verts, mn, mx - mn + 1, stride);
    issue(verts);
    grass_copies_draw(d, (const uint8_t *)verts, mn, mx - mn + 1, stride, issue);
    if (g_fire_hash) fire_lights::ingest(g_fire_hash, (const uint8_t *)verts + (size_t)mn * stride, stride, g_pos_off, mx - mn + 1, g_st.vs_constants, g_fire_rows);
    if (g_ground_draw) ground_ingest((const uint8_t *)verts, stride, p.type, p.count, idx, mx + 1, mn);
}

const uint8_t *stream_data(uint32_t stream)
{
    VertexBuffer *vb = g_st.streams[stream].vb;
    return vb ? (const uint8_t *)phys_to_virt(vb->Data) : nullptr;
}

} // namespace

// Pre-transformed (XYZRHW) vertices carry Xbox screen pixels, but host render targets are scale_x/y() times
// larger: copy vertices [first, first+count) with x/y scaled. Returns a pointer usable with the original
// indices (the copy offset by -first vertices); other paths get `data` back unchanged.
std::vector<uint8_t> g_rhw;
const uint8_t *scale_rhw(const DrawCtx &ctx, const void *data, uint32_t first, uint32_t count, uint32_t stride)
{
    auto *src = (const uint8_t *)data;
    float sx = target_scale_x(), sy = target_scale_y();
    if (ctx.path != Path::Fvf || (ctx.fvf & D3DFVF_POSITION_MASK) != D3DFVF_XYZRHW || (sx == 1 && sy == 1) || !src) return src;
    perf::Scope perf_scope(perf::kConvert);
    g_rhw.assign(src + (size_t)first * stride, src + (size_t)(first + count) * stride);
    for (uint32_t v = 0; v < count; v++) {
        float *p = (float *)&g_rhw[(size_t)v * stride];
        p[0] *= sx;
        p[1] *= sy;
    }
    return g_rhw.data() - (size_t)first * stride;
}

// ---- HLE draw functions ----

void __stdcall D3DDevice_DrawVerticesUP(uint32_t PrimitiveType, uint32_t VertexCount, const void *pVertexStreamZeroData,
                                        uint32_t VertexStreamZeroStride)
{
    DTRACE("%u, %u, %p, %u", PrimitiveType, VertexCount, pVertexStreamZeroData, VertexStreamZeroStride);
    pb_flush();
    perf::Scope perf_scope(perf::kDraw);
    DrawCtx ctx;
    if (!begin_draw(ctx)) return;
    if (ctx.path == Path::Prog) {
        uint32_t stride = convert_vertices(ctx.vs, 0, VertexCount, (const uint8_t *)pVertexStreamZeroData, VertexStreamZeroStride);
        debug_draw("DrawVerticesUP", ctx, PrimitiveType, VertexCount, g_conv.data(), stride / 4);
        set_decl(host3d::dev(), decl_for(ctx.vs));
        draw_up(PrimitiveType, VertexCount, g_conv.data(), stride);
        return;
    }
    debug_draw("DrawVerticesUP", ctx, PrimitiveType, VertexCount, (const float *)pVertexStreamZeroData, VertexStreamZeroStride / 4);
    draw_up(PrimitiveType, VertexCount, scale_rhw(ctx, pVertexStreamZeroData, 0, VertexCount, VertexStreamZeroStride),
            VertexStreamZeroStride);
}

void __stdcall D3DDevice_DrawVertices(uint32_t PrimitiveType, uint32_t StartVertex, uint32_t VertexCount)
{
    DTRACE("%u, %u, %u", PrimitiveType, StartVertex, VertexCount);
    pb_flush();
    perf::Scope perf_scope(perf::kDraw);
    DrawCtx ctx;
    if (!begin_draw(ctx)) return;
    if (ctx.path == Path::Prog) {
        uint32_t stride = convert_vertices(ctx.vs, StartVertex, VertexCount, nullptr, 0);
        debug_draw("DrawVertices", ctx, PrimitiveType, VertexCount, g_conv.data(), stride / 4);
        set_decl(host3d::dev(), decl_for(ctx.vs));
        draw_up(PrimitiveType, VertexCount, g_conv.data(), stride);
        return;
    }
    debug_draw("DrawVertices", ctx, PrimitiveType, VertexCount, nullptr, 0);
    const uint8_t *base = stream_data(0);
    uint32_t stride = g_st.streams[0].stride;
    if (!base || !stride) return;
    draw_up(PrimitiveType, VertexCount, scale_rhw(ctx, base, StartVertex, VertexCount, stride) + (size_t)StartVertex * stride, stride);
}

// --debug-frame: for indexed draws whose declaration has a packed normal (NORMPACKED3), write indices,
// positions and the raw normal dwords to a CSV, to check the normal decoding against the geometry.
void dump_packed_normal_geometry(const VertexShader *vs, uint32_t prim, uint32_t count, const uint16_t *idx, uint32_t mn, uint32_t mx)
{
    const VertexElement *pos = nullptr, *nrm = nullptr;
    for (uint32_t i = 0; i < vs->num_elements; i++) {
        if (vs->elements[i].reg == 0) pos = &vs->elements[i];
        if (vs->elements[i].xtype == 0x16) nrm = &vs->elements[i];
    }
    if (!pos || !nrm || pos->xtype != 0x32 || g_cfg.screenshot_dir.empty()) return;
    char name[64];
    snprintf(name, sizeof name, "\\f%u_d%u_geom.csv", g_frame_count.load() + 1, g_draw_serial);
    FILE *f = _wfopen((g_cfg.screenshot_dir + widen(name)).c_str(), L"w");
    if (!f) return;
    fprintf(f, "prim,%u\n", prim);
    for (uint32_t i = 0; i < count && i < 3000; i++) fprintf(f, "i,%u\n", idx[i]);
    auto data = [&](const VertexElement *e) {
        const uint8_t *b = stream_data(e->stream);
        uint32_t st = g_st.streams[e->stream].stride ? g_st.streams[e->stream].stride : vs->stream_stride[e->stream];
        return std::make_pair(b, st);
    };
    auto [pb, ps] = data(pos);
    auto [nb, ns] = data(nrm);
    if (pb && nb)
        for (uint32_t v = mn; v <= mx && v < mn + 4000; v++) {
            float p[3];
            uint32_t n;
            memcpy(p, pb + (size_t)v * ps + pos->offset, 12);
            memcpy(&n, nb + (size_t)v * ns + nrm->offset, 4);
            fprintf(f, "v,%u,%g,%g,%g,0x%08x\n", v, p[0], p[1], p[2], n);
        }
    fclose(f);
}

IDirect3DTexture9 *load_fp_texture(const std::wstring &configured_path, IDirect3DTexture9 *&texture, bool &load_attempted,
                                   const char *label)
{
    if (texture || load_attempted || configured_path.empty()) return texture;
    load_attempted = true;
    std::vector<uint32_t> pixels;
    uint32_t width = 0, height = 0;
    const std::string path = narrow(configured_path);
    if (!armory_img::load_png(path, pixels, width, height) || !width || !height) {
        logf("[%s] failed to load image: %s", label, path.c_str());
        return nullptr;
    }
    if (pixels.size() < (size_t)width * height) {
        logf("[%s] image %s returned %zu pixels for %ux%u", label, path.c_str(), pixels.size(), width, height);
        return nullptr;
    }
    // Pixels are A8R8G8B8 (0xAARRGGBB). Keep an authored alpha mask; replace a fully opaque one (see kFpOpaqueMaskAlpha).
    bool opaque = true;
    for (size_t i = 0; i < (size_t)width * height; ++i)
        if ((pixels[i] >> 24) != 0xFF) { opaque = false; break; }
    if (opaque) {
        for (size_t i = 0; i < (size_t)width * height; ++i)
            pixels[i] = (pixels[i] & 0x00FFFFFFu) | ((uint32_t)kFpOpaqueMaskAlpha << 24);
        logf("[%s] image has no alpha mask (fully opaque): reflection mask alpha set to %u", label, (unsigned)kFpOpaqueMaskAlpha);
    } else {
        logf("[%s] image alpha is used as the environment-map reflection mask", label);
    }
    IDirect3DTexture9 *created_texture = nullptr;
    IDirect3DDevice9 *device = host3d::dev();
    if (!device || FAILED(device->CreateTexture(width, height, 1, 0, D3DFMT_A8R8G8B8, D3DPOOL_MANAGED, &created_texture, nullptr))) {
        logf("[%s] failed to create %ux%u texture from %s", label, width, height, path.c_str());
        return nullptr;
    }
    D3DLOCKED_RECT lock = {};
    if (FAILED(created_texture->LockRect(0, &lock, nullptr, 0))) {
        created_texture->Release();
        logf("[%s] failed to lock texture for %s", label, path.c_str());
        return nullptr;
    }
    const size_t row_bytes = (size_t)width * sizeof(uint32_t);
    for (uint32_t y = 0; y < height; ++y)
        memcpy((uint8_t *)lock.pBits + (size_t)y * lock.Pitch, pixels.data() + (size_t)y * width, row_bytes);
    created_texture->UnlockRect(0);
    texture = created_texture;
    logf("[%s] loaded %s (%ux%u)", label, path.c_str(), width, height);
    return texture;
}

void __stdcall D3DDevice_DrawIndexedVertices(uint32_t PrimitiveType, uint32_t VertexCount, const uint16_t *pIndexData)
{
    DTRACE("%u, %u, %p", PrimitiveType, VertexCount, pIndexData);
    pb_flush();
    perf::Scope perf_scope(perf::kDraw);
    struct RestoreFpSkinningFlag {
        bool previous = g_fp_skinning_draw_active;
        ~RestoreFpSkinningFlag() { g_fp_skinning_draw_active = previous; }
    } restore_fp_skinning_flag;

    // During some weapon animations BLACK binds a low-resolution render target as tex0 for
    // the first-person mesh. Keep the last real diffuse texture per mesh and use it for that draw.
    // The mesh key includes both index and vertex buffers so different weapons keep their materials.
    struct RestoreTexture0 {
        Resource *saved = nullptr;
        Resource **device_stage = nullptr;
        Resource *saved_device = nullptr;
        bool changed = false;
        ~RestoreTexture0() {
            if (!changed) return;
            g_st.textures[0] = saved;
            if (device_stage) *device_stage = saved_device;
        }
    } restore_tex0{g_st.textures[0], nullptr, nullptr, false};
    struct RestoreArmOverride {
        bool active = false;
        ~RestoreArmOverride() { if (active) g_fp_arms_draw_active = false; }
    } restore_arm_override{};
    struct RestoreGunOverride {
        bool active = false;
        ~RestoreGunOverride() { if (active) g_fp_gun_draw_active = false; }
    } restore_gun_override{};
    VertexShader *draw_vs = vs_from_handle(g_st.vertex_shader);
    bool skinned_mesh = false;
    if (draw_vs) {
        bool weights = false, bone_indices = false, uv = false;
        for (uint32_t i = 0; i < draw_vs->num_elements; i++) {
            const VertexElement &el = draw_vs->elements[i];
            weights |= el.reg == 1 && el.xtype == 0x44;
            bone_indices |= el.reg == 4 && el.xtype == 0x45;
            uv |= el.reg == 9 && el.xtype == 0x22;
        }
        skinned_mesh = weights && bone_indices && uv;
    }
    if (pIndexData && skinned_mesh) {
        std::string callers = game_callers((const uint32_t *)_AddressOfReturnAddress());
        bool fp_path = callers.find("0x001ee981") != std::string::npos || callers.find("0x001eeb30") != std::string::npos;
        if (fp_path) {
            g_fp_skinning_draw_active = true;
            sync_first_person_material_textures();
            // Which part of the weapon's draw group is this? A new frame, or the first mesh of the group again
            // (the queue is rendered more than once per frame), starts the count over.
            uint32_t part;
            {
                const uint32_t frame = g_frame_count.load();
                if (frame != g_fp_part_frame || pIndexData == g_fp_part_first_indices) {
                    g_fp_part_ordinal = 0;
                    g_fp_part_first_indices = pIndexData;
                    g_fp_part_frame = frame;
                } else {
                    g_fp_part_ordinal++;
                }
            // Group record order differs between weapons. The original DBs place arms at vertex slot 0;
            // the weapon mesh starts after that range. This survives mesh index-count changes.
            uint16_t min_index = 0xFFFF;
            for (uint32_t i = 0; i < VertexCount; ++i)
                if (pIndexData[i] < min_index) min_index = pIndexData[i];
            part = min_index == 0 ? kFpPartArms : kFpPartGun;
            }
            if (debug_frame_active())
                logf("[fp-part] frame %u: draw of %u indices, index data %p, vb %p is part %u, game tex0 %p", g_frame_count.load() + 1,
                     VertexCount, pIndexData, g_st.streams[0].vb, part, g_st.textures[0]);
            // The type-4 skinned model's stage 0 can resolve to a stale level atlas even
            // though the same first-person render path binds the active weapon's WDD
            // texture on its rigid weapon draw. Reuse that resource on part 0. The
            // source is recognized by its XBE render path, never by an index count.
            if (part == kFpPartGun) {
                g_fp_current_gun_indices = pIndexData;
                g_fp_current_gun_vertices = g_st.streams[0].vb;
            }
            if (part == kFpPartGun && g_fp_native_gun_texture &&
                g_fp_native_gun_indices == pIndexData && g_fp_native_gun_vertices == g_st.streams[0].vb &&
                (resource_type(g_fp_native_gun_texture) == RTYPE_TEXTURE || resource_type(g_fp_native_gun_texture) == RTYPE_SURFACE) &&
                !is_render_target_texture((const PixelContainer *)g_fp_native_gun_texture)) {
                restore_tex0.device_stage = g_dev ? (Resource **)(g_dev + DEV_TEXTURES) : nullptr;
                restore_tex0.saved_device = restore_tex0.device_stage ? *restore_tex0.device_stage : nullptr;
                g_st.textures[0] = g_fp_native_gun_texture;
                if (restore_tex0.device_stage) *restore_tex0.device_stage = g_fp_native_gun_texture;
                restore_tex0.changed = true;
                if (debug_frame_active())
                    logf("[fp-native-gun-fix] frame %u: part 0 mesh %p/%p uses its captured WDD texture %p instead of queued material tex0 %p",
                         g_frame_count.load() + 1, pIndexData, g_st.streams[0].vb, g_fp_native_gun_texture, restore_tex0.saved);
            }
            if (part == kFpPartArms && !g_cfg.fp_arms_texture.empty()) {
                if (load_fp_texture(g_cfg.fp_arms_texture, g_fp_arms_texture, g_fp_arms_texture_load_attempted, "fp-arm-texture")) {
                    g_fp_arms_draw_active = true;
                    restore_arm_override.active = true;
                    if (debug_frame_active()) {
                        logf("[fp-arm-texture] frame %u: applying arm image to draw count %u, index data %p, stream %p",
                             g_frame_count.load() + 1, VertexCount, pIndexData, g_st.streams[0].vb);
                        if (Resource *t0 = g_st.textures[0]) {
                            auto *pc0 = (PixelContainer *)t0;
                            uint32_t w0 = 0, h0 = 0, d0 = 0, l0 = 0;
                            if (resource_type(t0) == RTYPE_TEXTURE || resource_type(t0) == RTYPE_SURFACE) pixel_container_dims(pc0, &w0, &h0, &d0, &l0);
                            logf("[fp-arm-texture]   game tex0 %p is %ux%u, %s%s (its 1/size scale is NOT applied to the arm image)", t0, w0, h0,
                                 pc0->Size ? "linear" : "swizzled", is_render_target_texture(pc0) ? ", render target" : "");
                        }
                    }
                }
            }
            if (!g_fp_arms_draw_active && part == kFpPartGun && !g_cfg.fp_gun_texture.empty()) {
                if (load_fp_texture(g_cfg.fp_gun_texture, g_fp_gun_texture, g_fp_gun_texture_load_attempted, "fp-gun-texture")) {
                    g_fp_gun_draw_active = true;
                    restore_gun_override.active = true;
                    if (debug_frame_active())
                        logf("[fp-gun-texture] frame %u: applying gun image to draw count %u, index data %p, stream %p",
                             g_frame_count.load() + 1, VertexCount, pIndexData, g_st.streams[0].vb);
                }
            }
            FirstPersonDrawKey key{pIndexData, g_st.streams[0].vb};
            Resource *texture = g_st.textures[0];
            auto cached = g_first_person_diffuse.find(key);
            if (!g_fp_arms_draw_active && texture && !is_render_target_texture((const PixelContainer *)texture)) {
                g_first_person_diffuse[key] = texture;
            } else if (!g_fp_arms_draw_active && texture && cached != g_first_person_diffuse.end()) {
                g_st.textures[0] = cached->second;
                restore_tex0.changed = true;
                if (debug_frame_active())
                    logf("[fp-material-fix] frame %u: mesh indices %p vertex buffer %p replaced render-target tex0 %p with cached diffuse %p",
                         g_frame_count.load() + 1, pIndexData, g_st.streams[0].vb, texture, cached->second);
            } else if (!g_fp_arms_draw_active && texture && debug_frame_active()) {
                logf("[fp-material-fix] frame %u: render-target tex0 %p on mesh indices %p vertex buffer %p, no cached diffuse yet",
                     g_frame_count.load() + 1, texture, pIndexData, g_st.streams[0].vb);
            }
        }
    }

    // In the same weapon-render path, BLACK draws a rigid weapon sub-part after the
    // skinned gun/arms pair. Its stage-0 resource is the texture loaded from the active
    // weapon's .wdd. Save it for the next frame's part-0 draw (the ordering is gun,
    // arms, rigid sub-part). Restrict stack inspection to that immediately-following
    // non-skinned indexed draw so ordinary level geometry doesn't become the candidate.
    if (pIndexData && !skinned_mesh) {
        Resource *candidate = g_st.textures[0];
        const std::string callers = game_callers((const uint32_t *)_AddressOfReturnAddress());
        const bool wdd_caller = callers.find("0x0016ec6f") != std::string::npos;
        const bool fp_caller = callers.find("0x001ee981") != std::string::npos || callers.find("0x001eeb30") != std::string::npos;
        if (debug_frame_active() && (wdd_caller || fp_caller)) {
            logf("[fp-native-gun-probe] frame %u: ordinal %u (arms=%u), candidate %p type %u, render-target %u, caller WDD %u FP %u; mesh %p/%p",
                 g_frame_count.load() + 1, g_fp_part_ordinal, kFpPartArms, candidate,
                 candidate ? resource_type(candidate) : 0u,
                 candidate ? (unsigned)is_render_target_texture((const PixelContainer *)candidate) : 0u,
                 (unsigned)wdd_caller, (unsigned)fp_caller, g_fp_current_gun_indices, g_fp_current_gun_vertices);
        }
        if (g_fp_part_frame == g_frame_count.load() && g_fp_part_ordinal == kFpLastSkinnedPartOrdinal &&
            candidate && (resource_type(candidate) == RTYPE_TEXTURE || resource_type(candidate) == RTYPE_SURFACE) &&
            !is_render_target_texture((const PixelContainer *)candidate)) {
            if (wdd_caller && fp_caller) {
                g_fp_native_gun_texture = candidate;
                g_fp_native_gun_indices = g_fp_current_gun_indices;
                g_fp_native_gun_vertices = g_fp_current_gun_vertices;
                if (debug_frame_active())
                    logf("[fp-native-gun-source] frame %u: captured weapon WDD texture %p for mesh %p/%p next frame",
                         g_frame_count.load() + 1, candidate, g_fp_native_gun_indices, g_fp_native_gun_vertices);
            }
        }
    }

    DrawCtx ctx;
    if (!begin_draw(ctx) || !pIndexData || !VertexCount) return;
    if (ctx.path == Path::Prog) {
        uint32_t mn = 0xFFFF, mx = 0;
        for (uint32_t i = 0; i < VertexCount; i++) {
            if (pIndexData[i] < mn) mn = pIndexData[i];
            if (pIndexData[i] > mx) mx = pIndexData[i];
        }
        uint32_t stride = convert_vertices(ctx.vs, mn, mx - mn + 1, nullptr, 0);
        debug_draw("DrawIndexedVertices", ctx, PrimitiveType, VertexCount, g_conv.data(), stride / 4, pIndexData, mn, mx);
        if (debug_frame_active() && !g_cfg.debug_frame_end) // single debug frames only (ranges stay fast)
            dump_packed_normal_geometry(ctx.vs, PrimitiveType, VertexCount, pIndexData, mn, mx);
        set_decl(host3d::dev(), decl_for(ctx.vs));
        // indices refer to vertex 0: point the data "mn vertices before" the converted block
        draw_indexed_up(PrimitiveType, VertexCount, pIndexData, (const uint8_t *)g_conv.data() - (size_t)mn * stride, stride);
        return;
    }
    const uint8_t *base = stream_data(0);
    uint32_t stride = g_st.streams[0].stride;
    if (!base || !stride) return;
    if (ctx.path == Path::Fvf && (ctx.fvf & D3DFVF_POSITION_MASK) == D3DFVF_XYZRHW) {
        uint32_t mn = 0xFFFF, mx = 0;
        for (uint32_t i = 0; i < VertexCount; i++) {
            mn = pIndexData[i] < mn ? pIndexData[i] : mn;
            mx = pIndexData[i] > mx ? pIndexData[i] : mx;
        }
        base = scale_rhw(ctx, base, mn, mx - mn + 1, stride);
    }
    draw_indexed_up(PrimitiveType, VertexCount, pIndexData, base, stride);
}

// ---- push-buffer draws (immediate mode / inline arrays) ----

void draw_immediate(uint32_t prim, const float *verts, uint32_t count, uint32_t attr_mask)
{
    perf::Scope perf_scope(perf::kDraw);
    DrawCtx ctx;
    if (!begin_draw(ctx)) return;
    if (ctx.path == Path::Prog) { // the 16 attribute slots are exactly the shader's v0-v15
        debug_draw("immediate", ctx, prim, count, verts, 64);
        uint32_t mask = (attr_mask | vs_input_mask(ctx.vs) | 1u) & 0xFFFF, n = 0;
        uint8_t slot[16];
        for (uint32_t i = 0; i < 16; i++)
            if (mask & (1u << i)) slot[n++] = (uint8_t)i;
        if (n == 16) { // every slot: no smaller layout (not seen so far)
            KNOTE_ONCE("immediate-mode draw with all 16 attributes (256-byte vertices)");
            set_decl(host3d::dev(), decl_imm16());
            draw_up(prim, count, verts, 256);
            return;
        }
        KNOTE_ONCE("immediate-mode draws send %u of 16 attributes (mask 0x%x, %u-byte vertices)", n, mask, n * 16);
        if (g_imm_pack.size() < (size_t)count * n * 4) g_imm_pack.resize((size_t)count * n * 4);
        float *o = g_imm_pack.data();
        for (uint32_t v = 0; v < count; v++)
            for (uint32_t k = 0; k < n; k++, o += 4) memcpy(o, verts + v * 64 + slot[k] * 4, 16);
        set_decl(host3d::dev(), decl_imm(mask));
        draw_up(prim, count, g_imm_pack.data(), n * 16);
        return;
    }
    uint32_t fvf = ctx.fvf;
    // Rebuild the vertices in the current FVF layout from the 16 attribute slots
    // (0 position, 2 normal, 3 diffuse, 4 specular, 9.. texture coordinates).
    uint32_t stride = fvf_stride(fvf);
    std::vector<uint8_t> buf(stride * count);
    for (uint32_t v = 0; v < count; v++) {
        const float(*a)[4] = (const float(*)[4])(verts + v * 64);
        uint8_t *o = &buf[v * stride];
        auto putf = [&](float f) { memcpy(o, &f, 4); o += 4; };
        auto putc = [&](const float *c) {
            auto b = [](float x) { int i = (int)(x * 255.0f + 0.5f); return (uint32_t)(i < 0 ? 0 : i > 255 ? 255 : i); };
            uint32_t col = b(c[3]) << 24 | b(c[0]) << 16 | b(c[1]) << 8 | b(c[2]);
            memcpy(o, &col, 4);
            o += 4;
        };
        switch (fvf & D3DFVF_POSITION_MASK) {
        case D3DFVF_XYZRHW: // Xbox screen pixels -> render scale
            putf(a[0][0] * target_scale_x()); putf(a[0][1] * target_scale_y()); putf(a[0][2]); putf(a[0][3]);
            break;
        default: putf(a[0][0]); putf(a[0][1]); putf(a[0][2]); break;
        }
        if (fvf & D3DFVF_NORMAL) { putf(a[2][0]); putf(a[2][1]); putf(a[2][2]); }
        if (fvf & D3DFVF_DIFFUSE) putc(a[3]);
        if (fvf & D3DFVF_SPECULAR) putc(a[4]);
        uint32_t tc = (fvf >> 8) & 0xF;
        for (uint32_t i = 0; i < tc; i++) {
            static const uint32_t n[4] = {2, 3, 4, 1};
            uint32_t k = n[(fvf >> (16 + 2 * i)) & 3];
            for (uint32_t c = 0; c < k; c++) putf(a[9 + i][c]);
        }
    }
    draw_up(prim, count, buf.data(), stride);
}

void draw_inline_array(uint32_t prim, const uint32_t *data, uint32_t dwords)
{
    perf::Scope perf_scope(perf::kDraw);
    DrawCtx ctx;
    if (!begin_draw(ctx)) return;
    if (ctx.path == Path::Prog) { // inline data uses the stream-0 layout of the declaration
        uint32_t in_stride = ctx.vs->stream_stride[0];
        if (!in_stride) return;
        uint32_t count = dwords * 4 / in_stride;
        uint32_t stride = convert_vertices(ctx.vs, 0, count, (const uint8_t *)data, in_stride);
        set_decl(host3d::dev(), decl_for(ctx.vs));
        draw_up(prim, count, g_conv.data(), stride);
        return;
    }
    uint32_t stride = fvf_stride(ctx.fvf);
    if (!stride) return;
    draw_up(prim, dwords * 4 / stride, scale_rhw(ctx, data, 0, dwords * 4 / stride, stride), stride);
}

// ---- screenshots ----

void screenshot_now(const char *tag)
{
    if (g_cfg.screenshot_dir.empty() || !host3d::dev()) return;
    CreateDirectoryW(g_cfg.screenshot_dir.c_str(), nullptr);
    std::wstring path = g_cfg.screenshot_dir + L"\\" + widen(tag) + L".png";
    bool ok = save_screenshot(path.c_str());
    logf("screenshot %s: %s", narrow(path).c_str(), ok ? "saved" : "FAILED");
}

bool save_screenshot(const wchar_t *path)
{
    IDirect3DDevice9 *d = host3d::dev();
    if (!d) return false;
    IDirect3DSurface9 *bb = nullptr;
    if (FAILED(d->GetBackBuffer(0, 0, D3DBACKBUFFER_TYPE_MONO, &bb))) return false;
    RECT frame, pic; // the picture as shown in the window, without black bars
    host3d::frame_layout(&frame, &pic);
    bool ok = save_surface_png(bb, path, false, &pic);
    bb->Release();
    return ok;
}

// A render target surface (32-bit) as PNG: colour (opaque), or with alpha_as_gray its alpha channel;
// only the `crop` rectangle when given.
bool save_surface_png(IDirect3DSurface9 *src, const wchar_t *path, bool alpha_as_gray, const RECT *crop)
{
    IDirect3DDevice9 *d = host3d::dev();
    IDirect3DSurface9 *sys = nullptr;
    D3DSURFACE_DESC desc;
    src->GetDesc(&desc);
    D3DFORMAT format = desc.Format;
    UINT full_w = desc.Width, full_h = desc.Height;
    if (crop) {
        desc.Width = crop->right - crop->left;
        desc.Height = crop->bottom - crop->top;
    }
    bool ok = false;
    if (SUCCEEDED(d->CreateOffscreenPlainSurface(full_w, full_h, format, D3DPOOL_SYSTEMMEM, &sys, nullptr)) &&
        SUCCEEDED(d->GetRenderTargetData(src, sys))) {
        D3DLOCKED_RECT lr;
        if (SUCCEEDED(sys->LockRect(&lr, crop, D3DLOCK_READONLY))) {
            std::vector<uint8_t> px(desc.Width * desc.Height * 4);
            for (UINT y = 0; y < desc.Height; y++) {
                memcpy(&px[y * desc.Width * 4], (uint8_t *)lr.pBits + y * lr.Pitch, desc.Width * 4);
                for (UINT x = 0; x < desc.Width; x++) {
                    uint8_t *p = &px[(y * desc.Width + x) * 4];
                    if (alpha_as_gray) p[0] = p[1] = p[2] = p[3];
                    p[3] = 0xFF;
                }
            }
            sys->UnlockRect();
            CoInitializeEx(nullptr, COINIT_MULTITHREADED);
            IWICImagingFactory *f = nullptr;
            IWICStream *st = nullptr;
            IWICBitmapEncoder *enc = nullptr;
            IWICBitmapFrameEncode *fr = nullptr;
            if (SUCCEEDED(CoCreateInstance(CLSID_WICImagingFactory, nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&f))) &&
                SUCCEEDED(f->CreateStream(&st)) && SUCCEEDED(st->InitializeFromFilename(path, GENERIC_WRITE)) &&
                SUCCEEDED(f->CreateEncoder(GUID_ContainerFormatPng, nullptr, &enc)) &&
                SUCCEEDED(enc->Initialize(st, WICBitmapEncoderNoCache)) && SUCCEEDED(enc->CreateNewFrame(&fr, nullptr)) &&
                SUCCEEDED(fr->Initialize(nullptr)) && SUCCEEDED(fr->SetSize(desc.Width, desc.Height))) {
                WICPixelFormatGUID pf = GUID_WICPixelFormat32bppBGRA;
                fr->SetPixelFormat(&pf);
                ok = SUCCEEDED(fr->WritePixels(desc.Height, desc.Width * 4, (UINT)px.size(), px.data())) &&
                     SUCCEEDED(fr->Commit()) && SUCCEEDED(enc->Commit());
            }
            if (fr) fr->Release();
            if (enc) enc->Release();
            if (st) st->Release();
            if (f) f->Release();
        }
    }
    if (sys) sys->Release();
    return ok;
}

// ---- table ----

#define H(addr, fn, params, ret) {addr, #fn, (void *)&fn, params, ret}

static const Hle kTable[] = {
    H(0x00269c90, D3DDevice_DrawVerticesUP, "s s s s", false),
    H(0x00269e40, D3DDevice_DrawVertices, "s s s", false),
    H(0x00269f10, D3DDevice_DrawIndexedVertices, "s s s", false),
};

const Hle *hle_draw_table(size_t *count)
{
    *count = sizeof kTable / sizeof kTable[0];
    return kTable;
}

} // namespace xd3d
