#include "d3d/pshader.h"

#include "d3d/host.h"
#include "perf.h"
#include "d3d/nv2a_psh.h"
#include "d3d/state.h"
#include "d3d/draw.h"

#include <d3dcompiler.h>

#include <cstring>
#include <string>
#include <unordered_map>

namespace xd3d {
namespace {

std::unordered_map<std::string, IDirect3DPixelShader9 *> g_cache; // key: program dwords (no constants) + cube mask

bool is_fp_weapon_material(const PixelShaderDef &d)
{
    return d.PSCombinerCount == 0x11102 && d.PSTextureModes == 0x21 && d.PSFinalCombinerInputsABCD == 0x130c0300 &&
           d.PSFinalCombinerInputsEFG == 0x00002080 && d.PSRGBInputs[0] == 0xc4c80000 && d.PSRGBOutputs[0] == 0x000000c0 &&
           d.PSRGBInputs[1] == 0xc9d820cc && d.PSRGBOutputs[1] == 0x00000c00 && d.PSAlphaInputs[0] == 0 &&
           d.PSAlphaOutputs[0] == 0 && d.PSAlphaInputs[1] == 0 && d.PSAlphaOutputs[1] == 0;
}

uint32_t cube_mask()
{
    uint32_t m = 0;
    for (int s = 0; s < 4; s++) {
        Resource *r = g_st.textures[s];
        if (r && resource_type(r) == RTYPE_TEXTURE && (((PixelContainer *)r)->Format & FMT_CUBEMAP)) m |= 1u << s;
    }
    return m;
}

uint32_t pack_color(const float *v)
{
    auto c = [](float f) {
        f = f < 0.0f ? 0.0f : f > 1.0f ? 1.0f : f;
        return (uint32_t)(f * 255.0f + 0.5f);
    };
    return (c(v[3]) << 24) | (c(v[0]) << 16) | (c(v[1]) << 8) | c(v[2]);
}

void unpack_color(uint32_t c, float *o)
{
    o[0] = ((c >> 16) & 255) / 255.0f;
    o[1] = ((c >> 8) & 255) / 255.0f;
    o[2] = (c & 255) / 255.0f;
    o[3] = (c >> 24) / 255.0f;
}

void log_def(const PixelShaderDef &d)
{
    logf("[psh] combiners 0x%x texmodes 0x%x dotmap 0x%x inputtex 0x%x compare 0x%x final 0x%08x 0x%08x", d.PSCombinerCount,
         d.PSTextureModes, d.PSDotMapping, d.PSInputTexture, d.PSCompareMode, d.PSFinalCombinerInputsABCD, d.PSFinalCombinerInputsEFG);
    for (uint32_t i = 0; i < (d.PSCombinerCount & 0xFF) && i < 8; i++)
        logf("[psh]   stage %u: rgb in 0x%08x out 0x%08x | alpha in 0x%08x out 0x%08x", i, d.PSRGBInputs[i], d.PSRGBOutputs[i],
             d.PSAlphaInputs[i], d.PSAlphaOutputs[i]);
}

} // namespace

IDirect3DPixelShader9 *ps_host_shader()
{
    const uint32_t *rs = render_state();
    PixelShaderDef def = {};
    memcpy(&def, rs, 57 * 4);
    def.PSTextureModes = rs[XRS_PSTEXTUREMODES];
    uint32_t cube = cube_mask();
    const bool neutral_stage1 = g_cfg.fp_neutral_stage1 && is_fp_weapon_material(def);
    const float stage1_gain = is_fp_weapon_material(def)
                                  ? (fp_arms_texture_override_active() ? 0.0f : g_cfg.fp_stage1_gain)
                                  : 1.0f;
    // key: everything except the constant values (10-25, 43, 44)
    uint32_t key[48];
    uint32_t n = 0;
    for (uint32_t i = 0; i < 57; i++)
        if (!(i >= 10 && i <= 25) && i != 43 && i != 44) key[n++] = rs[i];
    key[n++] = def.PSTextureModes;
    key[n++] = cube;
    key[n++] = neutral_stage1;
    key[n++] = g_cfg.fp_arms_unlit && fp_arms_texture_override_active();
    uint32_t stage1_gain_bits;
    memcpy(&stage1_gain_bits, &stage1_gain, sizeof stage1_gain_bits);
    key[n++] = stage1_gain_bits;
    static uint32_t last_key[48], last_n;
    static IDirect3DPixelShader9 *last_ps;
    if (n == last_n && !memcmp(key, last_key, n * 4)) return last_ps; // most draws keep the previous shader
    std::string k((const char *)key, n * 4);
    auto it = g_cache.find(k);
    if (it != g_cache.end()) {
        memcpy(last_key, key, n * 4);
        last_n = n;
        return last_ps = it->second;
    }

    const bool arms_unlit = g_cfg.fp_arms_unlit && fp_arms_texture_override_active();
    std::string hlsl = arms_unlit
                           ? "sampler2D s2d0 : register(s0);\n"
                             "struct PSIn { float4 v0 : COLOR0; float4 v1 : COLOR1; float4 tc0 : TEXCOORD0; float4 tc1 : TEXCOORD1; "
                             "float4 tc2 : TEXCOORD2; float4 tc3 : TEXCOORD3; };\n"
                             "float4 main(PSIn I) : COLOR0 { return tex2D(s2d0, I.tc0.xy); }\n"
                           : psh_to_hlsl(def, cube, neutral_stage1, stage1_gain);
    perf::Scope perf_scope(perf::kCompile);
    perf::add_compile();
    ID3DBlob *code = nullptr, *errors = nullptr;
    HRESULT hr = E_FAIL;
    for (const char *profile : {"ps_2_0", "ps_2_a", "ps_2_b"}) {
        if (errors) { errors->Release(); errors = nullptr; }
        hr = D3DCompile(hlsl.data(), hlsl.size(), "nv2a_psh", nullptr, nullptr, "main", profile, D3DCOMPILE_OPTIMIZATION_LEVEL2, 0,
                        &code, &errors);
        if (SUCCEEDED(hr)) break;
    }
    IDirect3DPixelShader9 *ps = nullptr;
    static int logged;
    if (FAILED(hr)) {
        logf("[psh] compile failed: %s", errors ? (const char *)errors->GetBufferPointer() : "?");
        log_def(def);
        static int dumped;
        if (dumped++ < 3) logf("[psh] HLSL:\n%s", hlsl.c_str());
    } else if (FAILED(host3d::dev()->CreatePixelShader((const DWORD *)code->GetBufferPointer(), &ps))) {
        logf("[psh] CreatePixelShader failed");
        ps = nullptr;
    } else if (logged++ < 40) {
        logf("[psh] pixel shader #%zu translated (cube mask 0x%x)", g_cache.size() + 1, cube);
        log_def(def);
    }
    if (arms_unlit && ps) logf("[psh] diagnostic: arm texture-only shader active");
    else if (neutral_stage1 && ps) logf("[psh] diagnostic: neutralized stage 1 for first-person weapon material");
    else if (stage1_gain != 1.0f && ps) logf("[psh] diagnostic: stage-1 RGB gain %.3f for first-person weapon material", stage1_gain);
    if (code) code->Release();
    if (errors) errors->Release();
    g_cache[k] = ps; // failures are cached too (drawn with the fallback)
    memcpy(last_key, key, n * 4);
    last_n = n;
    return last_ps = ps;
}

void upload_ps_constants(IDirect3DDevice9 *d)
{
    const uint32_t *rs = render_state();
    float c[23][4];
    for (int i = 0; i < 8; i++) {
        unpack_color(rs[XRS_PSCONSTANT0_0 + i], c[i]);
        unpack_color(rs[XRS_PSCONSTANT1_0 + i], c[8 + i]);
    }
    unpack_color(rs[43], c[16]); // PSFinalCombinerConstant0
    unpack_color(rs[44], c[17]); // PSFinalCombinerConstant1
    unpack_color(rs[XRS_FOGCOLOR], c[18]);
    for (int s = 0; s < 4; s++) {
        const uint32_t *ts = texture_state(s);
        memcpy(&c[19 + s][0], &ts[22], 4); // BUMPENVMAT00
        memcpy(&c[19 + s][1], &ts[23], 4); // BUMPENVMAT01
        memcpy(&c[19 + s][2], &ts[25], 4); // BUMPENVMAT10
        memcpy(&c[19 + s][3], &ts[24], 4); // BUMPENVMAT11
    }
    d->SetPixelShaderConstantF(0, &c[0][0], 23);
}

void ps_set_constant(const PixelShaderDef *def, uint32_t reg, const float *v)
{
    uint32_t color = pack_color(v);
    uint32_t *rs = render_state();
    for (int i = 0; i < 8; i++) {
        if (((def->PSC0Mapping >> (4 * i)) & 0xF) == reg) rs[XRS_PSCONSTANT0_0 + i] = color;
        if (((def->PSC1Mapping >> (4 * i)) & 0xF) == reg) rs[XRS_PSCONSTANT1_0 + i] = color;
    }
    if ((def->PSFinalCombinerConstants & 0xF) == reg) rs[43] = color;
    if (((def->PSFinalCombinerConstants >> 4) & 0xF) == reg) rs[44] = color;
}

} // namespace xd3d
