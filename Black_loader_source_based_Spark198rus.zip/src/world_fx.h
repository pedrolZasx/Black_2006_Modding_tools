#pragma once
// Settings for the two cheap light effects that replace volumetric rendering (file: world_fx.ini next to black.exe,
// reloaded while the game runs):
//   * [beam]  PNG textures for light beams / rays and their dust layer
//   * [fog] / [fog_level_NN]  depth-map fog layer (colour, opacity, blend mode, near/far remap, optional tiling PNG)
// The drawing is in d3d/world_lights_pass.inc (beams) and d3d/fog_pass.inc (fog).
#include <string>

namespace world_fx {

enum FogBlend { kNormal = 0, kAdd = 1, kMultiply = 2, kScreen = 3, kOverlay = 4 };

struct Fog {
    bool  enabled = false;
    float color[3] = {0.55f, 0.60f, 0.66f};
    float color_far[3] = {0.55f, 0.60f, 0.66f}; // colour at 100 % depth (blends from `color` at 0 %); follows `color` unless set
    bool  has_color_far = false;
    float opacity = 0.6f;        // layer opacity, 0..1
    int   blend = kNormal;       // FogBlend
    float start = 4.f;           // metres: depth where the fog layer starts (0 % of the depth map)
    float end = 60.f;            // metres: depth where it is fully there (100 % of the depth map)
    float curve = 1.f;           // >1 keeps the near part clear, <1 fogs the near part more
    float sky = 1.f;             // how much of the fog covers the sky / pixels with no geometry (0..1)
    std::string tile;            // optional tiling fog PNG ("" = none)
    float tile_strength = 0.5f;  // 0 = flat depth fog .. 1 = fully modulated by the tile
    float tile_scale = 0.08f;    // tile repeats per metre (world space)
    float tile_wind[2] = {0.30f, 0.10f}; // tile drift, metres per second (x, z)
    bool  show_depth = false;    // debug: show the depth-map layer as grey scale
};

// Water drips running down the first-person weapon, projected in WORLD space (d3d/weapon_drip_pass.inc).
// [weapon_drip] sets the defaults (off unless enabled=1); [weapon_drip_level_NN] switches it on for mission NN.
struct WeaponDrip {
    bool  enabled = false;
    std::string texture = "fx\\weapon_drip.png"; // drip map (white drops on dark), path relative to black.exe or absolute
    float strength = 0.8f;       // brightness of the drips, 0..2
    float wet = 0.12f;           // how much the weapon darkens where it is wet, 0..1
    float tile_width = 0.6f;     // metres the map covers across
    float tile_height = 0.4f;    // metres the map covers from top to bottom
    float speed = 0.25f;         // metres per second the drips run down
    float max_depth = 1.1f;      // metres from the camera: only pixels nearer than this count as "the weapon"
    float tint[3] = {0.80f, 0.90f, 1.00f}; // colour of the highlights
    bool  debug = false;         // show the weapon mask: red = weapon pixel, green = has depth, blue = distance
};

// Screen-space ambient occlusion from the depth buffer (see d3d/ao_pass.inc).
struct Ao {
    bool  enabled = false;       // AO over the whole picture (level geometry, grass, props)
    bool  light = true;          // AO on the placed lights' light only (works even when `enabled` is 0)
    float strength = 0.8f;       // whole-picture AO strength, 0..2
    float light_strength = 1.0f; // AO strength on the placed lights' light, 0..2
    float radius = 0.6f;         // metres: how far an occluder can be and still darken a pixel
    float bias = 0.12f;          // 0..0.5: ignores near-flat surfaces (higher = less self-shadowing, less AO)
    float power = 1.5f;          // contrast of the occlusion curve
    float max_distance = 45.f;   // metres: AO fades out beyond this
    bool  half_res = true;       // compute at half resolution (faster and smoother)
    bool  show = false;          // debug: show the AO buffer as grey scale
};

// Screen-space shadows for the placed lights (see d3d/shadow_pass.inc): every pixel marches a ray towards each light through the game's
// depth buffer; anything that is in front of the ray on screen blocks the light. Only geometry that is visible on screen can cast.
struct Shadow {
    bool  enabled = false;
    float strength = 0.85f;     // 0..1: how dark a fully shadowed pixel gets (1 = no light at all)
    float distance = 14.f;      // metres: longest ray marched towards the light (longer = shadows from farther occluders, but coarser steps)
    float thickness = 0.8f;     // metres: how thick on-screen surfaces are assumed to be (stops far walls shadowing everything behind them)
    float bias = 0.06f;         // metres: ray start offset from the surface (raise it if surfaces shadow themselves)
    bool  half_res = true;      // compute at half resolution (faster and smoother)
    bool  show = false;         // debug: show the shadow masks (light 1 = red, 2 = green, 3 = blue, 4 = alpha ignored)
};

// Screen-space global illumination (one bounce): lit surfaces nearby tint the surfaces around them (see d3d/gi_pass.inc). Runs after the placed
// lights so the light they add is what bounces.
struct Gi {
    bool  enabled = false;
    float strength = 0.7f;      // 0..4
    float radius = 2.5f;        // metres: how far bounce light travels
    float threshold = 0.12f;    // 0..0.9: only pixels brighter than this send bounce light (keeps dark corners dark)
    float max_distance = 40.f;  // metres: GI fades out beyond this
    bool  half_res = true;
    bool  show = false;         // debug: show the bounce buffer
};

// Dynamic sky: replaces the sky pixels (no geometry in the depth buffer) with a gradient, scrolling cloud PNG layers, a moon PNG and
// twinkling / glittering stars (see d3d/sky_pass.inc). Game sky shader (hash E2888DF0) keeps drawing; this layer is composited over it.
struct Sky {
    bool  enabled = false;
    float replace = 1.f;                     // 0 keep the game's sky colour .. 1 use the gradient below
    float top[3] = {0.02f, 0.03f, 0.09f};    // gradient colour at the zenith
    float horizon[3] = {0.10f, 0.13f, 0.22f};
    std::string environment = "fx\\sky_%02d.png"; // equirectangular PNG; %02d expands to the mission number
    float environment_strength = 1.f;
    float environment_rotation = 0.f;         // yaw in degrees
    float environment_brightness = 1.f;
    float environment_contrast = 1.f;
    float environment_saturation = 1.f;
    float environment_hue = 0.f;
    std::string cloud = "fx\\clouds.png";    // tiling PNG (alpha = density, or brightness when it has no alpha)
    float cloud_opacity = 0.85f, cloud_scale = 1.2f, cloud_scale2 = 2.3f, cloud_layer2 = 0.6f;
    float cloud_speed[2] = {0.004f, 0.0015f}; // uv per second, layer 1; layer 2 moves 1.8x faster
    float cloud_color[3] = {0.55f, 0.60f, 0.72f};
    float cloud_cover = 0.0f;                // -0.5 clearer .. +0.5 heavier
    std::string moon = "fx\\moon.png";       // optional (missing = no moon)
    float moon_dir[3] = {0.3f, 0.55f, -0.75f};
    float moon_size = 0.07f, moon_brightness = 1.2f, moon_halo = 0.35f, moon_drift = 0.f; // drift: degrees per second around Y
    float star_density = 0.6f, star_brightness = 1.f, star_size = 1.f, star_twinkle = 2.5f, star_glitter = 0.6f;
};

struct ColorGrade {
    bool enabled = false;
    float exposure = 0.f;
    float contrast = 1.f;
    float saturation = 1.f;
    float hue = 0.f;
    float vibrance = 0.f;
    float temperature = 0.f;
    float tint = 0.f;
    float shadows = 0.f;
    float highlights = 0.f;
    std::string lut;
    float lut_strength = 1.f;
};

struct Paths {
    std::string beam = "fx\\beam.png";  // U across the beam, V from the light (top) to the far end (bottom)
    std::string dust = "fx\\dust.png";  // tiling dust / noise layer, drifts along the beam
};

void reload_if_changed();               // cheap; looks at the file at most once a second
const Paths &paths();
Ao ao_for_level(int level);             // [ao] with [ao_level_NN] on top
Shadow shadow_for_level(int level);     // [shadow] with [shadow_level_NN] on top
Gi gi_for_level(int level);             // [gi] with [gi_level_NN] on top
Fog fog_for_level(int level);
WeaponDrip weapon_drip_for_level(int level); // [weapon_drip] with [weapon_drip_level_NN] on top
Sky sky_for_level(int level);          // [sky] with [sky_level_NN] on top (a level section switches the sky on there)           // [fog] with [fog_level_NN] on top
ColorGrade color_grade_for_level(int level);
std::string resolve_path(const std::string &rel); // relative paths start at the folder of black.exe

} // namespace world_fx
