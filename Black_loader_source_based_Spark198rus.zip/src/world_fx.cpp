#include "world_fx.h"
#include "common.h"
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cwchar>
#include <map>
#include <vector>

namespace world_fx {
namespace {

struct KV { std::string key, val; };
struct Section { std::string name; std::vector<KV> kv; };

Paths g_paths;
Fog g_default_fog;
std::map<int, Fog> g_level_fog;
WeaponDrip g_default_drip;
std::map<int, WeaponDrip> g_level_drip;
Sky g_default_sky;
std::map<int, Sky> g_level_sky;
ColorGrade g_default_grade;
std::map<int, ColorGrade> g_level_grade;
Ao g_default_ao;
std::map<int, Ao> g_level_ao;
Shadow g_default_shadow;
std::map<int, Shadow> g_level_shadow;
Gi g_default_gi;
std::map<int, Gi> g_level_gi;
FILETIME g_stamp{};
DWORD g_last_check = 0;
bool g_loaded = false;

std::wstring exe_dir()
{
    wchar_t p[MAX_PATH]{};
    GetModuleFileNameW(nullptr, p, MAX_PATH);
    wchar_t *s = wcsrchr(p, L'\\');
    if (s) s[1] = 0;
    return p;
}

std::wstring ini_path() { return exe_dir() + L"world_fx.ini"; }

std::string trim(const std::string &s)
{
    size_t a = s.find_first_not_of(" \t\r\n"), b = s.find_last_not_of(" \t\r\n");
    return a == std::string::npos ? std::string() : s.substr(a, b - a + 1);
}

std::string lower(std::string s)
{
    for (char &c : s) c = (char)tolower((unsigned char)c);
    return s;
}

bool parse_bool(const std::string &v) { const std::string l = lower(v); return !(l == "0" || l == "false" || l == "off" || l == "no" || l.empty()); }

int parse_blend(const std::string &v)
{
    const std::string l = lower(v);
    if (l == "normal" || l == "alpha" || l == "mix") return kNormal;
    if (l == "add" || l == "additive" || l == "linear_dodge") return kAdd;
    if (l == "multiply") return kMultiply;
    if (l == "screen") return kScreen;
    if (l == "overlay") return kOverlay;
    return std::clamp(atoi(l.c_str()), 0, 4);
}

void apply_fog_key(Fog &f, const std::string &k, const std::string &v)
{
    float a = 0, b = 0, c = 0;
    if (k == "enabled") f.enabled = parse_bool(v);
    else if (k == "color") { if (sscanf_s(v.c_str(), "%f,%f,%f", &a, &b, &c) == 3) { f.color[0] = a; f.color[1] = b; f.color[2] = c; } }
    else if (k == "color_far") { if (sscanf_s(v.c_str(), "%f,%f,%f", &a, &b, &c) == 3) { f.color_far[0] = a; f.color_far[1] = b; f.color_far[2] = c; f.has_color_far = true; } }
    else if (k == "opacity") f.opacity = std::clamp((float)atof(v.c_str()), 0.f, 1.f);
    else if (k == "blend") f.blend = parse_blend(v);
    else if (k == "start") f.start = std::max(0.f, (float)atof(v.c_str()));
    else if (k == "end") f.end = (float)atof(v.c_str());
    else if (k == "curve") f.curve = std::clamp((float)atof(v.c_str()), 0.1f, 8.f);
    else if (k == "sky") f.sky = std::clamp((float)atof(v.c_str()), 0.f, 1.f);
    else if (k == "tile") f.tile = v;
    else if (k == "tile_strength") f.tile_strength = std::clamp((float)atof(v.c_str()), 0.f, 1.f);
    else if (k == "tile_scale") f.tile_scale = std::clamp((float)atof(v.c_str()), 0.001f, 4.f);
    else if (k == "tile_wind") { if (sscanf_s(v.c_str(), "%f,%f", &a, &b) == 2) { f.tile_wind[0] = a; f.tile_wind[1] = b; } }
    else if (k == "show_depth") f.show_depth = parse_bool(v);
}

void apply_drip_key(WeaponDrip &d, const std::string &k, const std::string &v)
{
    float a = 0, b = 0, c = 0;
    const float x = (float)atof(v.c_str());
    if (k == "enabled") d.enabled = parse_bool(v);
    else if (k == "texture" || k == "png") d.texture = v;
    else if (k == "strength") d.strength = std::clamp(x, 0.f, 2.f);
    else if (k == "wet") d.wet = std::clamp(x, 0.f, 1.f);
    else if (k == "tile_width") d.tile_width = std::clamp(x, 0.02f, 10.f);
    else if (k == "tile_height") d.tile_height = std::clamp(x, 0.02f, 10.f);
    else if (k == "speed") d.speed = std::clamp(x, -5.f, 5.f);
    else if (k == "debug") d.debug = parse_bool(v);
    else if (k == "max_depth") d.max_depth = std::clamp(x, 0.2f, 5.f);
    else if (k == "tint") { if (sscanf_s(v.c_str(), "%f,%f,%f", &a, &b, &c) == 3) { d.tint[0] = a; d.tint[1] = b; d.tint[2] = c; } }
}

void apply_sky_key(Sky &k, const std::string &key, const std::string &v)
{
    float a = 0, b = 0, c = 0;
    const float x = (float)atof(v.c_str());
    auto rgb = [&](float *o) { if (sscanf_s(v.c_str(), "%f,%f,%f", &a, &b, &c) == 3) { o[0] = a; o[1] = b; o[2] = c; } };
    if (key == "enabled") k.enabled = parse_bool(v);
    else if (key == "replace") k.replace = std::clamp(x, 0.f, 1.f);
    else if (key == "top") rgb(k.top);
    else if (key == "horizon") rgb(k.horizon);
    else if (key == "environment") k.environment = v;
    else if (key == "environment_strength") k.environment_strength = std::clamp(x, 0.f, 1.f);
    else if (key == "environment_rotation") k.environment_rotation = x;
    else if (key == "environment_brightness") k.environment_brightness = std::clamp(x, 0.f, 4.f);
    else if (key == "environment_contrast") k.environment_contrast = std::clamp(x, 0.f, 3.f);
    else if (key == "environment_saturation") k.environment_saturation = std::clamp(x, 0.f, 3.f);
    else if (key == "environment_hue") k.environment_hue = std::clamp(x, -180.f, 180.f);
    else if (key == "cloud") k.cloud = v;
    else if (key == "cloud_opacity") k.cloud_opacity = std::clamp(x, 0.f, 1.f);
    else if (key == "cloud_scale") k.cloud_scale = std::clamp(x, 0.05f, 20.f);
    else if (key == "cloud_scale2") k.cloud_scale2 = std::clamp(x, 0.05f, 20.f);
    else if (key == "cloud_layer2") k.cloud_layer2 = std::clamp(x, 0.f, 1.f);
    else if (key == "cloud_speed") { if (sscanf_s(v.c_str(), "%f,%f", &a, &b) == 2) { k.cloud_speed[0] = a; k.cloud_speed[1] = b; } }
    else if (key == "cloud_color") rgb(k.cloud_color);
    else if (key == "cloud_cover") k.cloud_cover = std::clamp(x, -0.5f, 0.5f);
    else if (key == "moon") k.moon = v;
    else if (key == "moon_dir") rgb(k.moon_dir);
    else if (key == "moon_size") k.moon_size = std::clamp(x, 0.01f, 0.6f);
    else if (key == "moon_brightness") k.moon_brightness = std::clamp(x, 0.f, 4.f);
    else if (key == "moon_halo") k.moon_halo = std::clamp(x, 0.f, 2.f);
    else if (key == "moon_drift") k.moon_drift = x;
    else if (key == "star_density") k.star_density = std::clamp(x, 0.f, 3.f);
    else if (key == "star_brightness") k.star_brightness = std::clamp(x, 0.f, 4.f);
    else if (key == "star_size") k.star_size = std::clamp(x, 0.3f, 3.f);
    else if (key == "star_twinkle") k.star_twinkle = std::clamp(x, 0.f, 20.f);
    else if (key == "star_glitter") k.star_glitter = std::clamp(x, 0.f, 3.f);
}

void apply_grade_key(ColorGrade &g, const std::string &key, const std::string &v)
{
    const float x = (float)atof(v.c_str());
    if (key == "enabled") g.enabled = parse_bool(v);
    else if (key == "exposure") g.exposure = std::clamp(x, -5.f, 5.f);
    else if (key == "contrast") g.contrast = std::clamp(x, 0.f, 3.f);
    else if (key == "saturation") g.saturation = std::clamp(x, 0.f, 3.f);
    else if (key == "hue") g.hue = std::clamp(x, -180.f, 180.f);
    else if (key == "vibrance") g.vibrance = std::clamp(x, -1.f, 1.f);
    else if (key == "temperature") g.temperature = std::clamp(x, -1.f, 1.f);
    else if (key == "tint") g.tint = std::clamp(x, -1.f, 1.f);
    else if (key == "shadows") g.shadows = std::clamp(x, -1.f, 1.f);
    else if (key == "highlights") g.highlights = std::clamp(x, -1.f, 1.f);
    else if (key == "lut") g.lut = v;
    else if (key == "lut_strength") g.lut_strength = std::clamp(x, 0.f, 1.f);
}

void apply_ao_key(Ao &a, const std::string &k, const std::string &v)
{
    const float x = (float)atof(v.c_str());
    if (k == "enabled") a.enabled = parse_bool(v);
    else if (k == "light" || k == "light_ao") a.light = parse_bool(v);
    else if (k == "strength") a.strength = std::clamp(x, 0.f, 2.f);
    else if (k == "light_strength") a.light_strength = std::clamp(x, 0.f, 2.f);
    else if (k == "radius") a.radius = std::clamp(x, 0.05f, 5.f);
    else if (k == "bias") a.bias = std::clamp(x, 0.f, 0.5f);
    else if (k == "power") a.power = std::clamp(x, 0.2f, 6.f);
    else if (k == "max_distance") a.max_distance = std::clamp(x, 2.f, 500.f);
    else if (k == "half_res") a.half_res = parse_bool(v);
    else if (k == "show" || k == "show_ao") a.show = parse_bool(v);
}

void apply_shadow_key(Shadow &s, const std::string &k, const std::string &v)
{
    const float x = (float)atof(v.c_str());
    if (k == "enabled") s.enabled = parse_bool(v);
    else if (k == "strength") s.strength = std::clamp(x, 0.f, 1.f);
    else if (k == "distance") s.distance = std::clamp(x, 1.f, 100.f);
    else if (k == "thickness") s.thickness = std::clamp(x, 0.05f, 10.f);
    else if (k == "bias") s.bias = std::clamp(x, 0.f, 1.f);
    else if (k == "half_res") s.half_res = parse_bool(v);
    else if (k == "show") s.show = parse_bool(v);
}

void apply_gi_key(Gi &g, const std::string &k, const std::string &v)
{
    const float x = (float)atof(v.c_str());
    if (k == "enabled") g.enabled = parse_bool(v);
    else if (k == "strength") g.strength = std::clamp(x, 0.f, 4.f);
    else if (k == "radius") g.radius = std::clamp(x, 0.2f, 12.f);
    else if (k == "threshold") g.threshold = std::clamp(x, 0.f, 0.9f);
    else if (k == "max_distance") g.max_distance = std::clamp(x, 2.f, 500.f);
    else if (k == "half_res") g.half_res = parse_bool(v);
    else if (k == "show") g.show = parse_bool(v);
}

void load()
{
    g_paths = Paths();
    g_default_fog = Fog();
    g_level_fog.clear();
    g_default_drip = WeaponDrip();
    g_level_drip.clear();
    g_default_ao = Ao();
    g_level_ao.clear();
    g_default_shadow = Shadow();
    g_level_shadow.clear();
    g_default_gi = Gi();
    g_level_gi.clear();
    g_default_sky = Sky();
    g_level_sky.clear();
    g_default_grade = ColorGrade();
    g_level_grade.clear();
    FILE *fp = nullptr;
    _wfopen_s(&fp, ini_path().c_str(), L"rt");
    if (!fp) return;
    std::vector<Section> secs;
    char line[1024];
    while (fgets(line, sizeof line, fp)) {
        std::string s = trim(line);
        if (s.empty() || s[0] == ';' || s[0] == '#') continue;
        if (s[0] == '[') {
            const size_t e = s.find(']');
            secs.push_back({lower(trim(s.substr(1, e == std::string::npos ? std::string::npos : e - 1))), {}});
        } else if (!secs.empty()) {
            const size_t eq = s.find('=');
            if (eq == std::string::npos) continue;
            std::string v = trim(s.substr(eq + 1));
            const size_t cm = v.find(';'); // trailing comment
            if (cm != std::string::npos) v = trim(v.substr(0, cm));
            secs.back().kv.push_back({lower(trim(s.substr(0, eq))), v});
        }
    }
    fclose(fp);
    for (const Section &sec : secs) // [beam] and [fog] first, so the order in the file does not matter
        if (sec.name == "beam") {
            for (const KV &kv : sec.kv) {
                if (kv.key == "texture") g_paths.beam = kv.val;
                else if (kv.key == "dust_texture") g_paths.dust = kv.val;
            }
        } else if (sec.name == "fog")
            for (const KV &kv : sec.kv) apply_fog_key(g_default_fog, kv.key, kv.val);
        else if (sec.name == "weapon_drip")
            for (const KV &kv : sec.kv) apply_drip_key(g_default_drip, kv.key, kv.val);
        else if (sec.name == "ao")
            for (const KV &kv : sec.kv) apply_ao_key(g_default_ao, kv.key, kv.val);
        else if (sec.name == "shadow")
            for (const KV &kv : sec.kv) apply_shadow_key(g_default_shadow, kv.key, kv.val);
        else if (sec.name == "gi")
            for (const KV &kv : sec.kv) apply_gi_key(g_default_gi, kv.key, kv.val);
        else if (sec.name == "sky")
            for (const KV &kv : sec.kv) apply_sky_key(g_default_sky, kv.key, kv.val);
        else if (sec.name == "color_grade")
            for (const KV &kv : sec.kv) apply_grade_key(g_default_grade, kv.key, kv.val);
    for (const Section &sec : secs) {
        int level = -1;
        if (sscanf_s(sec.name.c_str(), "ao_level_%d", &level) == 1 && level >= 0) {
            Ao a = g_default_ao;
            for (const KV &kv : sec.kv) apply_ao_key(a, kv.key, kv.val);
            g_level_ao[level] = a;
            continue;
        }
        if (sscanf_s(sec.name.c_str(), "shadow_level_%d", &level) == 1 && level >= 0) {
            Shadow s = g_default_shadow;
            s.enabled = true; // a level section switches shadows on there unless it says enabled=0
            for (const KV &kv : sec.kv) apply_shadow_key(s, kv.key, kv.val);
            g_level_shadow[level] = s;
            continue;
        }
        if (sscanf_s(sec.name.c_str(), "gi_level_%d", &level) == 1 && level >= 0) {
            Gi g = g_default_gi;
            g.enabled = true;
            for (const KV &kv : sec.kv) apply_gi_key(g, kv.key, kv.val);
            g_level_gi[level] = g;
            continue;
        }
        if (sscanf_s(sec.name.c_str(), "sky_level_%d", &level) == 1 && level >= 0) {
            Sky k = g_default_sky;
            k.enabled = true;
            for (const KV &kv : sec.kv) apply_sky_key(k, kv.key, kv.val);
            g_level_sky[level] = k;
            continue;
        }
        if (sscanf_s(sec.name.c_str(), "color_grade_level_%d", &level) == 1 && level >= 0) {
            ColorGrade g = g_default_grade;
            g.enabled = true;
            for (const KV &kv : sec.kv) apply_grade_key(g, kv.key, kv.val);
            g_level_grade[level] = g;
            continue;
        }
        if (sscanf_s(sec.name.c_str(), "weapon_drip_level_%d", &level) == 1 && level >= 0) {
            WeaponDrip d = g_default_drip;
            d.enabled = true; // a level section switches it on for that mission unless it says enabled=0
            for (const KV &kv : sec.kv) apply_drip_key(d, kv.key, kv.val);
            g_level_drip[level] = d;
            continue;
        }
        if (sscanf_s(sec.name.c_str(), "fog_level_%d", &level) != 1 || level < 0) continue;
        Fog f = g_default_fog;
        f.enabled = true; // a level section switches fog on for that level unless it says enabled=0
        for (const KV &kv : sec.kv) apply_fog_key(f, kv.key, kv.val);
        g_level_fog[level] = f;
    }
    logf("[fx] world_fx.ini loaded: beam texture '%s', fog default %s, %zu level override(s)", g_paths.beam.c_str(),
         g_default_fog.enabled ? "on" : "off", g_level_fog.size());
}

} // namespace

void reload_if_changed()
{
    const DWORD now = GetTickCount();
    if (g_loaded && now - g_last_check < 1000) return;
    g_last_check = now;
    WIN32_FILE_ATTRIBUTE_DATA a{};
    if (!GetFileAttributesExW(ini_path().c_str(), GetFileExInfoStandard, &a)) {
        if (!g_loaded || g_stamp.dwLowDateTime || g_stamp.dwHighDateTime) { g_paths = Paths(); g_default_fog = Fog(); g_level_fog.clear(); g_default_drip = WeaponDrip(); g_level_drip.clear(); g_default_ao = Ao(); g_level_ao.clear(); g_default_shadow = Shadow(); g_level_shadow.clear(); g_default_gi = Gi(); g_level_gi.clear(); g_default_sky = Sky(); g_level_sky.clear(); g_default_grade = ColorGrade(); g_level_grade.clear(); }
        g_stamp = FILETIME{};
        g_loaded = true;
        return;
    }
    if (g_loaded && !CompareFileTime(&g_stamp, &a.ftLastWriteTime)) return;
    g_stamp = a.ftLastWriteTime;
    g_loaded = true;
    load();
}

const Paths &paths() { reload_if_changed(); return g_paths; }

Fog fog_for_level(int level)
{
    reload_if_changed();
    auto it = g_level_fog.find(level);
    return it != g_level_fog.end() ? it->second : g_default_fog;
}

WeaponDrip weapon_drip_for_level(int level)
{
    reload_if_changed();
    auto it = g_level_drip.find(level);
    return it != g_level_drip.end() ? it->second : g_default_drip;
}

Sky sky_for_level(int level)
{
    reload_if_changed();
    auto it = g_level_sky.find(level);
    Sky result = it != g_level_sky.end() ? it->second : g_default_sky;
    const size_t marker = result.environment.find("%02d");
    if (marker != std::string::npos) {
        char digits[3]{};
        sprintf_s(digits, "%02d", std::clamp(level, 0, 99));
        result.environment.replace(marker, 3, digits);
    }
    return result;
}

ColorGrade color_grade_for_level(int level)
{
    reload_if_changed();
    auto it = g_level_grade.find(level);
    return it != g_level_grade.end() ? it->second : g_default_grade;
}

Ao ao_for_level(int level)
{
    reload_if_changed();
    auto it = g_level_ao.find(level);
    return it != g_level_ao.end() ? it->second : g_default_ao;
}

Shadow shadow_for_level(int level)
{
    reload_if_changed();
    auto it = g_level_shadow.find(level);
    return it != g_level_shadow.end() ? it->second : g_default_shadow;
}

Gi gi_for_level(int level)
{
    reload_if_changed();
    auto it = g_level_gi.find(level);
    return it != g_level_gi.end() ? it->second : g_default_gi;
}

std::string resolve_path(const std::string &rel)
{
    if (rel.size() > 1 && (rel[1] == ':' || rel[0] == '\\' || rel[0] == '/')) return rel; // already absolute
    return narrow(exe_dir()) + rel;
}

} // namespace world_fx
