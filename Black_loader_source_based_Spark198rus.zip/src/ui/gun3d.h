// 3D weapon inspection for the armory. The model is a small converted file:
//   <black.exe folder>\armory\models\<name>.gmesh
// GMSH v2 stores position3, normal3, UV2 per vertex; v1 remains readable with generated normals.
// It is read on a background thread; the render thread transforms its vertices and submits indexed geometry to D3D9.
// D3D9 handles triangle rasterization, depth testing and texture filtering; no game gun code is touched.
#pragma once

#include <cstdint>
#include <windows.h>
#include <d3d9.h>

namespace gun3d {

// Draws weapon <weapon_id> inside <box> (window pixels). Returns false when there is no model (yet, or never):
// the caller then draws the normal PNG picture. Safe to call every frame. Game thread only.
bool draw(IDirect3DDevice9 *d, const RECT &box, int weapon_id);

// Release default-pool resources before the host resets its Direct3D device.
void on_device_lost();

// Input for the view, fed from the pad poll while the armory is open (any thread; just stores numbers).
void feed_mouse(int dx, int dy, int wheel);                      // raw mouse counts and wheel notches since the last poll
void feed_pad(int16_t rx, int16_t ry, uint8_t lt, uint8_t rt);   // right stick (rotate), triggers (zoom)

} // namespace gun3d
