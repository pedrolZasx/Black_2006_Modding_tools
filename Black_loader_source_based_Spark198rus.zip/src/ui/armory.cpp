#include "ui/armory.h"

#include "audio/output.h"
#include "input/bindings.h"
#include "ui/sfx.h"
#include "common.h"

#include <windows.h>

#include <algorithm>
#include <array>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cwchar>
#include <mutex>

namespace armory {
namespace {

// =====================================================================================================================
// SETTINGS you may want to change (see also weapons.txt in the armory folder next to black.exe)
// =====================================================================================================================
constexpr int kKeyToggle = 'T', kKeyToggle2 = 'U'; // keyboard: T or U opens and closes the armory
constexpr uint16_t kPadToggle = 0x0020; // pad: BACK (= SELECT) opens and closes it. 0x10 = START would clash with the pause menu
constexpr float kAudioMin = 0.40f;      // slowest speed of the GAME sounds in slow motion (1 = normal; lower = deeper, slower)
constexpr int kStartMags = 3;           // magazines you get with a bought weapon
constexpr int kDefaultMaxMags = 8;      // default spare magazines of reserve ammo, overridable per weapon in weapon_tuning.ini
constexpr uint32_t kKillCounter = 0x80B9A01E; // kills, 2 bytes (stats block 0x80B9A000 +0x1E); tested: counts shotgun, AK, uzi, grenade
constexpr int kPointsPerKill = 100;     // credits per kill
constexpr float kSlowFactor = 1.0f;    // world speed while the armory is open (0.15 = 15%)
constexpr audio_out::MusicCfg kArmoryMusicCfg{5.0f, 10.0f, 5.0f, 5.0f, 0.35f, 5.0f}; // delay, fades, gap, volume, close fade
constexpr ULONGLONG kFeedLife = 3400;   // ms a kill ribbon stays (slide in 250, fade out the last 400)
constexpr ULONGLONG kPopLife = 1800;    // ms the centre "+points" stays after the last kill
constexpr int kFeedMax = 4;             // ribbons shown at once
constexpr int kCols = 2, kVisRows = 3;  // weapon cards: columns, rows visible

// Colours are 0xAARRGGBB.
constexpr uint32_t kPanel = 0xA80A1013, kCard = 0x80101619, kCardSel = 0xA01B2921, kGreen = 0xFF8DB65A,
                   kDim = 0xFF52634B, kBuyBar = 0xA0273A23, kTab = 0x60374934, kTxt = 0xFFE8EDE6,
                   kTxtDim = 0xFF9AA5A2, kTxtGreen = 0xFF9AC46A, kOutline = 0x604B5A55,
                   kBarBg = 0xA01D2525, kBarFill = 0xFF809A85;

// =====================================================================================================================

enum Tab { TAB_WEAPONS, TAB_AMMO, TAB_EXIT, kTabs };
const wchar_t *const kTabName[kTabs] = {L"WEAPONS", L"AMMO", L"EXIT"};

struct Weapon {
    int id; // the game's weapon id
    std::wstring name, type;
    int price, ammo_price; // weapon, and one magazine of its ammo
};
std::vector<Weapon> g_weapons;

// First-run content of armory\weapons.txt: id, name, type, price, ammo price (per magazine)
const char kDefaultWeapons[] =
        "# Weapon armory list. One weapon per line:  id, name, type, price, ammo price (per magazine)\n"
        "# id = the game's weapon id. Lines starting with # are ignored. Saved changes load when you open the armory.\n"
        "# Pictures: armory\\weapons\\<id>.png (weapon) and armory\\ammo\\<id>.png (ammo); weapons\\default.png and\n"
        "# ammo\\default.png are used when a picture is missing.\n"
        "0, DC3 Elite, HANDGUN, 500, 50\n"
        "11, Smith & Wesson Model 629, HANDGUN, 800, 75\n"
        "14, Colt AR-15A2, HANDGUN, 1200, 100\n"
        "1, Franchi SPAS-12, SHOTGUN, 1500, 125\n"
        "13, Remington Model 870, SHOTGUN, 1200, 100\n"
        "3, IMI Uzi, SMG, 1500, 100\n"
        "8, Ingram MAC-11, SMG, 900, 75\n"
        "9, FN P90, SMG, 1800, 125\n"
        "15, Heckler & Koch HK94 (MP5), SMG, 1700, 125\n"
        "4, Heckler & Koch G36C, ASSAULT RIFLE, 2500, 150\n"
        "5, AK-47, ASSAULT RIFLE, 3000, 175\n"
        "12, M16, ASSAULT RIFLE, 2600, 150\n"
        "16, Colt AR-15A2, ASSAULT RIFLE, 2200, 150\n"
        "2, Walther WA2000, SNIPER, 4000, 200\n"
        "10, M249 SAW, LMG, 4500, 300\n"
        "7, M203, GRENADE LAUNCHER, 3500, 250\n"
        "6, RPG-7, LAUNCHER, 5000, 500\n";

bool g_open, g_wait_release, g_reload_pending;
int g_tab = TAB_WEAPONS, g_sel, g_scroll;
std::vector<int> g_view;                // the cards shown in this tab: indices into g_weapons (AMMO tab: carried weapons only)
int g_sel_saved[2], g_scroll_saved[2]; // selection of the WEAPONS and AMMO tabs, kept while on the other tab
int g_credits = 0;
bool g_credits_loaded;
bool g_kills_valid;
uint32_t g_kills_last;
wchar_t g_msg[64];
ULONGLONG g_msg_at;
std::mutex g_mu; // the pad poll and the frame drawing may run on different threads
std::mutex g_tuning_mu;
std::array<int, 17> g_max_mags{};
std::array<int, 17> g_magazine_size{};
std::array<uint32_t, 17> g_weapon_def{};
std::array<uint8_t, 17> g_original_magazine_size{};
DWORD g_tuning_checked;
FILETIME g_tuning_stamp{};
bool g_tuning_loaded;
wchar_t g_tuning_ini[MAX_PATH]{};

// ---- kill notifications --------------------------------------------------------------------------------------------
struct FeedItem {
    ULONGLONG t0;
    int pts;
};
std::vector<FeedItem> g_feed;
ULONGLONG g_pop_t0; // last kill
int g_pop_pts, g_pop_kills;

// ---- slow motion while open ----------------------------------------------------------------------------------------
// The game steps its world by a fixed frame time (1/60 s). While the armory is open that time is scaled down. Three
// places hold it; each is remembered when slow motion starts and put back exactly when it ends.
struct DtSite {
    int idx;
    uint32_t addr;
    float orig;
};
DtSite g_dt[3];
int g_dt_n;
bool g_slow_active, g_slow_failed;
float g_scale = 1.0f, g_target = 1.0f;

// ---- files ---------------------------------------------------------------------------------------------------------
std::string exe_dir()
{
    char p[MAX_PATH];
    DWORD n = GetModuleFileNameA(nullptr, p, MAX_PATH);
    std::string s(p, n);
    size_t k = s.find_last_of("\\/");
    return k == std::string::npos ? std::string() : s.substr(0, k + 1);
}

std::string credits_path()
{
    return exe_dir() + "armory\\credits.txt";
}

void load_credits()
{
    if (g_credits_loaded) return;
    g_credits_loaded = true;
    FILE *f = fopen(credits_path().c_str(), "rb");
    if (!f) return;
    long long value = 0;
    if (fscanf(f, "%lld", &value) == 1 && value >= 0 && value <= 0x7fffffffLL)
        g_credits = (int)value;
    fclose(f);
}

void save_credits()
{
    std::string dir = exe_dir() + "armory";
    CreateDirectoryA(dir.c_str(), nullptr);
    std::string path = credits_path(), temp = path + ".tmp";
    FILE *f = fopen(temp.c_str(), "wb");
    if (!f) {
        logf("[armory] could not save credits to %s", path.c_str());
        return;
    }
    bool ok = fprintf(f, "%d\n", g_credits) > 0;
    if (fclose(f) != 0) ok = false;
    if (!ok || !MoveFileExA(temp.c_str(), path.c_str(), MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH)) {
        DeleteFileA(temp.c_str());
        logf("[armory] could not save credits to %s", path.c_str());
    }
}

std::string trim(const std::string &s)
{
    size_t a = s.find_first_not_of(" \t\r\n"), b = s.find_last_not_of(" \t\r\n");
    return a == std::string::npos ? std::string() : s.substr(a, b - a + 1);
}

std::wstring upper_ascii(const std::string &s)
{
    std::wstring w;
    for (unsigned char c : s) w += (c >= 32 && c < 127) ? (wchar_t)toupper(c) : L'?';
    return w;
}

void parse_weapons(const std::string &text, std::vector<Weapon> &out)
{
    size_t pos = 0;
    while (pos < text.size() && out.size() < 64) {
        size_t e = text.find('\n', pos);
        std::string line = trim(text.substr(pos, e == std::string::npos ? std::string::npos : e - pos));
        pos = e == std::string::npos ? text.size() : e + 1;
        if (line.empty() || line[0] == '#') continue;
        std::vector<std::string> f;
        for (size_t a = 0;;) {
            size_t c = line.find(',', a);
            f.push_back(trim(line.substr(a, c == std::string::npos ? std::string::npos : c - a)));
            if (c == std::string::npos) break;
            a = c + 1;
        }
        if (f.size() < 5) continue;
        int id = atoi(f[0].c_str());
        if (id < 0 || id > 255 || f[0].empty()) continue;
        out.push_back({id, upper_ascii(f[1]), upper_ascii(f[2]), std::max(0, atoi(f[3].c_str())), std::max(0, atoi(f[4].c_str()))});
    }
}

// armory\weapons.txt (created with the defaults on first run), and the picture folders
void load_weapons()
{
    std::string base = exe_dir() + "armory\\";
    CreateDirectoryA((exe_dir() + "armory").c_str(), nullptr);
    CreateDirectoryA((base + "weapons").c_str(), nullptr);
    CreateDirectoryA((base + "ammo").c_str(), nullptr);
    std::string path = base + "weapons.txt", text;
    FILE *f = fopen(path.c_str(), "rb");
    if (!f) {
        if ((f = fopen(path.c_str(), "wb")) != nullptr) {
            fputs(kDefaultWeapons, f);
            fclose(f);
        }
        f = fopen(path.c_str(), "rb");
    }
    if (f) {
        char buf[4096];
        size_t n;
        while ((n = fread(buf, 1, sizeof buf, f)) > 0 && text.size() < 65536) text.append(buf, n);
        fclose(f);
    }
    std::vector<Weapon> w;
    parse_weapons(text, w);
    if (w.empty()) parse_weapons(kDefaultWeapons, w);
    g_weapons.swap(w);
    int count = (int)g_weapons.size();
    g_sel = std::max(0, std::min(g_sel, count - 1));
    g_scroll = std::min(g_scroll, std::max(0, (count + kCols - 1) / kCols - kVisRows));
}

// ---- game memory (the Xbox image runs at its own addresses inside this process) -----------------------------------
bool readable(uint32_t a, uint32_t n) { return a >= 0x10000 && !IsBadReadPtr((const void *)(uintptr_t)a, n); }
bool writable(uint32_t a, uint32_t n) { return a >= 0x10000 && !IsBadWritePtr((void *)(uintptr_t)a, n); }
uint32_t r32(uint32_t a) { return readable(a, 4) ? *(const uint32_t *)(uintptr_t)a : 0; }

void reload_weapon_tuning_locked()
{
    const DWORD now = GetTickCount();
    if (now - g_tuning_checked < 1000 && g_tuning_loaded) return;
    g_tuning_checked = now;
    if (!g_tuning_ini[0]) {
        GetModuleFileNameW(nullptr, g_tuning_ini, MAX_PATH);
        wchar_t *slash = wcsrchr(g_tuning_ini, L'\\');
        if (slash) wcscpy_s(slash + 1, MAX_PATH - (slash + 1 - g_tuning_ini), L"weapon_tuning.ini");
    }
    WIN32_FILE_ATTRIBUTE_DATA attrs{};
    FILETIME stamp{};
    if (GetFileAttributesExW(g_tuning_ini, GetFileExInfoStandard, &attrs)) stamp = attrs.ftLastWriteTime;
    if (!g_tuning_loaded || CompareFileTime(&stamp, &g_tuning_stamp) != 0) {
        g_tuning_loaded = true;
        g_tuning_stamp = stamp;
        g_max_mags.fill(kDefaultMaxMags);
        g_magazine_size.fill(0); // zero means keep the game's own magazine capacity
        for (int weapon = 0; weapon < (int)g_max_mags.size(); ++weapon) {
            wchar_t section[32];
            swprintf_s(section, L"weapon_%02d", weapon);
            int value = (int)GetPrivateProfileIntW(section, L"max_mags", kDefaultMaxMags, g_tuning_ini);
            g_max_mags[weapon] = std::clamp(value, 1, 99);
            value = (int)GetPrivateProfileIntW(section, L"magazine_size", 0, g_tuning_ini);
            g_magazine_size[weapon] = std::clamp(value, 0, 255);
        }
    }
}

int max_mags_for_weapon(int id)
{
    if (id < 0 || id >= (int)g_max_mags.size()) return kDefaultMaxMags;
    std::lock_guard<std::mutex> lock(g_tuning_mu);
    reload_weapon_tuning_locked();
    return g_max_mags[id];
}

int magazine_size_setting(int id)
{
    if (id < 0 || id >= (int)g_magazine_size.size()) return 0;
    std::lock_guard<std::mutex> lock(g_tuning_mu);
    reload_weapon_tuning_locked();
    return g_magazine_size[id];
}

uint32_t weapon_table() // the game's weapon table (32 bytes per id), 0 when not available
{
    uint32_t a = r32(0x2D12D0);
    a = a ? r32(a) : 0;
    return a ? r32(a + 4) : 0;
}

bool weapon_info(int id, int &clip, int &ammo_type)
{
    uint32_t tbl = weapon_table();
    if (!tbl) return false;
    uint32_t def = r32(tbl + id * 0x20 + 8);
    if (!def || !readable(def, 0xA0)) return false;
    clip = *(const uint8_t *)(uintptr_t)(def + 0x60);
    ammo_type = (int)r32(def + 0x64);
    return clip >= 1 && ammo_type >= 0 && ammo_type <= 9;
}

uint32_t player_state() { return r32(0x2D45D4); } // G
bool slot_occupied(uint32_t obj);

int current_weapon_id_impl()
{
    uint32_t G = player_state();
    if (!G) return -1;
    uint32_t arr = r32(G + 0x2C8), held = r32(G + 0x2CC);
    if (!arr || !held) return -1;
    for (int slot = 0; slot < 2; ++slot) {
        uint32_t obj = r32(arr + slot * 4);
        if (obj == held && slot_occupied(obj)) {
            int id = *(const uint8_t *)(uintptr_t)obj;
            return id >= 0 && id < 17 ? id : -1;
        }
    }
    return -1;
}

int current_weapon_slot_impl()
{
    uint32_t G = player_state();
    if (!G) return -1;
    uint32_t arr = r32(G + 0x2C8), held = r32(G + 0x2CC);
    if (!arr || !held) return -1;
    for (int slot = 0; slot < 2; ++slot) {
        uint32_t obj = r32(arr + slot * 4);
        if (obj == held && slot_occupied(obj)) return slot;
    }
    return -1;
}

// True when a weapon slot really holds a weapon the player has (picked up or bought): the object exists and the game
// has linked its weapon table entry (+0xE8) and definition (+0xEC) into it. An unused slot has none of that.
bool slot_occupied(uint32_t obj)
{
    return obj && readable(obj, 0xF8) && r32(obj + 0xE8) != 0 && r32(obj + 0xEC) != 0;
}

// The player's weapon object that holds weapon `id` (slot 0 or 1), or 0.
uint32_t carried(int id)
{
    uint32_t G = player_state(), arr = G ? r32(G + 0x2C8) : 0;
    if (!arr) return 0;
    for (int slot = 0; slot < 2; slot++) {
        uint32_t obj = r32(arr + slot * 4);
        if (slot_occupied(obj) && *(const uint8_t *)(uintptr_t)obj == (uint8_t)id) return obj;
    }
    return 0;
}

// Diagnostic: writes both weapon slots to black.log (id, table entry, definition, sub object, held pointer).
void log_slots(const char *why)
{
    uint32_t G = player_state(), arr = G ? r32(G + 0x2C8) : 0;
    if (!arr) {
        logf("[armory] slots (%s): game data not ready", why);
        return;
    }
    logf("[armory] slots (%s): G=%08X arr=%08X held=%08X", why, G, arr, r32(G + 0x2CC));
    for (int slot = 0; slot < 2; slot++) {
        uint32_t obj = r32(arr + slot * 4);
        if (!obj || !readable(obj, 0xF8)) {
            logf("[armory]   slot %d: obj=%08X (empty / not readable)", slot, obj);
            continue;
        }
        logf("[armory]   slot %d: obj=%08X id=%d entry=%08X def=%08X sub=%08X occupied=%d", slot, obj,
             (int)*(const uint8_t *)(uintptr_t)obj, r32(obj + 0xE8), r32(obj + 0xEC), r32(obj + 0xF4),
             slot_occupied(obj) ? 1 : 0);
    }
}

// reserve ammo of the weapon's ammo type; false if the game data is not there
bool reserve_info(int id, int &clip, int &reserve, int &max_reserve)
{
    int at;
    uint32_t G = player_state();
    if (!G || !weapon_info(id, clip, at)) return false;
    uint32_t a = G + 0x2A8 + at * 2;
    if (!readable(a, 2)) return false;
    reserve = *(const uint16_t *)(uintptr_t)a;
    max_reserve = std::min(clip * max_mags_for_weapon(id), 999);
    return true;
}

// Replace the equipped weapon object with `id`, with kStartMags magazines (never less reserve than the player already
// has). The game always has a two-entry slot array; an empty second entry must not prevent replacing the current slot.
// 0 = done, 1 = game data not ready, 2 = no weapon slot to replace.
int give_weapon(int id)
{
    uint32_t G = player_state(), tbl = weapon_table();
    if (!G || !tbl) return 1;
    uint32_t entry = tbl + id * 0x20, def = r32(entry + 8);
    if (!def || !readable(def, 0xA0)) return 1;
    uint32_t arr = r32(G + 0x2C8), held = r32(G + 0x2CC);
    if (!arr) return 1;
    int clip = *(const uint8_t *)(uintptr_t)(def + 0x60);
    uint32_t ammo_type = r32(def + 0x64);
    if (clip < 1) clip = 1;
    if (ammo_type > 9) return 1;
    log_slots("buy");
    uint32_t obj = 0;
    int slot = -1;
    for (int i = 0; i < 2; i++) {
        uint32_t candidate = r32(arr + i * 4);
        if (candidate && candidate == held && slot_occupied(candidate)) {
            obj = candidate;
            break;
        }
    }
    if (obj) {
        slot = obj == r32(arr) ? 0 : 1;
    } else {
        // If the held pointer is temporarily unavailable, use the first occupied slot rather than failing the purchase.
        for (int i = 0; i < 2; ++i) {
            uint32_t candidate = r32(arr + i * 4);
            if (slot_occupied(candidate)) {
                obj = candidate;
                slot = i;
                break;
            }
        }
    }
    if (!obj) return 2;
    uint32_t sub = r32(obj + 0xF4), ra = G + 0x2A8 + ammo_type * 2;
    if (!sub || !writable(obj, 0xF8) || !writable(sub, 0x20) || !writable(ra, 2)) return 1;
    int reserve = std::min(std::min(clip * max_mags_for_weapon(id), 999),
                           std::max((int)*(const uint16_t *)(uintptr_t)ra, std::min(clip * kStartMags, 999)));
    *(uint8_t *)(uintptr_t)obj = (uint8_t)id;
    *(uint32_t *)(uintptr_t)(obj + 0xE8) = entry;
    *(uint32_t *)(uintptr_t)(obj + 0xEC) = def;
    *(uint32_t *)(uintptr_t)(sub + 0x00) = r32(def + 0x90);
    *(uint32_t *)(uintptr_t)(sub + 0x08) = def;
    *(uint32_t *)(uintptr_t)(sub + 0x0C) = def;
    *(uint32_t *)(uintptr_t)(sub + 0x14) = r32(def + 0x98);
    *(uint16_t *)(uintptr_t)(sub + 0x18) = (uint16_t)clip;
    *(uint16_t *)(uintptr_t)ra = (uint16_t)reserve;
    *(uint8_t *)(uintptr_t)(sub + 0x1A) = (uint8_t)std::min(255, reserve / clip);
    logf("[armory] weapon %d placed in current slot %d (%d reserve)", id, slot, reserve);
    return 0;
}

// BLACK reserves two weapon-slot entries for the player. At mission start the unused entry may already have
// an object/subobject allocated but no weapon definition attached. Seed that slot from the starting weapon so
// the player can always switch between two weapons without first finding a pickup.
void ensure_second_weapon_slot()
{
    if (!bindings::in_play()) return;
    uint32_t G = player_state();
    uint32_t arr = G ? r32(G + 0x2C8) : 0;
    uint32_t held = G ? r32(G + 0x2CC) : 0;
    if (!G || !arr || !held) return;

    int held_slot = -1;
    for (int i = 0; i < 2; ++i) {
        uint32_t obj = r32(arr + i * 4);
        if (obj == held && slot_occupied(obj)) {
            held_slot = i;
            break;
        }
    }
    if (held_slot < 0) return;
    const int target_slot = 1 - held_slot;
    uint32_t dst_obj = r32(arr + target_slot * 4);
    if (slot_occupied(dst_obj)) return;

    static uint32_t last_not_ready_G;
    auto not_ready = [&](const char *reason) {
        if (last_not_ready_G != G) {
            logf("[armory] can't seed second weapon slot yet: %s (G=%08X slot=%d)", reason, G, target_slot);
            last_not_ready_G = G;
        }
    };
    if (!dst_obj || !writable(dst_obj, 0xF8)) return not_ready("game did not preallocate a writable slot object");
    uint32_t src_entry = r32(held + 0xE8), def = r32(held + 0xEC);
    uint32_t src_sub = r32(held + 0xF4), dst_sub = r32(dst_obj + 0xF4);
    if (!src_entry || !def || !readable(def, 0xA0) || !src_sub || !readable(src_sub, 0x20)) return not_ready("starting weapon data is incomplete");
    if (!dst_sub || dst_sub == src_sub || !writable(dst_sub, 0x20)) return not_ready("game did not preallocate an independent slot subobject");

    const int clip = std::max(1, (int)*(const uint8_t *)(uintptr_t)(def + 0x60));
    const uint32_t ammo_type = r32(def + 0x64);
    if (ammo_type > 9) return not_ready("starting weapon has an invalid ammo type");
    const uint32_t reserve_addr = G + 0x2A8 + ammo_type * 2;
    if (!writable(reserve_addr, 2)) return not_ready("reserve ammo is unavailable");
    const int reserve = *(const uint16_t *)(uintptr_t)reserve_addr;

    *(uint8_t *)(uintptr_t)dst_obj = *(const uint8_t *)(uintptr_t)held;
    *(uint32_t *)(uintptr_t)(dst_obj + 0xE8) = src_entry;
    *(uint32_t *)(uintptr_t)(dst_obj + 0xEC) = def;
    *(uint32_t *)(uintptr_t)(dst_sub + 0x00) = r32(def + 0x90);
    *(uint32_t *)(uintptr_t)(dst_sub + 0x08) = def;
    *(uint32_t *)(uintptr_t)(dst_sub + 0x0C) = def;
    *(uint32_t *)(uintptr_t)(dst_sub + 0x14) = r32(def + 0x98);
    *(uint16_t *)(uintptr_t)(dst_sub + 0x18) = (uint16_t)clip;
    *(uint8_t *)(uintptr_t)(dst_sub + 0x1A) = (uint8_t)std::min(255, reserve / clip);

    last_not_ready_G = 0;
    logf("[armory] duplicated starting weapon %d into slot %d", (int)*(const uint8_t *)(uintptr_t)held, target_slot);
}

// Keep reserve ammunition within the configured number of spare magazines. BLACK stores reserve by ammo type,
// so if both carried weapons share an ammo type, the lower configured capacity is the effective shared limit.
void enforce_reserve_limits()
{
    uint32_t G = player_state(), arr = G ? r32(G + 0x2C8) : 0;
    if (!G || !arr) return;
    std::array<int, 10> cap{};
    cap.fill(999);
    std::array<bool, 10> used{};
    for (int slot = 0; slot < 2; ++slot) {
        uint32_t obj = r32(arr + slot * 4);
        if (!slot_occupied(obj)) continue;
        int id = *(const uint8_t *)(uintptr_t)obj;
        uint32_t def = r32(obj + 0xEC);
        if (id < 0 || id >= 17 || !def || !readable(def, 0x68)) continue;
        int clip = *(const uint8_t *)(uintptr_t)(def + 0x60);
        uint32_t ammo_type = r32(def + 0x64);
        if (clip < 1 || ammo_type >= cap.size()) continue;
        cap[ammo_type] = std::min(cap[ammo_type], std::min(clip * max_mags_for_weapon(id), 999));
        used[ammo_type] = true;
    }
    for (uint32_t ammo_type = 0; ammo_type < cap.size(); ++ammo_type) {
        if (!used[ammo_type]) continue;
        uint32_t reserve_addr = G + 0x2A8 + ammo_type * 2;
        if (!writable(reserve_addr, 2)) continue;
        uint16_t &reserve = *(uint16_t *)(uintptr_t)reserve_addr;
        if (reserve > cap[ammo_type]) reserve = (uint16_t)cap[ammo_type];
        for (int slot = 0; slot < 2; ++slot) {
            uint32_t obj = r32(arr + slot * 4);
            if (!slot_occupied(obj)) continue;
            uint32_t def = r32(obj + 0xEC), sub = r32(obj + 0xF4);
            if (!def || !sub || r32(def + 0x64) != ammo_type || !writable(sub + 0x1A, 1)) continue;
            int clip = std::max(1, (int)*(const uint8_t *)(uintptr_t)(def + 0x60));
            *(uint8_t *)(uintptr_t)(sub + 0x1A) = (uint8_t)std::min(255, (int)reserve / clip);
        }
    }
}

// Weapon definitions hold magazine capacity at +0x60. Keep the original byte for each definition so an INI value
// of zero restores the game's capacity, and clamp carried magazines after changing that capacity.
void apply_magazine_size_settings()
{
    uint32_t tbl = weapon_table();
    if (!tbl) return;
    for (int id = 0; id < 17; ++id) {
        uint32_t def = r32(tbl + id * 0x20 + 8);
        if (!def || !writable(def, 0x61)) continue;
        if (g_weapon_def[id] != def) {
            g_weapon_def[id] = def;
            g_original_magazine_size[id] = *(uint8_t *)(uintptr_t)(def + 0x60);
        }
        int configured = magazine_size_setting(id);
        uint8_t desired = configured ? (uint8_t)configured : g_original_magazine_size[id];
        *(uint8_t *)(uintptr_t)(def + 0x60) = desired;
    }
    uint32_t G = player_state(), arr = G ? r32(G + 0x2C8) : 0;
    if (!arr) return;
    for (int slot = 0; slot < 2; ++slot) {
        uint32_t obj = r32(arr + slot * 4);
        if (!slot_occupied(obj)) continue;
        uint32_t def = r32(obj + 0xEC), sub = r32(obj + 0xF4);
        if (!def || !sub || !writable(sub + 0x18, 2)) continue;
        uint16_t &loaded = *(uint16_t *)(uintptr_t)(sub + 0x18);
        uint8_t capacity = *(uint8_t *)(uintptr_t)(def + 0x60);
        if (loaded > capacity) loaded = capacity;
    }
}

// The cards of the current tab. WEAPONS: all of weapons.txt. AMMO: only the weapons the player carries right now.
void refresh_view()
{
    g_view.clear();
    for (int i = 0; i < (int)g_weapons.size(); i++)
        if (g_tab != TAB_AMMO || carried(g_weapons[i].id)) g_view.push_back(i);
    int count = (int)g_view.size();
    g_sel = std::max(0, std::min(g_sel, count - 1));
    g_scroll = std::max(0, std::min(g_scroll, std::max(0, (count + kCols - 1) / kCols - kVisRows)));
    int row = g_sel / kCols;
    if (row < g_scroll) g_scroll = row;
    if (row >= g_scroll + kVisRows) g_scroll = row - kVisRows + 1;
}

// ---- slow motion -----------------------------------------------------------------------------------------------------
uint32_t dt_site_addr(int i)
{
    if (i == 0) return 0x2F3A38; // the global frame time
    if (i == 1) {                // the clock object's copy
        uint32_t c = r32(0x2D45D4);
        return c ? c + 0x1C : 0;
    }
    uint32_t g = r32(0x2D45F0); // the game object's frame time (44 users)
    return g ? g + 0x2013C : 0;
}

void update_time_scale()
{
    if (g_target < 1.0f && !g_slow_active && !g_slow_failed) { // start: remember the normal frame times
        g_dt_n = 0;
        for (int i = 0; i < 3; i++) {
            uint32_t a = dt_site_addr(i);
            if (!a || !writable(a, 4)) continue;
            float v = *(const float *)(uintptr_t)a;
            if (!(v > 0.0005f && v < 0.2f)) continue;
            g_dt[g_dt_n++] = {i, a, v};
            logf("[armory] slow motion site %d at %08x = %g", i, a, v);
        }
        if (!g_dt_n) {
            logf("[armory] slow motion: no frame time found");
            g_slow_failed = true;
            return;
        }
        g_slow_active = true;
        g_scale = 1.0f;
    }
    if (!g_slow_active) return;
    g_scale += (g_target - g_scale) * 0.2f;
    bool done = g_target >= 1.0f && g_scale > 0.995f;
    for (int i = 0; i < g_dt_n; i++) {
        if (dt_site_addr(g_dt[i].idx) != g_dt[i].addr || !writable(g_dt[i].addr, 4)) { // the game moved on: leave it
            g_slow_active = false;
            g_scale = 1.0f;
            g_target = 1.0f;
            audio_out::set_game_speed(1.0f);
            return;
        }
        *(float *)(uintptr_t)g_dt[i].addr = done ? g_dt[i].orig : g_dt[i].orig * g_scale;
    }
    audio_out::set_game_speed(done ? 1.0f : std::max(g_scale, kAudioMin)); // game sounds slow down with the world
    if (done) {
        g_slow_active = false;
        g_scale = 1.0f;
    }
}

// ---- kills -> credits and notifications -----------------------------------------------------------------------------
void on_kills(uint32_t n, ULONGLONG now)
{
    for (uint32_t i = 0; i < n; i++) {
        g_feed.push_back({now, kPointsPerKill});
        if ((int)g_feed.size() > kFeedMax) g_feed.erase(g_feed.begin());
    }
    if (now - g_pop_t0 > kPopLife) g_pop_pts = g_pop_kills = 0; // the last one faded: count from zero again
    g_pop_pts += (int)n * kPointsPerKill;
    g_pop_kills += (int)n;
    g_pop_t0 = now;
    sfx::play(sfx::KILL);
}

void update_credits()
{
    if (!readable(kKillCounter, 2)) {
        g_kills_valid = false;
        return;
    }
    uint32_t k = *(const uint16_t *)(uintptr_t)kKillCounter;
    if (!g_kills_valid) { // first read: just remember it
        g_kills_last = k;
        g_kills_valid = true;
        return;
    }
    uint32_t d = (k - g_kills_last) & 0xFFFF; // 16-bit counter: a wrap-around still counts, a reset gives a huge d
    if (d >= 1 && d <= 10) {
        g_credits += (int)d * kPointsPerKill;
        save_credits();
        on_kills(d, GetTickCount64());
    }
    g_kills_last = k; // a reset or a big jump (mission load) only resyncs, it gives nothing
}

// ---- buying --------------------------------------------------------------------------------------------------------
void set_msg(const wchar_t *m)
{
    wcsncpy_s(g_msg, m, _TRUNCATE);
    g_msg_at = GetTickCount64();
}

void deny(const wchar_t *m)
{
    set_msg(m);
    sfx::play(sfx::DENY);
}

void buy_weapon()
{
    const Weapon &w = g_weapons[g_view[g_sel]];
    if (g_credits < w.price) return deny(L"NOT ENOUGH CREDITS");
    int r = give_weapon(w.id);
    if (r == 0) {
        g_credits -= w.price;
        save_credits();
        set_msg(L"PURCHASED - SWITCHING WEAPON");
        bindings::queue_weapon_refresh();
        sfx::play(sfx::BUY);
    } else deny(r == 1 ? L"WEAPON DATA NOT READY" : L"NO WEAPON SLOT TO REPLACE");
}

// one magazine of ammo for the selected weapon, which the player must carry
void buy_ammo()
{
    const Weapon &w = g_weapons[g_view[g_sel]];
    int clip, reserve, max_reserve;
    if (!reserve_info(w.id, clip, reserve, max_reserve)) return deny(L"WEAPON DATA NOT READY");
    uint32_t obj = carried(w.id);
    if (!obj) return deny(L"YOU DO NOT CARRY THIS WEAPON");
    if (reserve >= max_reserve) return deny(L"AMMO FULL");
    if (g_credits < w.ammo_price) return deny(L"NOT ENOUGH CREDITS");
    int at;
    weapon_info(w.id, clip, at);
    uint32_t G = player_state(), ra = G + 0x2A8 + at * 2, sub = r32(obj + 0xF4);
    if (!writable(ra, 2)) return deny(L"WEAPON DATA NOT READY");
    reserve = std::min(reserve + clip, max_reserve);
    *(uint16_t *)(uintptr_t)ra = (uint16_t)reserve;
    if (sub && writable(sub + 0x1A, 1)) *(uint8_t *)(uintptr_t)(sub + 0x1A) = (uint8_t)std::min(255, reserve / clip);
    g_credits -= w.ammo_price;
    save_credits();
    set_msg(L"AMMO ADDED");
    sfx::play(sfx::BUY);
}

void close_armory()
{
    g_open = false;
    sfx::music(false, kArmoryMusicCfg);
    g_wait_release = true;
    g_target = 1.0f; // back to normal speed
}

// ---- input ---------------------------------------------------------------------------------------------------------
struct Repeat {
    bool prev;
    ULONGLONG next;
};
bool repeat(Repeat &r, bool down, ULONGLONG now)
{
    if (!down) {
        r.prev = false;
        return false;
    }
    if (!r.prev) {
        r.prev = true;
        r.next = now + 350;
        return true;
    }
    if (now >= r.next) {
        r.next = now + 90;
        return true;
    }
    return false;
}
bool edge(bool &prev, bool down)
{
    bool e = down && !prev;
    prev = down;
    return e;
}

void move_selection(int dx, int dy)
{
    int count = (int)g_view.size(), s = g_sel;
    if (g_tab == TAB_WEAPONS) { // slider: left/right (or up/down) step through the weapons, wrapping around
        int step = dx != 0 ? dx : dy;
        if (count > 0 && step != 0) s = (s + step + count) % count;
        g_sel = s;
        g_scroll = 0;
        return;
    }
    if (dx < 0 && s % kCols > 0) s--;
    if (dx > 0 && s % kCols < kCols - 1 && s + 1 < count) s++;
    if (dy < 0 && s - kCols >= 0) s -= kCols;
    if (dy > 0 && s + kCols < count) s += kCols;
    g_sel = s;
    int row = g_sel / kCols;
    if (row < g_scroll) g_scroll = row;
    if (row >= g_scroll + kVisRows) g_scroll = row - kVisRows + 1;
}

void switch_tab(int to)
{
    if (g_tab < 2) { // remember this tab's selection
        g_sel_saved[g_tab] = g_sel;
        g_scroll_saved[g_tab] = g_scroll;
    }
    g_tab = to;
    if (g_tab < 2) {
        g_sel = g_sel_saved[g_tab];
        g_scroll = g_scroll_saved[g_tab];
    }
    refresh_view();
}

std::wstring money(int v)
{
    wchar_t b[24];
    swprintf_s(b, L"%d", v);
    std::wstring s = b, out;
    for (size_t i = 0; i < s.size(); i++) {
        if (i && (s.size() - i) % 3 == 0) out += L',';
        out += s[i];
    }
    return out;
}

// Presentation-only profiles for the armory's stat bars. The current game-memory reader exposes clip/ammo data,
// not these combat ratings, so these values are archetype estimates used only by the UI (not game-engine values).
struct DisplayStats {
    int damage, accuracy, range, fire_rate;
    std::wstring line1, line2;
};

DisplayStats display_stats(const Weapon &w)
{
    const std::wstring &name = w.name;
    const std::wstring &type = w.type;
    if (type.find(L"SHOTGUN") != std::wstring::npos || name.find(L"SPAS") != std::wstring::npos)
        return {88, 38, 25, 120, L"Heavy damage at close range.", L"Spread limits effective range."};
    if (type.find(L"SNIPER") != std::wstring::npos || name.find(L"SNIP") != std::wstring::npos)
        return {92, 92, 96, 55, L"High accuracy at long range.", L"Powerful, slower follow-up shots."};
    if (type.find(L"LAUNCH") != std::wstring::npos || name.find(L"RPG") != std::wstring::npos)
        return {96, 42, 78, 70, L"Heavy explosive impact.", L"Best against groups of enemies."};
    if (type.find(L"SMG") != std::wstring::npos || name.find(L"P90") != std::wstring::npos ||
        name.find(L"MP5") != std::wstring::npos || name.find(L"UZI") != std::wstring::npos)
        return {22, 56, 40, 900, L"High rate of fire, low recoil.", L"Effective at close to mid range."};
    if (type.find(L"ASSAULT") != std::wstring::npos || type.find(L"RIFLE") != std::wstring::npos ||
        name.find(L"AK") != std::wstring::npos || name.find(L"M16") != std::wstring::npos)
        return {64, 68, 72, 650, L"Balanced damage and accuracy.", L"Versatile at medium range."};
    if (type.find(L"HANDGUN") != std::wstring::npos || type.find(L"SIDEARM") != std::wstring::npos ||
        name.find(L"PISTOL") != std::wstring::npos || name.find(L"EAGLE") != std::wstring::npos)
        return {70, 60, 52, 250, L"Compact and dependable sidearm.", L"Useful when a primary runs dry."};
    return {55, 60, 58, 500, L"A versatile field weapon.", L"Review its profile before buying."};
}

} // namespace

int current_weapon_id() { return current_weapon_id_impl(); }
int current_weapon_slot() { return current_weapon_slot_impl(); }

bool is_open()
{
    // The render thread calls this while the input thread can open or close the armory.
    std::lock_guard<std::mutex> lk(g_mu);
    return g_open;
}

bool has_overlay()
{
    std::lock_guard<std::mutex> lk(g_mu);
    if (g_open) return true;
    ULONGLONG now = GetTickCount64();
    if (g_pop_pts > 0 && now - g_pop_t0 < kPopLife) return true;
    for (const FeedItem &i : g_feed)
        if (now - i.t0 < kFeedLife) return true;
    std::wstring title, artist;
    float alpha = 0.0f;
    return sfx::radio_now_playing(title, artist, alpha);
}

bool poll(bool focus, uint16_t buttons, const uint8_t analog[8])
{
    std::lock_guard<std::mutex> lk(g_mu);
    apply_magazine_size_settings();
    ensure_second_weapon_slot();
    enforce_reserve_limits();
    load_credits();
    update_credits();
    update_time_scale();
    ULONGLONG now = GetTickCount64();
    auto key = [&](int vk) { return focus && (GetAsyncKeyState(vk) & 0x8000) != 0; };
    bool pad_a = analog[0] > 128, pad_b = analog[1] > 128;

    static bool tog_prev, ok_prev, back_prev, next_prev, prev_prev;
    static Repeat r_up, r_down, r_left, r_right;
    bool tog = edge(tog_prev, key(kKeyToggle) || key(kKeyToggle2) || (focus && (buttons & kPadToggle) != 0));
    bool up = repeat(r_up, key(VK_UP) || key('W') || (buttons & 1), now);
    bool down = repeat(r_down, key(VK_DOWN) || key('S') || (buttons & 2), now);
    bool left = repeat(r_left, key(VK_LEFT) || key('A') || (buttons & 4), now);
    bool right = repeat(r_right, key(VK_RIGHT) || key('D') || (buttons & 8), now);
    bool ok = edge(ok_prev, key(VK_RETURN) || key(VK_SPACE) || pad_a);
    bool back = edge(back_prev, key(VK_ESCAPE) || key(VK_BACK) || pad_b);
    bool tab_next = edge(next_prev, key(VK_TAB) || key('E') || analog[4] > 128); // E, Tab, BLACK (right shoulder)
    bool tab_prev = edge(prev_prev, key('Q') || analog[5] > 128);                // Q, WHITE (left shoulder)

    if (!g_open) {
        if (g_wait_release) { // closed this very moment: the keys that closed it must not reach the game (Esc = pause)
            bool held = key(VK_ESCAPE) || key(VK_BACK) || key(VK_RETURN) || key(VK_SPACE) || key(kKeyToggle) ||
                        key(kKeyToggle2) || (buttons & kPadToggle) != 0 || pad_a || pad_b;
            if (held) return true;
            g_wait_release = false;
        }
        if (tog && focus && bindings::in_play()) {
            g_open = true;
            sfx::music(true, kArmoryMusicCfg);
            g_msg[0] = 0;
            g_reload_pending = true; // read weapons.txt and the PNG files again
            load_weapons();
            g_target = kSlowFactor; // slow motion while shopping
            g_slow_failed = false;
            sfx::play(sfx::OPEN);
            logf("[armory] open");
            log_slots("open");
            return true;
        }
        return false;
    }
    if (tog || back || !bindings::in_play()) {
        logf("[armory] closed");
        close_armory();
        return true;
    }
    if (tab_next) switch_tab((g_tab + 1) % kTabs);
    if (tab_prev) switch_tab((g_tab + kTabs - 1) % kTabs);
    refresh_view(); // what is carried can change while it is open
    if (g_tab != TAB_EXIT && (left || right || up || down))
        move_selection((right ? 1 : 0) - (left ? 1 : 0), (down ? 1 : 0) - (up ? 1 : 0));
    if (ok) {
        if (g_tab == TAB_EXIT) {
            close_armory();
            return true;
        }
        if (g_sel >= 0 && g_sel < (int)g_view.size()) {
            if (g_tab == TAB_WEAPONS) buy_weapon();
            else buy_ammo();
        }
    }
    return true;
}

// ---- layout --------------------------------------------------------------------------------------------------------
namespace {
uint32_t fade(uint32_t c, float a)
{
    a = std::max(0.0f, std::min(1.0f, a));
    return (c & 0x00FFFFFFu) | ((uint32_t)(((c >> 24) & 0xFF) * a) << 24);
}
float ease_out(float x)
{
    x = std::max(0.0f, std::min(1.0f, x));
    return 1 - (1 - x) * (1 - x) * (1 - x);
}

// Kill notifications, drawn while the armory is closed: ribbons sliding in from the right (newest on top) and a
// centre "+points" that pops, drifts up and fades, adding up while kills keep coming (DOUBLE KILL, TRIPLE KILL ...).
void build_feed(Frame &f, ULONGLONG now)
{
    auto R = [&](float x0, float y0, float x1, float y1, uint32_t c) { f.rects.push_back({x0, y0, x1, y1, c}); };
    auto T = [&](float x, float y, float h, uint32_t c, int align, float track, const std::wstring &s) {
        f.texts.push_back({x, y, h, c, align, track, s});
    };
    int row = 0;
    for (int i = (int)g_feed.size() - 1; i >= 0; i--) {
        float age = (float)(now - g_feed[i].t0);
        if (age > kFeedLife) continue;
        float out = age > kFeedLife - 400 ? (age - (kFeedLife - 400)) / 400.0f : 0.0f, a = 1.0f - out;
        float dx = (1.0f - ease_out(age / 250.0f)) * 0.25f + out * 0.04f; // slide in, then a little out
        float x0 = 0.735f + dx, x1 = 0.965f + dx, y0 = 0.28f + row * 0.062f, y1 = y0 + 0.052f;
        row++;
        R(x0, y0, x1, y1, fade(kPanel, a));
        R(x0, y0, x0 + 0.004f, y1, fade(kGreen, a));
        T(x0 + 0.016f, y0 + 0.014f, 0.022f, fade(kTxt, a), 0, 0.08f, L"ENEMY KILLED");
        wchar_t b[16];
        swprintf_s(b, L"+%d", g_feed[i].pts);
        T(x1 - 0.012f, y0 + 0.012f, 0.026f, fade(kTxtGreen, a), 2, 0.0f, b);
    }
    float age = (float)(now - g_pop_t0);
    if (g_pop_pts > 0 && age < kPopLife) {
        float pop = age < 160 ? 1.0f + 0.5f * (1.0f - ease_out(age / 160.0f)) : 1.0f; // starts 50% big, settles
        float a = age > kPopLife - 500 ? 1.0f - (age - (kPopLife - 500)) / 500.0f : 1.0f;
        float y = 0.60f - 0.03f * ease_out(age / (float)kPopLife) - (pop - 1.0f) * 0.03f;
        wchar_t b[24];
        swprintf_s(b, L"+%d", g_pop_pts);
        T(0.5f, y, 0.058f * pop, fade(kTxt, a), 1, 0.02f, b);
        wchar_t lab[32];
        if (g_pop_kills <= 1) wcscpy_s(lab, L"ENEMY KILLED");
        else if (g_pop_kills == 2) wcscpy_s(lab, L"DOUBLE KILL");
        else if (g_pop_kills == 3) wcscpy_s(lab, L"TRIPLE KILL");
        else swprintf_s(lab, L"MULTI KILL x%d", g_pop_kills);
        T(0.5f, 0.675f, 0.022f, fade(kTxtGreen, a), 1, 0.2f, lab);
    }
}

// The armory itself.
void build_armory(Frame &f)
{
    f.reload_images = g_reload_pending;
    g_reload_pending = false;
    auto R = [&](float x0, float y0, float x1, float y1, uint32_t c) { f.rects.push_back({x0, y0, x1, y1, c}); };
    auto I = [&](float x0, float y0, float x1, float y1, const std::string &key, const std::string &alt) {
        f.images.push_back({x0, y0, x1, y1, 0xFFFFFFFFu, key, alt});
    };
    auto T = [&](float x, float y, float h, uint32_t c, int align, float track, const std::wstring &s) {
        f.texts.push_back({x, y, h, c, align, track, s});
    };
    auto outline = [&](float x0, float y0, float x1, float y1, float t, uint32_t c) {
        R(x0, y0, x1, y0 + t, c);
        R(x0, y1 - t, x1, y1, c);
        R(x0, y0, x0 + t, y1, c);
        R(x1 - t, y0, x1, y1, c);
    };

    refresh_view();
    const int count = (int)g_view.size();
    const bool ammo = g_tab == TAB_AMMO;
    const char *folder = ammo ? "ammo/" : "weapons/";

    // A tinted veil calms the live gameplay image behind the shop. True Gaussian blur must be implemented in the
    // D3D compositor; this overlay layer only has rectangle/image/text primitives available.
    R(0.0f, 0.0f, 1.0f, 1.0f, 0x6803070B);
    R(0.0f, 0.0f, 1.0f, 1.0f, 0x160A1720);

    // Minimal BLACK title block and fine divider, matching the subdued original-game menu language.
    T(0.042f, 0.043f, 0.058f, kTxt, 0, 0.035f, L"BLACK");
    T(0.043f, 0.119f, 0.025f, kTxtDim, 0, 0.245f, L"WEAPON ARMORY");
    R(0.042f, 0.163f, 0.254f, 0.1655f, 0xA0AAB5AF);

    // Compact credit readout in the upper-right corner.
    R(0.796f, 0.043f, 0.960f, 0.094f, 0xA0091012);
    outline(0.796f, 0.043f, 0.960f, 0.094f, 0.0016f, 0x7056635D);
    R(0.796f, 0.043f, 0.960f, 0.046f, 0xA07B8D82);
    T(0.806f, 0.057f, 0.019f, kTxtGreen, 0, 0.09f, L"CREDITS");
    T(0.949f, 0.050f, 0.031f, kTxt, 2, 0.0f, money(g_credits));

    // Left navigation. The selected tab gets a narrow olive marker rather than a large opaque panel.
    for (int t = 0; t < kTabs; t++) {
        float y = 0.251f + t * 0.050f;
        if (t == g_tab) {
            R(0.0f, y, 0.195f, y + 0.048f, kTab);
            R(0.0f, y, 0.0035f, y + 0.048f, kGreen);
            T(0.043f, y + 0.008f, 0.027f, kTxt, 0, 0.0f, L"> ");
        }
        T(0.064f, y + 0.008f, 0.027f, t == g_tab ? kTxt : kTxtDim, 0, 0.19f, kTabName[t]);
    }

    if (g_tab == TAB_EXIT || count == 0) {
        if (g_tab == TAB_AMMO) {
            T(0.30f, 0.40f, 0.030f, kTxt, 0, 0.06f, L"YOU CARRY NO WEAPON TO BUY AMMO FOR");
            T(0.30f, 0.46f, 0.022f, kTxtDim, 0, 0.04f, L"BUY A WEAPON IN THE WEAPONS TAB FIRST");
        } else {
            T(0.45f, 0.45f, 0.030f, kTxtDim, 1, 0.04f, L"PRESS ENTER OR A TO CLOSE");
        }
        T(0.958f, 0.906f, 0.018f, kTxtDim, 2, 0.025f, L"ESC / B  BACK");
        return;
    }

    // Two-column, three-row weapon grid. The thin outlines and restrained selection glow keep it close to the target.
    constexpr float cardX = 0.235f, cardY = 0.231f, cardW = 0.208f, cardH = 0.174f;
    constexpr float colStep = 0.2165f, rowStep = 0.186f;
    for (int row = 0; row < (ammo ? kVisRows : 0); row++) { // the WEAPONS tab is a slider, only AMMO keeps the cards
        for (int col = 0; col < kCols; col++) {
            int i = (g_scroll + row) * kCols + col;
            if (i >= count) continue;
            const Weapon &w = g_weapons[g_view[i]];
            float x = cardX + col * colStep, y = cardY + row * rowStep;
            bool sel = i == g_sel;
            R(x, y, x + cardW, y + cardH, sel ? kCardSel : kCard);
            outline(x, y, x + cardW, y + cardH, sel ? 0.0022f : 0.0010f,
                    sel ? kGreen : kOutline);
            if (sel) {
                R(x + 0.008f, y + cardH - 0.004f, x + cardW - 0.008f, y + cardH - 0.0015f, kGreen);
                T(x + 0.003f, y + 0.060f, 0.030f, kTxtGreen, 0, 0.0f, L"> ");
            }
            I(x + 0.015f, y + 0.012f, x + cardW - 0.013f, y + 0.125f,
              folder + std::to_string(w.id), std::string(folder) + "default");
            T(x + 0.013f, y + 0.135f, 0.023f, kTxt, 0, 0.035f, w.name);
            T(x + cardW - 0.013f, y + 0.135f, 0.023f, kTxtDim, 2, 0.0f,
              money(ammo ? w.ammo_price : w.price));
        }
    }

    // A slim scroll indicator appears only when the list actually extends beyond the six visible cards.
    int rows = (count + kCols - 1) / kCols;
    if (ammo && rows > kVisRows) {
        float y0 = cardY, y1 = cardY + 3.0f * rowStep - 0.010f;
        float th = (float)kVisRows / (float)rows * (y1 - y0);
        float ty = y0 + (y1 - y0 - th) * g_scroll / std::max(rows - kVisRows, 1);
        R(0.672f, y0, 0.6745f, y1, 0x503E4A46);
        R(0.672f, ty, 0.6745f, ty + th, kGreen);
    }

    // WEAPONS tab: one live full-screen background model; the image bounds are used by the PNG fallback.
    if (!ammo) {
        constexpr float bx0 = 0.17f, by0 = 0.10f, bx1 = 0.71f, by1 = 0.84f; // big, no frame: the gun floats over the blurred level
        const Weapon &sw = g_weapons[g_view[g_sel]];
        I(bx0, by0, bx1, by1 - 0.06f, folder + std::to_string(sw.id), std::string(folder) + "default");
        f.images.back().is3d = true; // a live 3D model when armory\\models\\<name>.gmesh exists
        T(bx0 + 0.005f, 0.43f, 0.070f, kTxtGreen, 0, 0.0f, L"<");
        T(bx1 - 0.005f, 0.43f, 0.070f, kTxtGreen, 2, 0.0f, L">");
        wchar_t cb[32];
        swprintf_s(cb, L"%d / %d", g_sel + 1, count);
        T((bx0 + bx1) * 0.5f, by1 - 0.060f, 0.024f, kTxt, 1, 0.12f, cb);
        T((bx0 + bx1) * 0.5f, by1 - 0.025f, 0.015f, kTxtDim, 1, 0.04f,
          L"LEFT / RIGHT  WEAPON     STICK LEFT / RIGHT  ROTATE     STICK UP / DOWN  ZOOM     +/-  ZOOM");
    }

    // Right-hand details pane.
    const Weapon &w = g_weapons[g_view[g_sel]];
    const int price = ammo ? w.ammo_price : w.price;
    const DisplayStats stats = display_stats(w);
    if (ammo) { // the AMMO tab keeps its framed pane; the WEAPONS tab has no boxes
        R(0.693f, 0.203f, 0.960f, 0.777f, kPanel);
        outline(0.693f, 0.203f, 0.960f, 0.777f, 0.0012f, kOutline);
    }
    T(0.710f, 0.218f, 0.037f, kTxt, 0, 0.025f, w.name);
    T(0.711f, 0.260f, 0.020f, kTxtGreen, 0, 0.08f, ammo ? std::wstring(L"AMMUNITION") : w.type);
    if (ammo) I(0.720f, 0.286f, 0.935f, 0.414f, folder + std::to_string(w.id), std::string(folder) + "default");
    T(0.710f, 0.432f, 0.017f, kTxtDim, 0, 0.0f, stats.line1);
    T(0.710f, 0.454f, 0.017f, kTxtDim, 0, 0.0f, stats.line2);
    R(0.710f, 0.482f, 0.943f, 0.4835f, 0x503D4844);

    // Cosmetic stat bars. Actual combat values are not exposed by the current reader; clip/reserve remain real game data.
    const float statY[4] = {0.497f, 0.525f, 0.553f, 0.581f};
    const wchar_t *statName[4] = {L"DAMAGE", L"ACCURACY", L"RANGE", L"FIRE RATE"};
    const int statValue[4] = {stats.damage, stats.accuracy, stats.range, stats.fire_rate};
    for (int j = 0; j < 4; j++) {
        T(0.710f, statY[j], 0.016f, kTxtDim, 0, 0.0f, statName[j]);
        R(0.781f, statY[j] + 0.005f, 0.919f, statY[j] + 0.014f, kBarBg);
        float fraction = j == 3 ? std::min(1.0f, statValue[j] / 1000.0f)
                                : std::min(1.0f, std::max(0.0f, statValue[j] / 100.0f));
        R(0.781f, statY[j] + 0.005f, 0.781f + (0.138f * fraction), statY[j] + 0.014f, kBarFill);
        wchar_t n[16];
        swprintf_s(n, L"%d", statValue[j]);
        T(0.939f, statY[j] - 0.001f, 0.016f, kTxtDim, 2, 0.0f, n);
    }

    // Preserve the useful live ammo information without crowding the main weapon profile.
    wchar_t b[64];
    int clip = 0, reserve = 0, maxr = 0, at = 0;
    if (ammo) {
        if (reserve_info(w.id, clip, reserve, maxr)) {
            if (carried(w.id)) swprintf_s(b, L"MAG %d   RESERVE %d / %d", clip, reserve, maxr);
            else wcscpy_s(b, L"WEAPON NOT CARRIED");
            T(0.710f, 0.612f, 0.015f, kTxtDim, 0, 0.0f, b);
        } else {
            T(0.710f, 0.612f, 0.015f, kTxtDim, 0, 0.0f, L"AMMO DATA NOT READY");
        }
    } else if (weapon_info(w.id, clip, at)) {
        swprintf_s(b, L"MAGAZINE %d ROUNDS", clip);
        T(0.710f, 0.612f, 0.015f, kTxtDim, 0, 0.0f, b);
    } else {
        T(0.710f, 0.612f, 0.015f, kTxtDim, 0, 0.0f, L"WEAPON DATA NOT LOADED YET");
    }

    if (g_msg[0] && GetTickCount64() - g_msg_at < 4000)
        T(0.710f, 0.644f, 0.016f, kTxtGreen, 0, 0.0f, g_msg);

    // Large, quiet purchase action; held inside the detail panel like the reference image.
    R(0.710f, 0.682f, 0.944f, 0.746f, kBuyBar);
    outline(0.710f, 0.682f, 0.944f, 0.746f, 0.0015f, kGreen);
    T(0.827f, 0.697f, 0.026f, kTxt, 1, 0.06f,
      (ammo ? std::wstring(L"BUY MAG   ") : std::wstring(L"BUY   ")) + money(price));

    // Keep the key hints quiet and aligned to the lower-right edge.
    T(0.824f, 0.909f, 0.018f, kTxtDim, 0, 0.025f, L"ENTER / A  SELECT");
    T(0.958f, 0.909f, 0.018f, kTxtDim, 2, 0.025f, L"ESC / B  BACK");
}
} // namespace

void build(Frame &f)
{
    std::lock_guard<std::mutex> lk(g_mu);
    f.rects.clear();
    f.images.clear();
    f.texts.clear();
    f.reload_images = false;
    if (!g_open) {
        build_feed(f, GetTickCount64());
        std::wstring title, artist;
        float alpha = 0.0f;
        if (sfx::radio_now_playing(title, artist, alpha)) {
            uint32_t text_color = ((uint32_t)(std::clamp(alpha, 0.0f, 1.0f) * 255.0f) << 24) | 0x00FFFFFFu;
            if (!title.empty()) f.texts.push_back({0.035f, 0.900f, 0.022f, text_color, 0, 0.0f, title, true});
            if (!artist.empty()) f.texts.push_back({0.035f, 0.929f, 0.018f, text_color, 0, 0.0f, artist, true});
        }
        return;
    }
    if (g_weapons.empty()) load_weapons();
    build_armory(f);
}

} // namespace armory
