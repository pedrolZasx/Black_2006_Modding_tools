#include "ui/gun3d.h"

#include <algorithm>
#include <atomic>
#include <climits>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <new>
#include <string>
#include <thread>
#include <vector>

namespace gun3d {
namespace {

// ---- limits: a bad or huge file can never take the game down --------------------------------------------------------
constexpr uint32_t kMaxFileBytes = 16u * 1024 * 1024;
constexpr uint32_t kMaxVerts = 65535; // 16-bit indices
constexpr uint32_t kMaxIndices = 3 * 100000;
constexpr uint32_t kMaxTexSide = 1024;

// weapon id -> file name (without extension). Only the pistol has a converted model so far.
const char *const kNames[17] = {"bg1_pst", "bg1_shg", "bg1_snr", "bg1_smg", "bg1_asr", "bg1_ak1", "bg1_rpg", "bg1_grl", "bg1_sm3",
                                "bg1_p90", "bg1_hvy", "bg1_mgn", "bg1_m16", "bg1_rm1", "bg1_gk1", "bg1_mp1", "bg1_bns"};

struct Model {
    std::vector<float> pos; // x,y,z per vertex (barrel along x, y up)
    std::vector<float> uv;  // u,v per vertex
    std::vector<float> nrm; // smooth normal per vertex
    std::vector<uint16_t> idx; // triangle list
    std::vector<uint8_t> bgra; // texture pixels
    uint32_t tw = 0, th = 0;
    std::vector<std::vector<uint8_t>> mips; // BGRA mip chain, level 0 = full size (built on the loader thread)
    std::vector<uint32_t> mw, mh;
    void clear()
    {
        std::vector<std::vector<uint8_t>>().swap(mips);
        std::vector<uint32_t>().swap(mw);
        std::vector<uint32_t>().swap(mh);
        std::vector<float>().swap(pos);
        std::vector<float>().swap(uv);
        std::vector<float>().swap(nrm);
        std::vector<uint16_t>().swap(idx);
        std::vector<uint8_t>().swap(bgra);
        tw = th = 0;
    }
};

enum State { kNone, kLoading, kReady, kFailed };

std::atomic<int> g_state{kNone};
Model g_model;                       // written by the loader thread only while g_state == kLoading
IDirect3DTexture9 *g_tex = nullptr;  // game thread only
int g_id = -1;                       // weapon the slot is for (game thread only)

// view
float g_yaw = 0.35f, g_pitch = -0.25f, g_zoom = 1.0f;
int g_fit_id = -1;
float g_fit_w = 0.0f, g_fit_h = 0.0f, g_fit_scale = 0.0f;
bool g_drag = false;
POINT g_last{0, 0};
ULONGLONG g_last_input = 0, g_last_frame = 0;
std::atomic<int> g_in_dx{0}, g_in_dy{0}, g_in_wheel{0}, g_in_rx{0}, g_in_ry{0}, g_in_lt{0}, g_in_rt{0};

std::string exe_dir()
{
    char p[MAX_PATH];
    DWORD n = GetModuleFileNameA(nullptr, p, MAX_PATH);
    if (n == 0 || n >= MAX_PATH) return std::string();
    std::string s(p, n);
    size_t k = s.find_last_of("\\/");
    return k == std::string::npos ? std::string() : s.substr(0, k + 1);
}

void build_mips(Model &m)
{
    m.mips.clear(); m.mw.clear(); m.mh.clear();
    m.mips.push_back(m.bgra); m.mw.push_back(m.tw); m.mh.push_back(m.th);
    while (m.mw.back() > 1 || m.mh.back() > 1) {
        const std::vector<uint8_t> &p = m.mips.back();
        uint32_t cw = m.mw.back(), ch = m.mh.back(), nw = std::max(1u, cw >> 1), nh = std::max(1u, ch >> 1);
        std::vector<uint8_t> n((size_t)nw * nh * 4);
        for (uint32_t y = 0; y < nh; y++)
            for (uint32_t x = 0; x < nw; x++) {
                uint32_t xa = std::min(cw - 1, x * 2), xb = std::min(cw - 1, x * 2 + 1), ya = std::min(ch - 1, y * 2), yb = std::min(ch - 1, y * 2 + 1);
                for (int k = 0; k < 4; k++)
                    n[((size_t)y * nw + x) * 4 + k] = (uint8_t)((p[((size_t)ya * cw + xa) * 4 + k] + p[((size_t)ya * cw + xb) * 4 + k] +
                                                                  p[((size_t)yb * cw + xa) * 4 + k] + p[((size_t)yb * cw + xb) * 4 + k] + 2) / 4);
            }
        m.mips.push_back(std::move(n)); m.mw.push_back(nw); m.mh.push_back(nh);
    }
}

// ---- background loader ----------------------------------------------------------------------------------------------
void load_main(std::string path)
{
    bool ok = false;
    try {
        FILE *f = nullptr;
        if (fopen_s(&f, path.c_str(), "rb") == 0 && f) {
            fseek(f, 0, SEEK_END);
            long sz = ftell(f);
            fseek(f, 0, SEEK_SET);
            if (sz >= 24 && (uint32_t)sz <= kMaxFileBytes) {
                std::vector<uint8_t> b((size_t)sz);
                if (fread(b.data(), 1, b.size(), f) == b.size()) {
                    uint32_t ver, nv, ni, tw, th;
                    std::memcpy(&ver, &b[4], 4);
                    std::memcpy(&nv, &b[8], 4);
                    std::memcpy(&ni, &b[12], 4);
                    std::memcpy(&tw, &b[16], 4);
                    std::memcpy(&th, &b[20], 4);
                    const bool has_packed_normals = ver == 2;
                    const uint32_t vertex_stride = has_packed_normals ? 32u : 20u;
                    bool head = std::memcmp(b.data(), "GMSH", 4) == 0 && (ver == 1 || has_packed_normals) && nv > 0 && nv <= kMaxVerts && ni > 0 &&
                                ni % 3 == 0 && ni <= kMaxIndices && tw > 0 && th > 0 && tw <= kMaxTexSide && th <= kMaxTexSide;
                    uint64_t need = 24ull + (uint64_t)nv * vertex_stride + (uint64_t)ni * 4 + (uint64_t)tw * th * 4;
                    if (head && need == (uint64_t)sz) {
                        Model &m = g_model;
                        m.clear();
                        m.pos.resize((size_t)nv * 3);
                        m.uv.resize((size_t)nv * 2);
                        m.nrm.assign((size_t)nv * 3, 0.0f);
                        m.idx.resize(ni);
                        m.bgra.resize((size_t)tw * th * 4);
                        m.tw = tw;
                        m.th = th;
                        const uint8_t *p = b.data() + 24;
                        for (uint32_t i = 0; i < nv; i++) {
                            float v[8] = {};
                            std::memcpy(v, p + (size_t)i * vertex_stride, vertex_stride);
                            m.pos[i * 3 + 0] = v[0];
                            m.pos[i * 3 + 1] = v[1];
                            m.pos[i * 3 + 2] = v[2];
                            if (has_packed_normals) {
                                float nl = std::sqrt(v[3] * v[3] + v[4] * v[4] + v[5] * v[5]);
                                if (nl > 1e-20f) {
                                    m.nrm[i * 3 + 0] = v[3] / nl;
                                    m.nrm[i * 3 + 1] = v[4] / nl;
                                    m.nrm[i * 3 + 2] = v[5] / nl;
                                }
                                m.uv[i * 2 + 0] = v[6];
                                m.uv[i * 2 + 1] = v[7];
                            } else {
                                m.uv[i * 2 + 0] = v[3];
                                m.uv[i * 2 + 1] = v[4];
                            }
                        }
                        p += (size_t)nv * vertex_stride;
                        bool idx_ok = true;
                        for (uint32_t i = 0; i < ni; i++) {
                            uint32_t k;
                            std::memcpy(&k, p + (size_t)i * 4, 4);
                            if (k >= nv) {
                                idx_ok = false;
                                break;
                            }
                            m.idx[i] = (uint16_t)k;
                        }
                        p += (size_t)ni * 4;
                        if (idx_ok) {
                            for (size_t i = 0; i < (size_t)tw * th; i++) { // RGBA -> BGRA (D3DFMT_A8R8G8B8)
                                m.bgra[i * 4 + 0] = p[i * 4 + 2];
                                m.bgra[i * 4 + 1] = p[i * 4 + 1];
                                m.bgra[i * 4 + 2] = p[i * 4 + 0];
                                m.bgra[i * 4 + 3] = 255;
                            }
                            // Old GMSH v1 files have no source normals, so estimate them. Version 2 carries the game's
                            // packed NORMPACKED3 normals and should preserve those instead.
                            if (!has_packed_normals) {
                            // Smooth normals that do NOT depend on triangle winding and keep hard edges: every incident
                            // face normal is flipped to agree with the first one, and only faces within ~50 degrees are averaged.
                            const uint32_t nt3 = ni / 3;
                            std::vector<float> fn((size_t)nt3 * 3);
                            std::vector<uint32_t> cnt((size_t)nv + 1, 0), fill((size_t)nv, 0), lst((size_t)ni);
                            for (uint32_t t = 0; t < nt3; t++) {
                                const float *a = &m.pos[m.idx[t * 3] * 3], *bb = &m.pos[m.idx[t * 3 + 1] * 3], *c = &m.pos[m.idx[t * 3 + 2] * 3];
                                float e1[3] = {bb[0] - a[0], bb[1] - a[1], bb[2] - a[2]};
                                float e2[3] = {c[0] - a[0], c[1] - a[1], c[2] - a[2]};
                                fn[t * 3 + 0] = e1[1] * e2[2] - e1[2] * e2[1]; // length = 2 * area
                                fn[t * 3 + 1] = e1[2] * e2[0] - e1[0] * e2[2];
                                fn[t * 3 + 2] = e1[0] * e2[1] - e1[1] * e2[0];
                                for (int k = 0; k < 3; k++) cnt[m.idx[t * 3 + k] + 1]++;
                            }
                            for (uint32_t i = 0; i < nv; i++) cnt[i + 1] += cnt[i];
                            for (uint32_t t = 0; t < nt3; t++)
                                for (int k = 0; k < 3; k++) {
                                    uint32_t v = m.idx[t * 3 + k];
                                    lst[cnt[v] + fill[v]++] = t;
                                }
                            auto unit = [](const float *n, float *o) {
                                float l = std::sqrt(n[0] * n[0] + n[1] * n[1] + n[2] * n[2]);
                                if (l > 1e-20f) { o[0] = n[0] / l; o[1] = n[1] / l; o[2] = n[2] / l; }
                                else o[0] = o[1] = o[2] = 0.0f;
                            };
                            for (uint32_t v = 0; v < nv; v++) {
                                uint32_t b0 = cnt[v], b1 = cnt[v + 1];
                                if (b0 == b1) continue;
                                float ref[3];
                                unit(&fn[lst[b0] * 3], ref);
                                float acc[3] = {0, 0, 0};
                                for (uint32_t q = b0; q < b1; q++) {
                                    const float *f = &fn[lst[q] * 3];
                                    float u[3];
                                    unit(f, u);
                                    float d = u[0] * ref[0] + u[1] * ref[1] + u[2] * ref[2];
                                    if (std::fabs(d) < 0.64f) continue; // crease: another surface, don't blend
                                    float sg = d < 0 ? -1.0f : 1.0f;
                                    acc[0] += sg * f[0]; acc[1] += sg * f[1]; acc[2] += sg * f[2];
                                }
                                float *n = &m.nrm[v * 3];
                                unit(acc, n);
                            }
                            }
                            build_mips(m);
                            ok = true;
                        }
                    }
                }
            }
            fclose(f);
        }
    } catch (...) { // std::bad_alloc or anything else: just no 3D model
        ok = false;
    }
    if (!ok) g_model.clear();
    g_state.store(ok ? kReady : kFailed, std::memory_order_release);
}

void reset_view()
{
    g_yaw = 0.35f;
    g_pitch = -0.25f;
    g_zoom = 1.0f;
}

// mouse drag = rotate, + / - = zoom, R = reset. Only while the game window is in front.
void update_input()
{
    ULONGLONG now = GetTickCount64();
    float dt = g_last_frame ? std::min(0.1f, (now - g_last_frame) / 1000.0f) : 0.0f;
    g_last_frame = now;
    HWND fg = GetForegroundWindow();
    DWORD pid = 0;
    if (fg) GetWindowThreadProcessId(fg, &pid);
    bool focus = pid == GetCurrentProcessId();
    bool down = focus && (GetAsyncKeyState(VK_LBUTTON) & 0x8000) != 0;
    POINT pt;
    if (!GetCursorPos(&pt)) pt = g_last;
    if (down) {
        if (g_drag) {
            g_yaw += (pt.x - g_last.x) * 0.010f;
            g_pitch = std::max(-1.3f, std::min(1.3f, g_pitch + (pt.y - g_last.y) * 0.008f));
            if (pt.x != g_last.x || pt.y != g_last.y) g_last_input = now;
        }
        g_drag = true;
    } else {
        g_drag = false;
    }
    g_last = pt;
    // mouse (the game captures the cursor, so these are raw counts): hold the left button and move = rotate; wheel = zoom
    int mdx = g_in_dx.exchange(0), mdy = g_in_dy.exchange(0), mw = g_in_wheel.exchange(0);
    if (down && (mdx || mdy)) {
        g_yaw += mdx * 0.010f;
        g_pitch = std::max(-1.3f, std::min(1.3f, g_pitch + mdy * 0.008f));
        g_last_input = now;
    }
    if (mw) {
        g_zoom *= std::pow(1.12f, (float)mw);
        g_last_input = now;
    }
    // pad: right stick rotates, right / left trigger zoom in / out
    float fx = g_in_rx.load() / 32768.0f, fy = g_in_ry.load() / 32768.0f;
    if (std::fabs(fx) < 0.25f) fx = 0;
    if (std::fabs(fy) < 0.25f) fy = 0;
    if (fx != 0) {
        g_yaw += fx * 2.6f * dt;
        g_last_input = now;
    }
    if (fy != 0) {
        g_zoom *= std::exp(fy * 1.5f * dt); // right stick up zooms in; down zooms out
        g_last_input = now;
    }
    float rt = g_in_rt.load() / 255.0f, lt = g_in_lt.load() / 255.0f;
    if (rt > 0.1f) g_zoom *= 1.0f + 1.5f * rt * dt, g_last_input = now;
    if (lt > 0.1f) g_zoom /= 1.0f + 1.5f * lt * dt, g_last_input = now;
    if (focus) {
        auto key = [](int vk) { return (GetAsyncKeyState(vk) & 0x8000) != 0; };
        if (key(VK_OEM_PLUS) || key(VK_ADD)) g_zoom *= 1.0f + 1.2f * dt, g_last_input = now;
        if (key(VK_OEM_MINUS) || key(VK_SUBTRACT)) g_zoom /= 1.0f + 1.2f * dt, g_last_input = now;
        if (key('R')) reset_view();
    }
    g_zoom = std::max(0.4f, std::min(3.0f, g_zoom));
    if (!g_drag && now - g_last_input > 2000) g_yaw += 0.5f * dt; // slow turntable when left alone
    if (g_yaw > 6.2831853f) g_yaw -= 6.2831853f;
    if (g_yaw < -6.2831853f) g_yaw += 6.2831853f;
}

// XYZRHW keeps the preview in the same screen-space rectangle as the old rasterizer.
struct GpuVertex {
    float x, y, z, rhw;
    DWORD diffuse;
    float u, v;
};
constexpr DWORD kGpuFvf = D3DFVF_XYZRHW | D3DFVF_DIFFUSE | D3DFVF_TEX1;
IDirect3DVertexBuffer9 *g_vb = nullptr; // managed resources survive a device reset
IDirect3DIndexBuffer9 *g_ib = nullptr;
IDirect3DSurface9 *g_depth = nullptr; // default pool; released before Reset
uint32_t g_depth_w = 0, g_depth_h = 0;

void release_mesh_resources()
{
    if (g_tex) { g_tex->Release(); g_tex = nullptr; }
    if (g_vb) { g_vb->Release(); g_vb = nullptr; }
    if (g_ib) { g_ib->Release(); g_ib = nullptr; }
}

bool make_mesh_resources(IDirect3DDevice9 *d)
{
    if (g_tex && g_vb && g_ib) return true;
    release_mesh_resources();
    const size_t nv = g_model.pos.size() / 3, ni = g_model.idx.size();
    if (!nv || !ni || nv > UINT_MAX / sizeof(GpuVertex) || ni > UINT_MAX / sizeof(uint16_t)) return false;

    if (FAILED(d->CreateTexture(g_model.tw, g_model.th, (UINT)g_model.mips.size(), 0, D3DFMT_A8R8G8B8,
                                D3DPOOL_MANAGED, &g_tex, nullptr)) || !g_tex) return false;
    for (UINT level = 0; level < g_model.mips.size(); ++level) {
        D3DLOCKED_RECT lr = {};
        if (FAILED(g_tex->LockRect(level, &lr, nullptr, 0))) { release_mesh_resources(); return false; }
        const uint32_t w = g_model.mw[level], h = g_model.mh[level];
        const uint8_t *src = g_model.mips[level].data();
        for (uint32_t y = 0; y < h; ++y)
            std::memcpy((uint8_t *)lr.pBits + (size_t)y * lr.Pitch, src + (size_t)y * w * 4, (size_t)w * 4);
        g_tex->UnlockRect(level);
    }
    if (FAILED(d->CreateVertexBuffer((UINT)(nv * sizeof(GpuVertex)), D3DUSAGE_WRITEONLY, kGpuFvf,
                                     D3DPOOL_MANAGED, &g_vb, nullptr)) || !g_vb ||
        FAILED(d->CreateIndexBuffer((UINT)(ni * sizeof(uint16_t)), D3DUSAGE_WRITEONLY, D3DFMT_INDEX16,
                                    D3DPOOL_MANAGED, &g_ib, nullptr)) || !g_ib) {
        release_mesh_resources();
        return false;
    }
    void *dst = nullptr;
    if (FAILED(g_ib->Lock(0, 0, &dst, 0))) { release_mesh_resources(); return false; }
    std::memcpy(dst, g_model.idx.data(), ni * sizeof(uint16_t));
    g_ib->Unlock();
    return true;
}

} // namespace

bool draw(IDirect3DDevice9 *d, const RECT &box, int weapon_id)
{
    if (!d || weapon_id < 0 || weapon_id >= 17) return false;
    if (weapon_id != g_id) { // another weapon: free the old one (never while the loader thread is still writing)
        if (g_state.load(std::memory_order_acquire) == kLoading) return false;
        release_mesh_resources();
        g_model.clear();
        g_id = weapon_id;
        g_fit_id = -1;
        g_state.store(kNone, std::memory_order_release);
        reset_view();
    }
    int st = g_state.load(std::memory_order_acquire);
    if (st == kNone) {
        std::string dir = exe_dir();
        if (dir.empty()) {
            g_state.store(kFailed, std::memory_order_release);
            return false;
        }
        g_state.store(kLoading, std::memory_order_release);
        try {
            std::thread(load_main, dir + "armory\\models\\" + kNames[weapon_id] + ".gmesh").detach();
        } catch (...) {
            g_state.store(kFailed, std::memory_order_release);
        }
        return false;
    }
    if (st != kReady) return false;

    update_input();

    const float bw = (float)(box.right - box.left), bh = (float)(box.bottom - box.top);
    if (bw < 8 || bh < 8) return true;
    if (!make_mesh_resources(d)) { g_state.store(kFailed, std::memory_order_release); return false; }

    const size_t nv = g_model.pos.size() / 3, ni = g_model.idx.size();
    D3DSURFACE_DESC rt_desc = {};
    IDirect3DSurface9 *rt = nullptr;
    if (FAILED(d->GetRenderTarget(0, &rt)) || !rt) return false;
    HRESULT desc_hr = rt->GetDesc(&rt_desc);
    rt->Release();
    if (FAILED(desc_hr)) return false;
    if (!g_depth || g_depth_w != rt_desc.Width || g_depth_h != rt_desc.Height) {
        if (g_depth) { g_depth->Release(); g_depth = nullptr; }
        if (FAILED(d->CreateDepthStencilSurface(rt_desc.Width, rt_desc.Height, D3DFMT_D24S8,
                                                D3DMULTISAMPLE_NONE, 0, FALSE, &g_depth, nullptr)) || !g_depth) {
            g_depth = nullptr;
            return false; // caller draws the normal PNG instead
        }
        g_depth_w = rt_desc.Width;
        g_depth_h = rt_desc.Height;
    }

    const float cx = (box.left + box.right) * 0.5f, cy = (box.top + box.bottom) * 0.5f;
    const float c = std::cos(g_yaw), s = std::sin(g_yaw), cp = std::cos(g_pitch), sp = std::sin(g_pitch);
    const float L[3] = {-0.4f / 0.9695f, 0.6f / 0.9695f, -0.7f / 0.9695f};
    static std::vector<GpuVertex> verts;
    try { verts.resize(nv); } catch (...) { return false; }
    float obj_min[3] = {1e30f, 1e30f, 1e30f}, obj_max[3] = {-1e30f, -1e30f, -1e30f};
    for (size_t i = 0; i < nv; ++i) {
        const float *p = &g_model.pos[i * 3];
        for (int k = 0; k < 3; ++k) {
            obj_min[k] = std::min(obj_min[k], p[k]);
            obj_max[k] = std::max(obj_max[k], p[k]);
        }
    }
    const float pivot[3] = {(obj_min[0] + obj_max[0]) * 0.5f,
                            (obj_min[1] + obj_max[1]) * 0.5f,
                            (obj_min[2] + obj_max[2]) * 0.5f};
    float minx = 1e30f, maxx = -1e30f, miny = 1e30f, maxy = -1e30f;
    float minz = 1e30f, maxz = -1e30f;
    for (size_t i = 0; i < nv; ++i) {
        const float *p = &g_model.pos[i * 3];
        float px = p[0] - pivot[0], py = p[1] - pivot[1], pz = p[2] - pivot[2];
        float x1 = px * c + pz * s, z1 = -px * s + pz * c;
        float y2 = py * cp - z1 * sp, z2 = py * sp + z1 * cp;
        minx = std::min(minx, x1); maxx = std::max(maxx, x1);
        miny = std::min(miny, y2); maxy = std::max(maxy, y2);
        minz = std::min(minz, z2); maxz = std::max(maxz, z2);
    }
    // Fit the rotated gun into the available view with a small margin. The user zoom is
    // applied after fitting, so the default view shows the complete weapon.
    const float span_x = std::max(maxx - minx, 1e-6f), span_y = std::max(maxy - miny, 1e-6f);
    if (g_fit_id != weapon_id || std::fabs(g_fit_w - bw) > 0.5f || std::fabs(g_fit_h - bh) > 0.5f) {
        g_fit_id = weapon_id;
        g_fit_w = bw;
        g_fit_h = bh;
        g_fit_scale = 0.88f * std::min(bw / span_x, bh / span_y);
    }
    const float sc = g_fit_scale * g_zoom;
    for (size_t i = 0; i < nv; ++i) {
        const float *p = &g_model.pos[i * 3], *n = &g_model.nrm[i * 3], *uv = &g_model.uv[i * 2];
        float px = p[0] - pivot[0], py = p[1] - pivot[1], pz = p[2] - pivot[2];
        float x1 = px * c + pz * s, z1 = -px * s + pz * c;
        float y2 = py * cp - z1 * sp, z2 = py * sp + z1 * cp;
        float nx1 = n[0] * c + n[2] * s, nz1 = -n[0] * s + n[2] * c;
        float ny2 = n[1] * cp - nz1 * sp, nz2 = n[1] * sp + nz1 * cp;
        float diffuse = std::min(1.0f, 1.5f * (0.30f + 0.70f * std::fabs(nx1 * L[0] + ny2 * L[1] + nz2 * L[2])));
        DWORD shade = (DWORD)(std::min(255.0f, diffuse * 255.0f) + 0.5f);
        verts[i] = {cx + x1 * sc - 0.5f, cy - y2 * sc - 0.5f, z2, 1.0f,
                    0xFF000000u | (shade << 16) | (shade << 8) | shade, uv[0], uv[1]};
    }
    const float zr = std::max(maxz - minz, 1e-6f);
    for (GpuVertex &v : verts) v.z = 0.05f + 0.90f * (v.z - minz) / zr; // nearer vertices have smaller depth

    void *dst = nullptr;
    if (FAILED(g_vb->Lock(0, (UINT)(nv * sizeof(GpuVertex)), &dst, 0))) return false;
    std::memcpy(dst, verts.data(), nv * sizeof(GpuVertex));
    g_vb->Unlock();

    IDirect3DSurface9 *old_z = nullptr;
    d->GetDepthStencilSurface(&old_z); // this UI pass normally has no depth surface bound
    if (FAILED(d->SetDepthStencilSurface(g_depth))) { if (old_z) old_z->Release(); return false; }
    d->Clear(0, nullptr, D3DCLEAR_ZBUFFER, 0, 1.0f, 0);
    DWORD old_z_enable = FALSE, old_z_write = FALSE, old_z_func = D3DCMP_ALWAYS, old_cull = D3DCULL_NONE;
    DWORD old_blend = FALSE, old_src = D3DBLEND_ONE, old_dst = D3DBLEND_ZERO, old_scissor = FALSE;
    DWORD old_min = D3DTEXF_LINEAR, old_mag = D3DTEXF_LINEAR, old_mip = D3DTEXF_NONE;
    DWORD old_addr_u = D3DTADDRESS_CLAMP, old_addr_v = D3DTADDRESS_CLAMP;
    DWORD old_color_op = D3DTOP_SELECTARG1, old_color_a1 = D3DTA_DIFFUSE, old_color_a2 = D3DTA_CURRENT;
    DWORD old_alpha_op = D3DTOP_SELECTARG1, old_alpha_a1 = D3DTA_DIFFUSE, old_alpha_a2 = D3DTA_CURRENT;
    RECT old_scissor_rect = {};
    d->GetRenderState(D3DRS_ZENABLE, &old_z_enable);
    d->GetRenderState(D3DRS_ZWRITEENABLE, &old_z_write);
    d->GetRenderState(D3DRS_ZFUNC, &old_z_func);
    d->GetRenderState(D3DRS_CULLMODE, &old_cull);
    d->GetRenderState(D3DRS_ALPHABLENDENABLE, &old_blend);
    d->GetRenderState(D3DRS_SRCBLEND, &old_src);
    d->GetRenderState(D3DRS_DESTBLEND, &old_dst);
    d->GetRenderState(D3DRS_SCISSORTESTENABLE, &old_scissor);
    d->GetScissorRect(&old_scissor_rect);
    d->GetSamplerState(0, D3DSAMP_MINFILTER, &old_min);
    d->GetSamplerState(0, D3DSAMP_MAGFILTER, &old_mag);
    d->GetSamplerState(0, D3DSAMP_MIPFILTER, &old_mip);
    d->GetSamplerState(0, D3DSAMP_ADDRESSU, &old_addr_u);
    d->GetSamplerState(0, D3DSAMP_ADDRESSV, &old_addr_v);
    d->GetTextureStageState(0, D3DTSS_COLOROP, &old_color_op);
    d->GetTextureStageState(0, D3DTSS_COLORARG1, &old_color_a1);
    d->GetTextureStageState(0, D3DTSS_COLORARG2, &old_color_a2);
    d->GetTextureStageState(0, D3DTSS_ALPHAOP, &old_alpha_op);
    d->GetTextureStageState(0, D3DTSS_ALPHAARG1, &old_alpha_a1);
    d->GetTextureStageState(0, D3DTSS_ALPHAARG2, &old_alpha_a2);

    d->SetScissorRect(&box);
    d->SetRenderState(D3DRS_SCISSORTESTENABLE, TRUE);
    d->SetRenderState(D3DRS_ZENABLE, D3DZB_TRUE);
    d->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);
    d->SetRenderState(D3DRS_ZFUNC, D3DCMP_LESSEQUAL);
    d->SetRenderState(D3DRS_CULLMODE, D3DCULL_CW); // match the front-face winding accepted by the old rasterizer
    d->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
    d->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
    d->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
    d->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
    d->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
    d->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);
    d->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_MODULATE);
    d->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
    d->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
    d->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_SELECTARG1);
    d->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_DIFFUSE);
    d->SetFVF(kGpuFvf);
    d->SetStreamSource(0, g_vb, 0, sizeof(GpuVertex));
    d->SetIndices(g_ib);
    d->SetTexture(0, g_tex);
    HRESULT draw_hr = d->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, (UINT)nv, 0, (UINT)(ni / 3));
    d->SetTexture(0, nullptr);
    d->SetIndices(nullptr);
    d->SetStreamSource(0, nullptr, 0, 0);
    d->SetRenderState(D3DRS_ZENABLE, old_z_enable);
    d->SetRenderState(D3DRS_ZWRITEENABLE, old_z_write);
    d->SetRenderState(D3DRS_ZFUNC, old_z_func);
    d->SetRenderState(D3DRS_CULLMODE, old_cull);
    d->SetRenderState(D3DRS_ALPHABLENDENABLE, old_blend);
    d->SetRenderState(D3DRS_SRCBLEND, old_src);
    d->SetRenderState(D3DRS_DESTBLEND, old_dst);
    d->SetRenderState(D3DRS_SCISSORTESTENABLE, old_scissor);
    d->SetScissorRect(&old_scissor_rect);
    d->SetSamplerState(0, D3DSAMP_MINFILTER, old_min);
    d->SetSamplerState(0, D3DSAMP_MAGFILTER, old_mag);
    d->SetSamplerState(0, D3DSAMP_MIPFILTER, old_mip);
    d->SetSamplerState(0, D3DSAMP_ADDRESSU, old_addr_u);
    d->SetSamplerState(0, D3DSAMP_ADDRESSV, old_addr_v);
    d->SetTextureStageState(0, D3DTSS_COLOROP, old_color_op);
    d->SetTextureStageState(0, D3DTSS_COLORARG1, old_color_a1);
    d->SetTextureStageState(0, D3DTSS_COLORARG2, old_color_a2);
    d->SetTextureStageState(0, D3DTSS_ALPHAOP, old_alpha_op);
    d->SetTextureStageState(0, D3DTSS_ALPHAARG1, old_alpha_a1);
    d->SetTextureStageState(0, D3DTSS_ALPHAARG2, old_alpha_a2);
    d->SetDepthStencilSurface(old_z);
    if (old_z) old_z->Release();
    return SUCCEEDED(draw_hr);
}

void on_device_lost()
{
    if (g_depth) { g_depth->Release(); g_depth = nullptr; }
    g_depth_w = g_depth_h = 0;
}

void feed_mouse(int dx, int dy, int wheel)
{
    g_in_dx.fetch_add(dx);
    g_in_dy.fetch_add(dy);
    g_in_wheel.fetch_add(wheel);
}

void feed_pad(int16_t rx, int16_t ry, uint8_t lt, uint8_t rt)
{
    g_in_rx.store(rx);
    g_in_ry.store(ry);
    g_in_lt.store(lt);
    g_in_rt.store(rt);
}

} // namespace gun3d
