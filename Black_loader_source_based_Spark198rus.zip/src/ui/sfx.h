// Armory sounds. Each is looked up as <folder of black.exe>\armory\<name>.wav (16-bit PCM or 32-bit float, mono or
// stereo, any rate) and, when that file is missing, a short synthesised sound is used instead. They are mixed into
// the game's audio output (audio_out::play_sfx), so they work without any game sound bank.
#pragma once

#include "audio/output.h"

#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace sfx {

enum Id { KILL, BUY, DENY, OPEN, kCount }; // files: kill.wav, buy.wav, deny.wav, open.wav

void play(Id id);

// Decodes a whole .wav file held in memory (16-bit PCM or 32-bit float, mono or stereo, any rate) to interleaved stereo
// floats at 48 kHz, times `volume`. Used by the weather system for its thunder sounds. False: not a supported wav.
bool decode_wav(const uint8_t *bytes, size_t n, std::vector<float> &out, float volume = 1.0f);

// Armory music: armory\music*.wav next to black.exe (WAV, 16/24-bit PCM or 32-bit float, mono or stereo).
// music(true) when the armory opens, music(false) when it closes. Game audio fades with the same transitions.
void music(bool armory_open, const audio_out::MusicCfg &cfg);
// radio\radio*.wav next to black.exe; fades tracks while enabled.
void radio(bool enabled);
void radio_level_active(bool active);
void radio_volume(float level);
bool radio_now_playing(std::wstring &title, std::wstring &artist, float &alpha);

} // namespace sfx
