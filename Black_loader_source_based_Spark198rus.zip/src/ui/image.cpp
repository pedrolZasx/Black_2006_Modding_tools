#include "ui/image.h"

#include <windows.h>
#include <wincodec.h>

#include <condition_variable>
#include <deque>
#include <exception>
#include <mutex>
#include <thread>

namespace armory_img {

uint64_t file_stamp(const std::string &path)
{
    WIN32_FILE_ATTRIBUTE_DATA d;
    if (!GetFileAttributesExA(path.c_str(), GetFileExInfoStandard, &d)) return 0;
    return ((uint64_t)d.ftLastWriteTime.dwHighDateTime << 32) | d.ftLastWriteTime.dwLowDateTime;
}

namespace {

bool decode(IWICImagingFactory *fac, const std::wstring &wp, std::vector<uint32_t> &px, uint32_t &w, uint32_t &h)
{
    IWICBitmapDecoder *dec = nullptr;
    IWICBitmapFrameDecode *fr = nullptr;
    IWICBitmapScaler *scaler = nullptr;
    IWICFormatConverter *conv = nullptr;
    bool ok = false;
    UINT iw = 0, ih = 0;
    if (SUCCEEDED(fac->CreateDecoderFromFilename(wp.c_str(), nullptr, GENERIC_READ, WICDecodeMetadataCacheOnDemand, &dec)) &&
        SUCCEEDED(dec->GetFrame(0, &fr)) && SUCCEEDED(fr->GetSize(&iw, &ih)) && iw > 0 && ih > 0 && iw <= 16384 && ih <= 16384) {
        IWICBitmapSource *src = fr;
        UINT ow = iw, oh = ih;
        if (iw > kMaxSide || ih > kMaxSide) { // scale down while decoding: no full-size copy in memory
            double k = (double)kMaxSide / (iw > ih ? iw : ih);
            ow = (UINT)(iw * k + 0.5);
            oh = (UINT)(ih * k + 0.5);
            if (ow < 1) ow = 1;
            if (oh < 1) oh = 1;
            if (SUCCEEDED(fac->CreateBitmapScaler(&scaler)) && SUCCEEDED(scaler->Initialize(fr, ow, oh, WICBitmapInterpolationModeFant)))
                src = scaler;
            else {
                ow = iw;
                oh = ih;
            }
        }
        if (SUCCEEDED(fac->CreateFormatConverter(&conv)) &&
            SUCCEEDED(conv->Initialize(src, GUID_WICPixelFormat32bppBGRA, WICBitmapDitherTypeNone, nullptr, 0.0,
                                       WICBitmapPaletteTypeCustom))) {
            px.assign((size_t)ow * oh, 0);
            if (SUCCEEDED(conv->CopyPixels(nullptr, ow * 4, (UINT)(px.size() * 4), (BYTE *)px.data()))) {
                w = ow;
                h = oh;
                ok = true;
            }
        }
    }
    if (conv) conv->Release();
    if (scaler) scaler->Release();
    if (fr) fr->Release();
    if (dec) dec->Release();
    return ok;
}

bool load_with(IWICImagingFactory *fac, const std::string &path, std::vector<uint32_t> &px, uint32_t &w, uint32_t &h)
{
    if (!fac || GetFileAttributesA(path.c_str()) == INVALID_FILE_ATTRIBUTES) return false;
    int n = MultiByteToWideChar(CP_ACP, 0, path.c_str(), -1, nullptr, 0);
    if (n <= 0) return false;
    std::wstring wp((size_t)n, L'\0');
    MultiByteToWideChar(CP_ACP, 0, path.c_str(), -1, &wp[0], n);
    try {
        return decode(fac, wp, px, w, h);
    } catch (const std::exception &) { // out of memory
        std::vector<uint32_t>().swap(px);
        return false;
    }
}

// ---- worker thread (created on the first request, lives until the process ends) -------------------------------------
struct Job {
    std::string key, path;
};
struct Worker {
    std::mutex mu;
    std::condition_variable cv;
    std::deque<Job> jobs;
    std::deque<Loaded> done;
    std::vector<std::string> busy; // keys queued or being decoded
    bool started = false;
};
Worker &worker() // never deleted: the thread may still be waiting on it when the process exits
{
    static Worker *w = new Worker;
    return *w;
}

void worker_main()
{
    Worker &W = worker();
    SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_BELOW_NORMAL);
    bool com = SUCCEEDED(CoInitializeEx(nullptr, COINIT_MULTITHREADED));
    IWICImagingFactory *fac = nullptr;
    if (FAILED(CoCreateInstance(CLSID_WICImagingFactory, nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&fac)))) fac = nullptr;
    for (;;) {
        Job j;
        {
            std::unique_lock<std::mutex> lk(W.mu);
            W.cv.wait(lk, [&] { return !W.jobs.empty(); });
            j = std::move(W.jobs.front());
            W.jobs.pop_front();
        }
        Loaded r;
        r.key = j.key;
        r.stamp = file_stamp(j.path);
        r.ok = load_with(fac, j.path, r.px, r.w, r.h);
        {
            std::lock_guard<std::mutex> lk(W.mu);
            for (size_t i = 0; i < W.busy.size(); i++)
                if (W.busy[i] == j.key) {
                    W.busy.erase(W.busy.begin() + i);
                    break;
                }
            W.done.push_back(std::move(r));
        }
    }
    (void)com;
}

} // namespace

bool load_png(const std::string &path, std::vector<uint32_t> &px, uint32_t &w, uint32_t &h)
{
    bool com = SUCCEEDED(CoInitializeEx(nullptr, COINIT_MULTITHREADED)); // fine if this thread already did it
    IWICImagingFactory *fac = nullptr;
    if (FAILED(CoCreateInstance(CLSID_WICImagingFactory, nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&fac)))) fac = nullptr;
    bool ok = load_with(fac, path, px, w, h);
    if (fac) fac->Release();
    (void)com;
    return ok;
}

void request(const std::string &key, const std::string &path)
{
    Worker &W = worker();
    std::lock_guard<std::mutex> lk(W.mu);
    for (const std::string &b : W.busy)
        if (b == key) return; // already queued
    if (!W.started) {
        try {
            std::thread(worker_main).detach();
            W.started = true;
        } catch (...) {
            return; // no thread: the picture stays missing
        }
    }
    W.busy.push_back(key);
    W.jobs.push_back({key, path});
    W.cv.notify_one();
}

bool take(Loaded &out)
{
    Worker &W = worker();
    std::lock_guard<std::mutex> lk(W.mu);
    if (W.done.empty()) return false;
    out = std::move(W.done.front());
    W.done.pop_front();
    return true;
}

} // namespace armory_img
