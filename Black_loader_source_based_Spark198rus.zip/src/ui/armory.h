// Weapon armory: a menu drawn over the game (not part of the pause menu). The game keeps running; while it is open
// the pad poll gives the game no input and feeds the armory instead. Drawing is in d3d/device.cpp (blur + overlay).
#pragma once

#include <cstdint>
#include <string>
#include <vector>

namespace armory {

// Everything is in fractions of the picture: x, width of rectangles in 0..1 of its width, y in 0..1 of its height.
struct Rect {
    float x0, y0, x1, y1;
    uint32_t argb;
};
// A picture from <black.exe folder>\armory\<key>.png, fitted inside the box (aspect kept). If that file is missing,
// <alt> is tried. argb tints it (white = as is).
struct Image {
    float x0, y0, x1, y1;
    uint32_t argb;
    std::string key, alt;
    bool is3d = false; // the big weapon preview: drawn as a live 3D model when one exists (ui/gun3d.cpp)
};
struct Text {
    float x, y;     // anchor x (see align), top of the line
    float h;        // text size (em height) as a fraction of the picture height
    uint32_t argb;
    int align;      // 0 left, 1 centre, 2 right of x
    float track;    // extra space between letters, in em
    std::wstring s;
    bool radio_font = false; // lightweight Arial face for radio captions only
};
struct Frame {
    std::vector<Rect> rects;   // drawn first,
    std::vector<Image> images; // then the pictures,
    std::vector<Text> texts;   // then the text on top
    bool reload_images = false; // the armory just opened: load the PNG files again
};

bool is_open();
int current_weapon_id(); // held weapon's BLACK ID (0-16), or -1 when no weapon is equipped
int current_weapon_slot(); // current held slot (0 or 1), or -1 when unavailable
bool has_overlay(); // something to draw: the armory is open or a kill notification is still showing
// Once per pad poll, after the pad was read. focus: the game window is in front. Handles the toggle key and, while
// open, the navigation (keyboard and pad). Returns true when the game must get no input this poll (open, or the
// keys that closed it are still down); the caller then clears the pad and skips the key bindings.
bool poll(bool focus, uint16_t buttons, const uint8_t analog[8]);
void build(Frame &f); // this frame's layout (the armory when open, else the kill notifications)

} // namespace armory
