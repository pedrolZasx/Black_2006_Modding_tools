// PNG loading for the armory (Windows Imaging Component).
#pragma once

#include <cstdint>
#include <string>
#include <vector>

namespace armory_img {

// Largest side of a loaded picture. Bigger pictures are scaled down while they are decoded: the armory shows them at
// most ~600 pixels wide, and a 4096x4096 picture costs 64 MB of RAM plus 64 MB of video memory for nothing.
constexpr uint32_t kMaxSide = 1024;

// Decodes a PNG (or any image WIC reads) to 32-bit pixels, 0xAARRGGBB, straight (not premultiplied) alpha.
// Pictures larger than kMaxSide are scaled down (aspect kept). Never throws.
bool load_png(const std::string &path, std::vector<uint32_t> &px, uint32_t &w, uint32_t &h);

// ---- loading in the background ---------------------------------------------------------------------------------------
// The game must never wait for the disk or the PNG decoder. request() queues a file for the worker thread and returns at
// once; take() hands back the finished pictures one by one (call it from the thread that makes the textures).
struct Loaded {
    std::string key;       // as given to request()
    bool ok = false;       // false: missing or not readable
    uint64_t stamp = 0;    // last-write time of the file when it was read (0 = unknown)
    uint32_t w = 0, h = 0;
    std::vector<uint32_t> px;
};
void request(const std::string &key, const std::string &path);
bool take(Loaded &out);
uint64_t file_stamp(const std::string &path); // last-write time of a file, 0 when it does not exist

} // namespace armory_img
