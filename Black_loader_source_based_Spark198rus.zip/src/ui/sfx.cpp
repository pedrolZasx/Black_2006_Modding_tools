#include "ui/sfx.h"

#include "audio/output.h"
#include "common.h"
#include "input/bindings.h"

#include <windows.h>

#include <algorithm>
#include <atomic>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <exception>
#include <new>
#include <string>
#include <thread>
#include <utility>
#include <vector>

namespace sfx {
namespace {

constexpr float kPi = 3.14159265f;
constexpr float kVolume = 1.0f; // master level of all armory sounds
const char *const kFile[kCount] = {"kill", "buy", "deny", "open"};

struct Sound {
    std::vector<float> lr; // interleaved stereo, 48 kHz
    bool tried;
};
Sound g_snd[kCount];

std::string exe_dir()
{
    char p[MAX_PATH];
    DWORD n = GetModuleFileNameA(nullptr, p, MAX_PATH);
    std::string s(p, n);
    size_t k = s.find_last_of("\\/");
    return k == std::string::npos ? std::string() : s.substr(0, k + 1);
}

bool decode_wav_bytes(const uint8_t *bytes, size_t n, std::vector<float> &out, float volume)
{
    if (n < 44 || memcmp(bytes, "RIFF", 4) || memcmp(bytes + 8, "WAVE", 4)) return false;
    struct View {
        const uint8_t *p;
        size_t n;
        const uint8_t &operator[](size_t i) const { return p[i]; }
        size_t size() const { return n; }
    } d{bytes, n};
    uint16_t tag = 0, ch = 0, bits = 0;
    uint32_t rate = 0, dsz = 0;
    const uint8_t *data = nullptr;
    for (size_t p = 12; p + 8 <= d.size();) {
        uint32_t sz;
        memcpy(&sz, &d[p + 4], 4);
        const uint8_t *c = &d[p + 8];
        if (!memcmp(&d[p], "fmt ", 4) && sz >= 16 && p + 8 + 16 <= d.size()) {
            memcpy(&tag, c, 2);
            memcpy(&ch, c + 2, 2);
            memcpy(&rate, c + 4, 4);
            memcpy(&bits, c + 14, 2);
        } else if (!memcmp(&d[p], "data", 4)) {
            data = c;
            dsz = (uint32_t)std::min<size_t>(sz, d.size() - (p + 8));
        }
        p += 8 + (size_t)sz + (sz & 1);
    }
    bool pcm16 = (tag == 1 || tag == 0xFFFE) && bits == 16, flt = tag == 3 && bits == 32;
    if (!data || !rate || (ch != 1 && ch != 2) || (!pcm16 && !flt)) return false;
    size_t frames = dsz / (size_t)(ch * (bits / 8));
    if (!frames) return false;
    std::vector<float> src(frames * 2);
    for (size_t i = 0; i < frames; i++) {
        float v[2] = {0, 0};
        for (int c = 0; c < ch; c++) {
            if (pcm16) {
                int16_t s;
                memcpy(&s, data + (i * ch + c) * 2, 2);
                v[c] = s / 32768.0f;
            } else memcpy(&v[c], data + (i * ch + c) * 4, 4);
        }
        src[i * 2] = v[0];
        src[i * 2 + 1] = ch == 2 ? v[1] : v[0];
    }
    size_t n_out = (size_t)((uint64_t)frames * audio_out::RATE / rate);
    out.assign(n_out * 2, 0.0f);
    for (size_t i = 0; i < n_out; i++) { // linear resample to 48 kHz
        double pos = (double)i * rate / audio_out::RATE;
        size_t i0 = (size_t)pos, i1 = std::min(i0 + 1, frames - 1);
        float fr = (float)(pos - (double)i0);
        for (int c = 0; c < 2; c++) out[i * 2 + c] = (src[i0 * 2 + c] * (1 - fr) + src[i1 * 2 + c] * fr) * volume;
    }
    return true;
}

bool load_wav(const std::string &path, std::vector<float> &out, long max_bytes = 8 * 1024 * 1024, float volume = kVolume) // short sounds only; the music has its own loader
{
    FILE *f = fopen(path.c_str(), "rb");
    if (!f) return false;
    fseek(f, 0, SEEK_END);
    long n = ftell(f);
    fseek(f, 0, SEEK_SET);
    if (n < 44 || n > max_bytes) {
        fclose(f);
        return false;
    }
    std::vector<uint8_t> d((size_t)n);
    size_t got = fread(d.data(), 1, d.size(), f);
    fclose(f);
    if (got != d.size()) return false;
    return decode_wav_bytes(d.data(), d.size(), out, volume);
}

// ---- armory music loader -------------------------------------------------------------------------------------------
// The music can be long (minutes). It is NOT read into memory whole: the file is read in small pieces, converted to
// 48 kHz stereo 16-bit on the fly and stored in ONE buffer (4 bytes per frame: 10 minutes = 115 MB). Loading runs on a
// background thread, so opening the armory never waits for the disk and the game thread is never blocked.
constexpr uint32_t kMusicMaxSeconds = 600; // longer files are cut here
constexpr size_t kMusicBudgetBytes = 128u * 1024u * 1024u; // keep the 32-bit game's playlist bounded
constexpr size_t kMusicMaxTracks = 32;
constexpr size_t kRadioMaxTracks = 64;

struct WavInfo {
    uint16_t tag = 0, ch = 0, bits = 0;
    uint32_t rate = 0;
    uint64_t data_off = 0, data_bytes = 0;
};

// Finds the "fmt " and "data" chunks without reading the audio data.
bool wav_header(FILE *f, int64_t fsize, WavInfo &w)
{
    uint8_t h[12];
    if (fread(h, 1, 12, f) != 12 || memcmp(h, "RIFF", 4) || memcmp(h + 8, "WAVE", 4)) return false;
    bool have_fmt = false, have_data = false;
    while (!(have_fmt && have_data)) {
        uint8_t ck[8];
        if (fread(ck, 1, 8, f) != 8) break;
        uint32_t sz;
        memcpy(&sz, ck + 4, 4);
        int64_t body = _ftelli64(f);
        if (!memcmp(ck, "fmt ", 4) && sz >= 16) {
            uint8_t b[16];
            if (fread(b, 1, 16, f) != 16) return false;
            memcpy(&w.tag, b, 2);
            memcpy(&w.ch, b + 2, 2);
            memcpy(&w.rate, b + 4, 4);
            memcpy(&w.bits, b + 14, 2);
            have_fmt = true;
        } else if (!memcmp(ck, "data", 4)) {
            w.data_off = (uint64_t)body;
            w.data_bytes = sz;
            have_data = true;
        }
        int64_t next = body + (int64_t)sz + (int64_t)(sz & 1);
        if (next >= fsize && !(have_fmt && have_data)) break;
        if (_fseeki64(f, next, SEEK_SET) != 0) break;
    }
    if (!have_fmt || !have_data) return false;
    uint64_t avail = (int64_t)w.data_off < fsize ? (uint64_t)fsize - w.data_off : 0;
    w.data_bytes = std::min<uint64_t>(w.data_bytes, avail); // a wrong or "streaming" size: use what is in the file
    bool pcm = w.tag == 1 || w.tag == 0xFFFE;
    bool ok_fmt = (pcm && (w.bits == 16 || w.bits == 24)) || (w.tag == 3 && w.bits == 32);
    return ok_fmt && w.rate >= 8000 && w.rate <= 384000 && (w.ch == 1 || w.ch == 2);
}

// `count` source frames starting at frame `first`, as interleaved stereo floats in dst.
bool read_frames(FILE *f, const WavInfo &w, uint64_t first, size_t count, std::vector<float> &dst, std::vector<uint8_t> &raw)
{
    const size_t bps = w.bits / 8, fb = (size_t)w.ch * bps;
    raw.resize(count * fb);
    if (_fseeki64(f, (int64_t)(w.data_off + first * fb), SEEK_SET) != 0) return false;
    if (fread(raw.data(), 1, raw.size(), f) != raw.size()) return false;
    dst.resize(count * 2);
    for (size_t i = 0; i < count; i++) {
        float v[2] = {0, 0};
        for (int c = 0; c < w.ch; c++) {
            const uint8_t *p = &raw[i * fb + (size_t)c * bps];
            if (w.bits == 16) {
                int16_t s;
                memcpy(&s, p, 2);
                v[c] = s / 32768.0f;
            } else if (w.bits == 24) {
                int32_t s = (int32_t)(((uint32_t)p[0] << 8) | ((uint32_t)p[1] << 16) | ((uint32_t)p[2] << 24)) >> 8;
                v[c] = s / 8388608.0f;
            } else memcpy(&v[c], p, 4);
        }
        dst[i * 2] = v[0];
        dst[i * 2 + 1] = w.ch == 2 ? v[1] : v[0];
    }
    return true;
}

// WAV (16/24-bit PCM or 32-bit float, mono or stereo, any rate) -> interleaved stereo 16-bit at 48 kHz.
bool load_music(const std::string &path, std::vector<int16_t> &out, size_t max_bytes)
{
    FILE *f = fopen(path.c_str(), "rb");
    if (!f) return false;
    bool ok = false;
    try {
        _fseeki64(f, 0, SEEK_END);
        int64_t fsize = _ftelli64(f);
        _fseeki64(f, 0, SEEK_SET);
        WavInfo w;
        if (fsize > 90LL * 1024 * 1024) {
            logf("[radio] WAV exceeds the 90 MB file limit: %s", path.c_str());
            fclose(f);
            return false;
        }
        if (fsize > 44 && wav_header(f, fsize, w)) {
            const uint64_t fb = (uint64_t)w.ch * (w.bits / 8), frames = w.data_bytes / fb;
            uint64_t n_out = frames * audio_out::RATE / w.rate;
            if (n_out > (uint64_t)kMusicMaxSeconds * audio_out::RATE) {
                logf("[armory] music is longer than %u s: only the first %u s are used", kMusicMaxSeconds, kMusicMaxSeconds);
                n_out = (uint64_t)kMusicMaxSeconds * audio_out::RATE;
            }
            if (n_out > max_bytes / (2 * sizeof(int16_t))) {
                logf("[music] track skipped (playlist memory limit): %s", path.c_str());
                fclose(f);
                return false;
            }
            if (frames && n_out) {
                out.resize((size_t)n_out * 2); // may throw std::bad_alloc: caught below, the game goes on without music
                const size_t kBlock = 16384;   // output frames per piece
                std::vector<float> src;
                std::vector<uint8_t> raw;
                ok = true;
                for (uint64_t o = 0; o < n_out && ok; o += kBlock) {
                    size_t cnt = (size_t)std::min<uint64_t>(kBlock, n_out - o);
                    uint64_t i_first = (uint64_t)((double)o * w.rate / audio_out::RATE);
                    uint64_t i_last = std::min<uint64_t>(frames - 1, (uint64_t)((double)(o + cnt - 1) * w.rate / audio_out::RATE) + 1);
                    if (i_last < i_first || !read_frames(f, w, i_first, (size_t)(i_last - i_first + 1), src, raw)) {
                        ok = false;
                        break;
                    }
                    for (size_t i = 0; i < cnt; i++) { // linear resample to 48 kHz
                        double pos = (double)(o + i) * w.rate / audio_out::RATE;
                        uint64_t i0 = (uint64_t)pos, i1 = std::min<uint64_t>(i0 + 1, frames - 1);
                        float fr = (float)(pos - (double)i0);
                        size_t a = (size_t)(i0 - i_first), b = (size_t)(i1 - i_first);
                        for (int c = 0; c < 2; c++) {
                            float v = src[a * 2 + c] * (1 - fr) + src[b * 2 + c] * fr;
                            v = std::max(-1.0f, std::min(1.0f, v)) * 32767.0f;
                            out[(size_t)(o + i) * 2 + c] = (int16_t)(v >= 0 ? v + 0.5f : v - 0.5f);
                        }
                    }
                }
            }
        }
    } catch (const std::exception &) {
        logf("[armory] music: not enough memory for the track");
        ok = false;
    }
    fclose(f);
    if (!ok) std::vector<int16_t>().swap(out); // give the memory back
    return ok;
}

struct RadioState {
    std::atomic<int> state{0};
    std::atomic<bool> enabled{false}, level_active{false};
    std::vector<std::vector<int16_t>> tracks;
    std::vector<audio_out::MusicTrack> playlist;
    struct Tag { std::wstring title, artist; };
    std::vector<Tag> tags;
    audio_out::MusicCfg cfg{0.0f, 3.0f, 3.0f, 4.0f, 1.0f, 2.0f};
};
RadioState &radio_state() { static RadioState *r = new RadioState; return *r; }

void radio_thread() {
    RadioState &r = radio_state();
    SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_BELOW_NORMAL);
    try {
        const std::string dir = exe_dir() + "radio\\";
        std::vector<std::string> paths;
        WIN32_FIND_DATAA fd = {};
        HANDLE find = FindFirstFileA((dir + "radio*.wav").c_str(), &fd);
        if (find != INVALID_HANDLE_VALUE) {
            do { if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) paths.push_back(dir + fd.cFileName); }
            while (FindNextFileA(find, &fd));
            FindClose(find);
        }
        // Sort numbered tracks naturally: radio2.wav must precede radio10.wav.
        auto less_ci = [](const std::string &a, const std::string &b) {
            size_t i = 0, j = 0;
            while (i < a.size() && j < b.size()) {
                unsigned char ca = (unsigned char)a[i], cb = (unsigned char)b[j];
                if (std::isdigit(ca) && std::isdigit(cb)) {
                    size_t ia = i, jb = j;
                    while (ia < a.size() && a[ia] == '0') ++ia;
                    while (jb < b.size() && b[jb] == '0') ++jb;
                    size_t ea = ia, eb = jb;
                    while (ea < a.size() && std::isdigit((unsigned char)a[ea])) ++ea;
                    while (eb < b.size() && std::isdigit((unsigned char)b[eb])) ++eb;
                    if (ea - ia != eb - jb) return ea - ia < eb - jb;
                    int cmp = a.compare(ia, ea - ia, b, jb, eb - jb);
                    if (cmp) return cmp < 0;
                    i = ea; j = eb;
                    continue;
                }
                ca = (unsigned char)std::tolower(ca); cb = (unsigned char)std::tolower(cb);
                if (ca != cb) return ca < cb;
                ++i; ++j;
            }
            return a.size() - i < b.size() - j;
        };
        std::sort(paths.begin(), paths.end(), less_ci);
        if (paths.size() > kRadioMaxTracks) paths.resize(kRadioMaxTracks);
        const std::string ini = dir + "radio.ini";
        if (GetFileAttributesA(ini.c_str()) == INVALID_FILE_ATTRIBUTES) {
            FILE *f = nullptr;
            if (fopen_s(&f, ini.c_str(), "wb") == 0 && f) {
                fprintf(f, "; Song metadata for the radio playlist. Use the exact WAV filename as each section.\r\n"
                           "; Edit title and artist, then restart the game to reload the list.\r\n\r\n");
                for (const auto &path : paths) {
                    size_t slash = path.find_last_of("\\/");
                    std::string name = slash == std::string::npos ? path : path.substr(slash + 1);
                    size_t dot = name.find_last_of('.');
                    std::string title = dot == std::string::npos ? name : name.substr(0, dot);
                    fprintf(f, "[%s]\r\ntitle=%s\r\nartist=\r\n\r\n", name.c_str(), title.c_str());
                }
                fclose(f);
            }
        }
        size_t used = 0;
        r.tracks.reserve(paths.size());
        r.tags.reserve(paths.size());
        for (const auto &path : paths) {
            std::vector<int16_t> track;
            size_t remaining = kMusicBudgetBytes - used;
            if (!remaining || !load_music(path, track, remaining)) continue;
            used += track.size() * sizeof(int16_t);
            logf("[radio] track: %s (%.1f s)", path.c_str(), (double)(track.size() / 2) / audio_out::RATE);
            r.tracks.push_back(std::move(track));
            size_t slash = path.find_last_of("\\/");
            std::string name = slash == std::string::npos ? path : path.substr(slash + 1);
            size_t dot = name.find_last_of('.');
            std::string fallback = dot == std::string::npos ? name : name.substr(0, dot);
            char title[512] = {}, artist[512] = {};
            GetPrivateProfileStringA(name.c_str(), "title", fallback.c_str(), title, (DWORD)sizeof title, ini.c_str());
            GetPrivateProfileStringA(name.c_str(), "artist", "", artist, (DWORD)sizeof artist, ini.c_str());
            auto wide = [](const char *s) {
                int n = MultiByteToWideChar(CP_ACP, 0, s, -1, nullptr, 0);
                std::wstring w(n > 0 ? (size_t)n : 0, L'\0');
                if (n > 0) {
                    MultiByteToWideChar(CP_ACP, 0, s, -1, &w[0], n);
                    w.pop_back();
                }
                return w;
            };
            r.tags.push_back({wide(title), wide(artist)});
        }
        if (!r.tracks.empty()) {
            r.playlist.reserve(r.tracks.size());
            for (const auto &track : r.tracks) r.playlist.push_back({track.data(), track.size() / 2});
            audio_out::radio_set_playlist(r.playlist.data(), r.playlist.size(), r.cfg);
            logf("[radio] playlist ready: %u track(s), %.1f MB", (unsigned)r.playlist.size(), (double)used / (1024.0 * 1024.0));
        } else logf("[radio] no usable tracks in %s (expected radio*.wav, up to 90 MB each)", dir.c_str());
    } catch (...) { logf("[radio] playlist loading failed (memory or file error)"); }
    r.state = 2;
    audio_out::radio_enable(r.enabled.load());
    audio_out::radio_pause(!r.level_active.load());
}

struct MusicState {
    std::atomic<int> state{0}; // 0 not started, 1 loading, 2 finished (with or without a track)
    std::string dir;
    audio_out::MusicCfg cfg{};
    std::vector<std::vector<int16_t>> tracks; // retained: the audio thread reads these for the rest of the run
    std::vector<audio_out::MusicTrack> playlist;
};
MusicState &music_state()
{
    static MusicState *m = new MusicState; // on purpose never deleted (the thread may still be running at exit)
    return *m;
}

void music_thread()
{
    MusicState &m = music_state();
    SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_BELOW_NORMAL);
    ULONGLONG t0 = GetTickCount64();
    try {
        std::vector<std::string> paths;
        WIN32_FIND_DATAA fd = {};
        HANDLE find = FindFirstFileA((m.dir + "music*.wav").c_str(), &fd);
        if (find != INVALID_HANDLE_VALUE) {
            do {
                if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) paths.push_back(m.dir + fd.cFileName);
            } while (FindNextFileA(find, &fd));
            FindClose(find);
        }
        auto lower = [](char c) { return (char)std::tolower((unsigned char)c); };
        auto less_ci = [&](const std::string &a, const std::string &b) {
            return std::lexicographical_compare(a.begin(), a.end(), b.begin(), b.end(),
                                                [&](char x, char y) { return lower(x) < lower(y); });
        };
        std::sort(paths.begin(), paths.end(), [&](const std::string &a, const std::string &b) {
            const std::string an = a.substr(m.dir.size()), bn = b.substr(m.dir.size());
            bool a_main = !less_ci("music.wav", an) && !less_ci(an, "music.wav");
            bool b_main = !less_ci("music.wav", bn) && !less_ci(bn, "music.wav");
            return a_main != b_main ? a_main : less_ci(an, bn);
        });
        if (paths.size() > kMusicMaxTracks) paths.resize(kMusicMaxTracks);

        size_t used = 0;
        m.tracks.reserve(paths.size());
        for (const std::string &path : paths) {
            std::vector<int16_t> track;
            size_t remaining = kMusicBudgetBytes - used;
            if (!remaining || !load_music(path, track, remaining)) continue;
            used += track.size() * sizeof(int16_t);
            logf("[armory] music track: %s (%.1f s, %.1f MB)", path.c_str(), (double)(track.size() / 2) / audio_out::RATE,
                 (double)(track.size() * sizeof(int16_t)) / (1024.0 * 1024.0));
            m.tracks.push_back(std::move(track));
        }
        if (!m.tracks.empty()) {
            m.playlist.reserve(m.tracks.size());
            for (const auto &track : m.tracks) m.playlist.push_back({track.data(), track.size() / 2});
            audio_out::music_set_playlist(m.playlist.data(), m.playlist.size(), m.cfg);
            logf("[armory] music playlist: %u track(s), %.1f MB, loaded in %llu ms", (unsigned)m.playlist.size(),
                 (double)used / (1024.0 * 1024.0), (unsigned long long)(GetTickCount64() - t0));
        } else logf("[armory] no usable music in %s (expected music*.wav)", m.dir.c_str());
    } catch (...) {
        m.tracks.clear();
        m.playlist.clear();
        logf("[armory] music: playlist loading failed (memory or file error)");
    }
    m.state = 2;
}

// A decaying chord: partials = {frequency, level}. Starts at `start` seconds.
void add_tone(std::vector<float> &o, float start, float len, float decay, const float (*partials)[2], int np, float gain)
{
    size_t i0 = (size_t)(start * audio_out::RATE), n = (size_t)(len * audio_out::RATE);
    if (o.size() < (i0 + n) * 2) o.resize((i0 + n) * 2, 0.0f);
    for (size_t i = 0; i < n; i++) {
        float t = (float)i / audio_out::RATE, env = expf(-t * decay) * std::min(1.0f, t / 0.002f); // 2 ms attack
        float s = 0;
        for (int p = 0; p < np; p++) s += sinf(2 * kPi * partials[p][0] * t) * partials[p][1];
        o[(i0 + i) * 2] += s * env * gain * kVolume;
        o[(i0 + i) * 2 + 1] += s * env * gain * kVolume;
    }
}

void synth(Id id, std::vector<float> &o)
{
    switch (id) {
    case KILL: { // bright bell "ding"
        const float p[3][2] = {{1568, 0.5f}, {2352, 0.3f}, {3136, 0.2f}};
        add_tone(o, 0, 0.45f, 11, p, 3, 0.45f);
        break;
    }
    case BUY: { // two quick rising notes
        const float a[2][2] = {{880, 0.7f}, {1760, 0.3f}}, b[2][2] = {{1320, 0.7f}, {2640, 0.3f}};
        add_tone(o, 0, 0.12f, 20, a, 2, 0.4f);
        add_tone(o, 0.07f, 0.3f, 12, b, 2, 0.4f);
        break;
    }
    case DENY: { // low double buzz
        const float a[2][2] = {{140, 0.6f}, {210, 0.4f}};
        add_tone(o, 0, 0.12f, 14, a, 2, 0.5f);
        add_tone(o, 0.14f, 0.16f, 14, a, 2, 0.5f);
        break;
    }
    default: { // OPEN: soft tick
        const float a[1][2] = {{600, 1.0f}};
        add_tone(o, 0, 0.06f, 50, a, 1, 0.3f);
        break;
    }
    }
}

} // namespace

bool decode_wav(const uint8_t *bytes, size_t n, std::vector<float> &out, float volume)
{
    return decode_wav_bytes(bytes, n, out, volume);
}

void play(Id id)
{
    Sound &s = g_snd[id];
    if (!s.tried) {
        s.tried = true;
        std::string path = exe_dir() + "armory\\" + kFile[id] + ".wav";
        bool loaded = false;
        try {
            loaded = load_wav(path, s.lr);
        } catch (...) {
            loaded = false;
        }
        if (loaded) logf("[armory] sound %s: %s", kFile[id], path.c_str());
        else {
            s.lr.clear();
            synth(id, s.lr);
        }
    }
    if (!s.lr.empty()) audio_out::play_sfx(s.lr.data(), s.lr.size() / 2, 1.0f);
}

void music(bool armory_open, const audio_out::MusicCfg &cfg)
{
    audio_out::set_game_volume(armory_open ? 0.0f : 1.0f, 2.0f);
    MusicState &m = music_state();
    int idle = 0;
    if (armory_open && m.state.compare_exchange_strong(idle, 1)) { // first opening: load the track in the background
        m.dir = exe_dir() + "armory\\";
        m.cfg = cfg;
        try {
            std::thread(music_thread).detach();
        } catch (...) {
            logf("[armory] music: could not start the loading thread");
            m.state = 2;
        }
    }
    audio_out::music_open(armory_open);
}

void radio(bool enabled)
{
    RadioState &r = radio_state();
    r.enabled.store(enabled);
    audio_out::radio_enable(enabled && r.level_active.load());
    if (enabled) {
        int idle = 0;
        if (r.state.compare_exchange_strong(idle, 1)) {
            try { std::thread(radio_thread).detach(); }
            catch (...) { r.state = 2; logf("[radio] could not start loading thread"); }
        }
    }
}

void radio_level_active(bool active)
{
    RadioState &r = radio_state();
    bool was_active = r.level_active.exchange(active);
    if (active) {
        // Keep enablement in sync even if the PC setting changed outside a level.
        audio_out::radio_enable(r.enabled.load());
        audio_out::radio_pause(false);
    } else if (was_active) {
        if (bindings::pause_menu_was_requested()) audio_out::radio_pause(true);
        else audio_out::radio_fade_out(3.0f); // death / mission exit: fade instead of cutting off
    }
}

void radio_volume(float level) { audio_out::radio_set_volume(level); }

bool radio_now_playing(std::wstring &title, std::wstring &artist, float &alpha)
{
    RadioState &r = radio_state();
    if (!audio_out::radio_enabled()) return false;
    int i = audio_out::radio_current_track();
    if (i < 0 || (size_t)i >= r.tags.size()) return false;
    title = r.tags[(size_t)i].title;
    artist = r.tags[(size_t)i].artist;
    alpha = audio_out::radio_caption_alpha();
    return !title.empty() || !artist.empty();
}

} // namespace sfx
