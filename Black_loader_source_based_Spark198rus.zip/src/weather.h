// Thunderstorm: random lightning flashes that light the map, and a thunder wav that plays some milliseconds after
// each big flash. Everything is set in weather.ini next to black.exe (written on first start, re-read while the game
// runs); thunder sounds are the .wav files in the thunder\ folder next to black.exe (folder is set in weather.ini).
// Pattern, timing and the light itself: see weather_core.h, d3d/weather_pass.inc, weather.ini.
#pragma once

namespace weather {

// What the screen pass needs for the current frame.
struct Look {
    float level;     // 0..~1.3 flash brightness right now
    float rgb[3];    // flash colour * strength
    float floor, gain, gun, range, far_fade, normal_strength, sky_gain;
};

// Call once per presented frame (render thread). Advances the storm, starts a strike when one is due and plays the
// thunder when its time has come. True when a flash is visible this frame (then `out` is filled).
bool frame(Look &out);

// Start a strike right now (F9 test key): big = the "small, small, BIG" pattern, else a weak flash.
void trigger(bool big);

} // namespace weather
