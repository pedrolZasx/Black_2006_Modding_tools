#pragma once
// Fire lights: every draw made by a shader listed in fire_lights.ini (found with the F11/F12 shader scan) becomes a
// short-lived point light at the position of the flame sprites. When the fire goes away (barrel burns out, explosion
// ends) its light fades out. Settings: fire_lights.ini next to black.exe, reloaded while the game runs.
#include <cstdint>
#include "world_lights.h"

namespace fire_lights {

// Called from begin_draw for every draw that uses a vertex shader. True when this shader is a fire shader (then
// call ingest() from the draw functions with the converted vertices).
bool is_fire_shader(uint32_t shader_hash);

// Vertices of one fire draw. `base` = first vertex, stride in bytes, pos_off = byte offset of v0 (float x,y,z) inside a
// vertex, count vertices. `constants` = the 192 vertex shader constants (float4). `rows` = the decoded transform for oPos (four DP4 slots, or [-2, scale-constant, offset-constant, -2] for MUL+ADD),
// or all -1 when no transform was found; the game's world -> clip matrix
// (constants vp_const..vp_const+3) is inverted to turn those clip positions back into world positions.
void ingest(uint32_t shader_hash, const uint8_t *base, uint32_t stride, int pos_off, uint32_t count, const float (*constants)[4], const int rows[4]);

// Appends the current fire lights for `level` to out (at most max). Returns how many were added.
int collect(int level, world_lights::Light *out, int max);

// Positions for the debug-marked fire profiles; consumed by the world-light render pass.
int debug_positions(int level, float out[][3], int max);

} // namespace fire_lights
