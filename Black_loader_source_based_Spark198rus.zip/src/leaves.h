﻿#pragma once
#include "rain.h"
#include <string>
#include <vector>
namespace leaves {
struct Particle { float p[3], size, angle, alpha; };
struct Frame { std::string texture; float opacity; const Particle *particles; int count; };
bool frame(const rain::Frame &camera, int level, Frame &out);
}
