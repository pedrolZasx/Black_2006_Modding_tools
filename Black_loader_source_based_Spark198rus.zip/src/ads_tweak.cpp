#include "ads_tweak.h"

#include "common.h"
#include "settings.h"
#include "ui/armory.h"

#include <algorithm>
#include <cmath>
#include <cwchar>
#include <cstring>

extern "C" volatile LONG g_ads_tweak_aim_active = 0;
extern "C" volatile LONG g_ads_tweak_force_nozoom = 0;
extern "C" volatile LONG g_ads_modern_mode = 1;
extern "C" volatile LONG g_ads_sniper_scope_active = 0;
extern "C" volatile float g_ads_sniper_zoom = 3.0f;
extern "C" volatile LONG g_ads_sniper_native_linger = 0;
extern "C" volatile float g_native_weapon_zoom = 1.0f;
extern "C" volatile float g_ads_tweak_zoom = 1.0f;

namespace {
constexpr uint32_t kMagic = 0x4253414B; // "DASB", shared layout v8 (per-gun transition times)
AdsTweakShared *g_shared;
HANDLE g_mapping;
bool g_transition_initialized;
bool g_transition_target;
float g_transition_from;
float g_transition_to;
ULONGLONG g_transition_start_ms;
float g_transition_duration_ms = 220.0f;
volatile LONG g_pose_weight_10000;
volatile LONG g_active_weapon_id = -2;
bool g_zoom_transition_initialized;
float g_zoom_transition_from = 1.0f, g_zoom_transition_to = 1.0f;
float g_zoom_transition_duration_ms = 220.0f;
ULONGLONG g_zoom_transition_start_ms;

int profile_time_ms(int weapon, bool zoom)
{
    if (weapon < 0 || weapon >= kAdsWeaponCount || !g_cfg.ads_weapon_profile[weapon]) return 220;
    const int value = zoom ? g_cfg.ads_weapon_zoom_ms[weapon] : g_cfg.ads_weapon_ads_ms[weapon];
    return value >= 50 ? std::clamp(value, 50, 1000) : 220;
}

float profile_zoom(int weapon)
{
    return weapon >= 0 && weapon < kAdsWeaponCount && g_cfg.ads_weapon_profile[weapon]
               ? std::clamp(g_cfg.ads_weapon_zoom[weapon], 1.0f, 4.0f) : 1.0f;
}

float update_pose_weight(ULONGLONG now)
{
    float t = g_transition_duration_ms <= 0.0f ? 1.0f :
                  std::clamp((float)(now - g_transition_start_ms) / g_transition_duration_ms, 0.0f, 1.0f);
    t = t * t * (3.0f - 2.0f * t); // smoothstep
    float weight = g_transition_from + (g_transition_to - g_transition_from) * t;
    InterlockedExchange(&g_pose_weight_10000, (LONG)lroundf(weight * 10000.0f));
    return weight;
}

float update_zoom_transition(ULONGLONG now)
{
    if (!g_zoom_transition_initialized) {
        g_zoom_transition_initialized = true;
        g_zoom_transition_start_ms = now;
        g_ads_tweak_zoom = 1.0f;
    }
    float t = g_zoom_transition_duration_ms <= 0.0f ? 1.0f :
                  std::clamp((float)(now - g_zoom_transition_start_ms) / g_zoom_transition_duration_ms, 0.0f, 1.0f);
    t = t * t * (3.0f - 2.0f * t);
    float zoom = g_zoom_transition_from + (g_zoom_transition_to - g_zoom_transition_from) * t;
    g_ads_tweak_zoom = zoom;
    return zoom;
}

void set_zoom_target(float target, float duration_ms, ULONGLONG now)
{
    target = std::clamp(target, 1.0f, 4.0f);
    duration_ms = std::clamp(duration_ms, 50.0f, 1000.0f);
    float current = update_zoom_transition(now);
    if (std::fabs(target - g_zoom_transition_to) < 0.0005f &&
        std::fabs(duration_ms - g_zoom_transition_duration_ms) < 0.5f) return;
    g_zoom_transition_from = current;
    g_zoom_transition_to = target;
    g_zoom_transition_duration_ms = duration_ms;
    g_zoom_transition_start_ms = now;
}

void sync_zoom_target(ULONGLONG now)
{
    const int weapon = InterlockedCompareExchange(&g_active_weapon_id, 0, 0);
    const bool active = g_ads_modern_mode && InterlockedCompareExchange((volatile LONG *)&g_ads_tweak_aim_active, 0, 0);
    set_zoom_target(active ? profile_zoom(weapon) : 1.0f, (float)profile_time_ms(weapon, true), now);
}
}

void ads_tweak_initialize()
{
    InterlockedExchange((volatile LONG *)&g_ads_tweak_force_nozoom, g_cfg.ads_tweak_ui ? 1 : 0);
    InterlockedExchange((volatile LONG *)&g_ads_modern_mode, g_cfg.ads_modern ? 1 : 0);
    g_ads_tweak_zoom = 1.0f;
    wchar_t name[64];
    swprintf_s(name, L"Local\\BlackAdsTweak_%lu", GetCurrentProcessId());
    g_mapping = CreateFileMappingW(INVALID_HANDLE_VALUE, nullptr, PAGE_READWRITE, 0, sizeof(AdsTweakShared), name);
    if (!g_mapping) {
        logf("ads-tweak: couldn't create the shared pose mapping (%lu)", GetLastError());
        return;
    }
    const bool existed = GetLastError() == ERROR_ALREADY_EXISTS;
    g_shared = (AdsTweakShared *)MapViewOfFile(g_mapping, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(AdsTweakShared));
    if (!g_shared) {
        logf("ads-tweak: couldn't map the shared pose data (%lu)", GetLastError());
        CloseHandle(g_mapping);
        g_mapping = nullptr;
        return;
    }
    if (!existed || g_shared->magic != kMagic) {
        ZeroMemory(g_shared, sizeof(*g_shared));
        g_shared->magic = kMagic;
        g_shared->move_all = g_cfg.ads_move_all ? 1 : 0;
        g_shared->weapon_id = -2;
        g_shared->global_rotation = g_cfg.ads_global_rotation ? 1 : 0;
        g_shared->pivot_joint = std::clamp(g_cfg.ads_rotation_pivot, 0, kAdsJointCount - 1);
        g_shared->weapon_zoom_milli = 1000;
        g_shared->ads_transition_ms = 220;
        g_shared->zoom_transition_ms = 220;
        for (int j = 0; j < kAdsJointCount; ++j)
            for (int axis = 0; axis < 6; ++axis) g_shared->offsets[j][axis] = g_cfg.ads_joint[j][axis];
    }
    logf("ads-tweak: shared joint editor ready (44 joints, skin constants c60-c191)");
}

void ads_tweak_poll()
{
    if (!g_shared || g_shared->magic != kMagic) return;
    float copy[kAdsJointCount][6];
    LONG before, after;
    for (;;) {
        before = InterlockedCompareExchange(&g_shared->sequence, 0, 0);
        if (before & 1) { YieldProcessor(); continue; }
        memcpy(copy, g_shared->offsets, sizeof copy);
        MemoryBarrier();
        after = InterlockedCompareExchange(&g_shared->sequence, 0, 0);
        if (before == after && !(after & 1)) break;
    }

    const int previous_weapon = InterlockedCompareExchange(&g_active_weapon_id, 0, 0);
    const int current_weapon = armory::current_weapon_id();
    InterlockedExchange((volatile LONG *)&g_ads_sniper_scope_active,
                        current_weapon == 2 && InterlockedCompareExchange((volatile LONG *)&g_ads_modern_mode, 0, 0) && ads_tweak_is_aiming() ? 1 : 0);
    auto store_pose = [&](float target[kAdsJointCount][6]) {
        for (int j = 0; j < kAdsJointCount; ++j) {
            for (int axis = 0; axis < 3; ++axis) target[j][axis] = std::clamp(copy[j][axis], -5.0f, 5.0f);
            for (int axis = 3; axis < 6; ++axis) target[j][axis] = std::clamp(copy[j][axis], -180.0f, 180.0f);
        }
    };
    if (previous_weapon >= 0 && previous_weapon < kAdsWeaponCount)
    {
        store_pose(g_cfg.ads_weapon_joint[previous_weapon]);
        g_cfg.ads_weapon_zoom[previous_weapon] = std::clamp(
            InterlockedCompareExchange(&g_shared->weapon_zoom_milli, 1000, 0) * 0.001f, 1.0f, 4.0f);
        g_cfg.ads_weapon_ads_ms[previous_weapon] = std::clamp(
            (int)InterlockedCompareExchange(&g_shared->ads_transition_ms, 220, 0), 50, 1000);
        g_cfg.ads_weapon_zoom_ms[previous_weapon] = std::clamp(
            (int)InterlockedCompareExchange(&g_shared->zoom_transition_ms, 220, 0), 50, 1000);
    } else
        store_pose(g_cfg.ads_joint);

    if (current_weapon != previous_weapon) {
        const float(*pose)[6] = g_cfg.ads_joint;
        if (current_weapon >= 0 && current_weapon < kAdsWeaponCount) {
            if (!g_cfg.ads_weapon_profile[current_weapon]) {
                memcpy(g_cfg.ads_weapon_joint[current_weapon], g_cfg.ads_joint, sizeof g_cfg.ads_joint);
                g_cfg.ads_weapon_profile[current_weapon] = true;
            }
            if (g_cfg.ads_weapon_ads_ms[current_weapon] < 50) g_cfg.ads_weapon_ads_ms[current_weapon] = 220;
            if (g_cfg.ads_weapon_zoom_ms[current_weapon] < 50) g_cfg.ads_weapon_zoom_ms[current_weapon] = 220;
            pose = g_cfg.ads_weapon_joint[current_weapon];
        }
        InterlockedIncrement(&g_shared->sequence);
        MemoryBarrier();
        memcpy(g_shared->offsets, pose, sizeof g_shared->offsets);
        MemoryBarrier();
        InterlockedIncrement(&g_shared->sequence);
        InterlockedExchange(&g_active_weapon_id, current_weapon);
        InterlockedExchange(&g_shared->weapon_id, current_weapon);
        const float zoom = current_weapon >= 0 && current_weapon < kAdsWeaponCount && g_cfg.ads_weapon_profile[current_weapon]
                               ? std::clamp(g_cfg.ads_weapon_zoom[current_weapon], 1.0f, 4.0f) : 1.0f;
        InterlockedExchange(&g_shared->weapon_zoom_milli, (LONG)lroundf(zoom * 1000.0f));
        InterlockedExchange(&g_shared->ads_transition_ms, profile_time_ms(current_weapon, false));
        InterlockedExchange(&g_shared->zoom_transition_ms, profile_time_ms(current_weapon, true));
        logf("ads-tweak: active weapon ID %d", current_weapon);
    }
    if (current_weapon >= 0 && current_weapon < kAdsWeaponCount && g_cfg.ads_weapon_profile[current_weapon]) {
        g_cfg.ads_weapon_zoom[current_weapon] = std::clamp(
            InterlockedCompareExchange(&g_shared->weapon_zoom_milli, 1000, 0) * 0.001f, 1.0f, 4.0f);
        g_cfg.ads_weapon_ads_ms[current_weapon] = std::clamp(
            (int)InterlockedCompareExchange(&g_shared->ads_transition_ms, 220, 0), 50, 1000);
        g_cfg.ads_weapon_zoom_ms[current_weapon] = std::clamp(
            (int)InterlockedCompareExchange(&g_shared->zoom_transition_ms, 220, 0), 50, 1000);
    }
    g_cfg.ads_move_all = InterlockedCompareExchange(&g_shared->move_all, 0, 0) != 0;
    g_cfg.ads_global_rotation = InterlockedCompareExchange(&g_shared->global_rotation, 0, 0) != 0;
    g_cfg.ads_rotation_pivot = std::clamp((int)InterlockedCompareExchange(&g_shared->pivot_joint, 0, 0), 0, kAdsJointCount - 1);
    g_cfg.ads_modern = InterlockedCompareExchange((volatile LONG *)&g_ads_modern_mode, 0, 0) != 0;
    sync_zoom_target(GetTickCount64());
    if (InterlockedExchange(&g_shared->save_requested, 0)) {
        if (current_weapon >= 0 && current_weapon < kAdsWeaponCount) g_cfg.ads_weapon_profile[current_weapon] = true;
        settings_save();
        logf("ads-tweak: saved joint offsets to black.ini");
    }
}

void ads_tweak_set_modern_mode(bool modern)
{
    g_cfg.ads_modern = modern;
    InterlockedExchange((volatile LONG *)&g_ads_modern_mode, modern ? 1 : 0);
    InterlockedExchange((volatile LONG *)&g_ads_sniper_scope_active,
                        modern && armory::current_weapon_id() == 2 && ads_tweak_is_aiming() ? 1 : 0);
    sync_zoom_target(GetTickCount64());
}

void ads_tweak_set_aim(bool active)
{
    const ULONGLONG now = GetTickCount64();
    if (!g_transition_initialized) {
        g_transition_initialized = true;
        g_transition_target = false;
        g_transition_from = g_transition_to = 0.0f;
        g_transition_start_ms = now;
    }
    float weight = update_pose_weight(now);
    if (active != g_transition_target) {
        g_transition_from = weight;
        g_transition_to = active ? 1.0f : 0.0f;
        const int weapon = InterlockedCompareExchange(&g_active_weapon_id, 0, 0);
        g_transition_duration_ms = (float)profile_time_ms(weapon, false);
        g_transition_start_ms = now;
        g_transition_target = active;
        weight = update_pose_weight(now);
    }
    InterlockedExchange((volatile LONG *)&g_ads_tweak_aim_active, active ? 1 : 0);
    const bool modern = InterlockedCompareExchange((volatile LONG *)&g_ads_modern_mode, 0, 0) != 0;
    InterlockedExchange((volatile LONG *)&g_ads_sniper_scope_active,
                        active && modern && armory::current_weapon_id() == 2 ? 1 : 0);
    sync_zoom_target(now);
    if (g_shared && g_shared->magic == kMagic)
        InterlockedExchange(&g_shared->aim_active, active ? 1 : 0);
}

bool ads_tweak_is_aiming() { return InterlockedCompareExchange((volatile LONG *)&g_ads_tweak_aim_active, 0, 0) != 0; }

void ads_tweak_sniper_zoom_update(int direction, float elapsed_seconds)
{
    if (!direction || elapsed_seconds <= 0.0f) return;
    const float current = g_ads_sniper_zoom;
    const float rate = 0.9f; // logarithmic zoom ratio per second, smooth across poll rates
    const float next = current * expf((direction > 0 ? 1.0f : -1.0f) * rate * std::min(elapsed_seconds, 0.05f));
    g_ads_sniper_zoom = std::clamp(next, kSniperZoomMin, kSniperZoomMax);
}

float ads_tweak_pose_weight()
{
    return InterlockedCompareExchange(&g_pose_weight_10000, 0, 0) * 0.0001f;
}

bool ads_tweak_editor_hover()
{
    return g_shared && g_shared->magic == kMagic && InterlockedCompareExchange(&g_shared->editor_hover, 0, 0) != 0;
}

void ads_tweak_apply(float (*skin_constants)[4], int register_count)
{
    const float weight = ads_tweak_pose_weight();
    if (!g_ads_modern_mode || !skin_constants || register_count < kAdsJointCount * 3 || weight <= 0.0f) return;
    // c60-c191 hold up to 44 three-row affine joint matrices.
    const int weapon = InterlockedCompareExchange(&g_active_weapon_id, 0, 0);
    const float(*pose)[6] = weapon >= 0 && weapon < kAdsWeaponCount && g_cfg.ads_weapon_profile[weapon]
                                ? g_cfg.ads_weapon_joint[weapon]
                                : g_cfg.ads_joint;
    const bool global_rotation = g_shared && InterlockedCompareExchange(&g_shared->global_rotation, 0, 0) != 0;
    const int pivot_joint = g_shared ? std::clamp((int)InterlockedCompareExchange(&g_shared->pivot_joint, 0, 0),
                                                 0, kAdsJointCount - 1) : 0;
    float grx = 0.0f, gry = 0.0f, grz = 0.0f;
    if (global_rotation) {
        grx = pose[pivot_joint][3] * weight * 0.01745329251994329577f;
        gry = pose[pivot_joint][4] * weight * 0.01745329251994329577f;
        grz = pose[pivot_joint][5] * weight * 0.01745329251994329577f;
    }
    const float gsx = sinf(grx), gcx = cosf(grx), gsy = sinf(gry), gcy = cosf(gry), gsz = sinf(grz), gcz = cosf(grz);
    const float global_r[3][3] = {{gcz * gcy, gcz * gsy * gsx - gsz * gcx, gcz * gsy * gcx + gsz * gsx},
                                  {gsz * gcy, gsz * gsy * gsx + gcz * gcx, gsz * gsy * gcx - gcz * gsx},
                                  {-gsy, gcy * gsx, gcy * gcx}};
    float pivot[3] = {};
    if (global_rotation)
        for (int axis = 0; axis < 3; ++axis) pivot[axis] = skin_constants[pivot_joint * 3 + axis][3];
    for (int j = 0; j < kAdsJointCount; ++j) {
        float (*m)[4] = &skin_constants[j * 3];
        if (global_rotation) {
            float basis[3][3];
            for (int row = 0; row < 3; ++row)
                for (int col = 0; col < 3; ++col) basis[row][col] = m[row][col];
            for (int row = 0; row < 3; ++row)
                for (int col = 0; col < 3; ++col)
                    m[row][col] = global_r[row][0] * basis[0][col] + global_r[row][1] * basis[1][col] +
                                  global_r[row][2] * basis[2][col];
            float delta[3] = {m[0][3] - pivot[0], m[1][3] - pivot[1], m[2][3] - pivot[2]};
            for (int row = 0; row < 3; ++row)
                m[row][3] = pivot[row] + global_r[row][0] * delta[0] + global_r[row][1] * delta[1] +
                            global_r[row][2] * delta[2];
            for (int row = 0; row < 3; ++row) m[row][3] += pose[j][row] * weight;
            continue;
        }
        float rx = pose[j][3] * weight * 0.01745329251994329577f;
        float ry = pose[j][4] * weight * 0.01745329251994329577f;
        float rz = pose[j][5] * weight * 0.01745329251994329577f;
        float sx = sinf(rx), cx = cosf(rx), sy = sinf(ry), cy = cosf(ry), sz = sinf(rz), cz = cosf(rz);
        const float r[3][3] = {{cz * cy, cz * sy * sx - sz * cx, cz * sy * cx + sz * sx},
                               {sz * cy, sz * sy * sx + cz * cx, sz * sy * cx - cz * sx},
                               {-sy, cy * sx, cy * cx}};
        float basis[3][3];
        for (int row = 0; row < 3; ++row)
            for (int col = 0; col < 3; ++col) basis[row][col] = m[row][col];
        for (int row = 0; row < 3; ++row)
            for (int col = 0; col < 3; ++col)
                m[row][col] = basis[row][0] * r[0][col] + basis[row][1] * r[1][col] + basis[row][2] * r[2][col];
        for (int row = 0; row < 3; ++row) m[row][3] += pose[j][row] * weight;
    }
}

bool ads_tweak_launch_ui()
{
    wchar_t exe[MAX_PATH];
    DWORD n = GetModuleFileNameW(nullptr, exe, MAX_PATH);
    if (!n || n >= MAX_PATH) return false;
    std::wstring path(exe, n);
    size_t slash = path.find_last_of(L"\\/");
    if (slash == std::wstring::npos) return false;
    path.resize(slash + 1);
    path += L"black_ads_tweak.exe";
    wchar_t command[MAX_PATH * 2];
    swprintf_s(command, L"\"%s\" %lu", path.c_str(), GetCurrentProcessId());
    STARTUPINFOW si = {sizeof si};
    PROCESS_INFORMATION pi = {};
    if (!CreateProcessW(path.c_str(), command, nullptr, nullptr, FALSE, 0, nullptr, nullptr, &si, &pi)) {
        logf("ads-tweak: couldn't start %ls (%lu)", path.c_str(), GetLastError());
        return false;
    }
    CloseHandle(pi.hThread);
    CloseHandle(pi.hProcess);
    logf("ads-tweak: launched %ls", path.c_str());
    return true;
}
