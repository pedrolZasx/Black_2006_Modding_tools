#pragma once

#include <string>
#include <windows.h>

namespace world_lights {

struct Light {
    int level;
    float position[3];
    float direction[3];
    float color[3];
    float intensity;
    float range;
    float inner_degrees;
    float outer_degrees;
    bool cone;
    float flicker_amount;
    float flicker_speed;
    bool follow_camera;
    bool rotation_enabled;
    float rotation[3]; // yaw, pitch, roll in degrees
    // volumetric beam (fog shaft with moving noise) and drifting dust, drawn in the cone
    float vol_intensity;   // 0 = off
    float vol_density;
    float vol_feather;     // 0 hard cone edge .. 1 very soft
    float vol_noise_scale; // fog pattern size (bigger = finer)
    float vol_noise_speed; // fog drift speed
    float vol_wind_yaw;    // degrees, direction the fog and dust drift
    float dust_amount;
    float dust_size;       // metres between dust specks
    // texture beam (PNG with transparency drawn as a camera-facing ribbon along the cone) - see world_fx.h
    // reuses: vol_intensity = brightness, vol_density = opacity, dust_amount = dust layer strength,
    //         dust_size = dust tile size in metres, vol_noise_speed = dust drift speed
    int   beam_mode;       // 0 = ray-marched volumetric (old, heavy), 1 = PNG texture (default)
    int   beam_blend;      // 0 additive, 1 alpha, 2 screen
    float beam_length;     // x range (1 = beam ends at the light's range)
    float beam_width;      // x cone width (1 = matches the outer cone angle)
    float beam_soft;       // metres over which the beam fades out where it meets geometry (0 = hard)
};

constexpr int kMaxLights = 32;
struct Shared {
    uint32_t magic;
    volatile LONG sequence;
    volatile LONG save_requested;
    volatile LONG create_requested;
    volatile LONG place_requested;
    volatile LONG selected_index;
    volatile LONG ui_open;
    volatile LONG count;
    volatile LONG current_level;
    float camera[3], right[3], up[3], forward[3];
    Light lights[kMaxLights];
};

constexpr int kMaxVisibleLights = 4;

int active_for_level(int level, Light out[kMaxVisibleLights]);
void editor_poll(bool focused, const float camera[3], const float forward[3]);
void update_camera(const float camera[3], const float right[3], const float up[3], const float forward[3]);
bool freecam_basis(float camera[3], float right[3], float up[3], float forward[3]);
bool editor_active();
bool editor_overlay_text(std::wstring &text);
void close_editor();
void initialize();
bool launch_ui();

} // namespace world_lights
