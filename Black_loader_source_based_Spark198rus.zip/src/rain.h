// 3D rain around the player. Real rain drops (a few thousand, world-space streaks). Each drop has a fixed place in the
// world (a function of world position and time only) and only the drops inside a box around the camera are worked out
// and drawn, so the rain covers the whole level without following the player. Drawn by d3d/rain_pass.inc, depth-tested against
// the scene, so walls, props and the player's gun hide the drops behind them.
// Everything is set in rain.ini next to black.exe (written on first start, re-read while the game runs).
// F7 toggles the rain, F6 writes the camera position to black.log (to build the `indoor` boxes of rain.ini).
#pragma once

#include <cstdint>

namespace rain {

struct Drop {
    float p[3];   // world position of the head of the streak (the lowest point)
    float dir[3]; // unit vector the drop moves in (down + wind): the streak slants along it
    float len;    // streak length, metres
    float alpha;  // 0..1 own brightness
    float blend;  // 0..1: how much the streak takes the colour of the background (0 = plain rain colour)
};

// What the draw pass needs for this frame. Valid until the next frame().
struct Frame {
    // camera, world space. right/up/fwd are the rows of the camera matrix (world = cam + x*right + y*up + z*fwd)
    float cam[3];
    float right[3], up[3], fwd[3];
    float fov_deg;     // the camera's live horizontal field of view in degrees, 0 = unknown
    float near_plane;  // the camera's near plane in metres (depth = near / z), 0 = unknown
    float aspect;      // the camera's aspect (1.778 widescreen, 1.333 4:3), 0 = unknown
    // box around the camera
    float radius;      // half size in x and z, metres
    float below, above; // metres under / over the camera
    // look
    float color[3];
    float intensity;   // 0..1+ master (fades in and out with level / indoor zones)
    float width_px;    // streak width in pixels of a 480-line picture
    float near_fade;   // metres: drops closer than this fade out
    float amb_min, amb_gain; // streak brightness = amb_min + amb_gain * brightness of the picture behind it
    const Drop *drops;
    int count;
};

// Once per presented frame (render thread). Advances the rain and fills `out`. False: nothing to draw (rain off, not
// in a level, in a menu / pause / cutscene, camera not readable yet, or inside an indoor box and faded out).
bool frame(Frame &out);

// The mean wind of rain.ini (m/s in world x and z); the foliage wind (wind.cpp) follows it.
bool wind_xz(float out[2]);

} // namespace rain
