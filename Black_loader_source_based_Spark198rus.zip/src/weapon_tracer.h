#pragma once
#include <cstdint>

namespace weapon_tracer {
struct Segment { float position[3]; float direction[3]; int weapon_id; };
struct Settings { bool enabled; bool motion_blur; float color[3]; float thickness; float length; };
void install_patch();
bool segment(int index, Segment &out);
Settings settings(int weapon_id);
float travel_distance(int weapon_id);
} // namespace weapon_tracer
