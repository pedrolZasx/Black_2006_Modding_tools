// The Xbox time-stamp counter. XAPI's QueryPerformanceCounter is a bare `rdtsc` and its
// QueryPerformanceFrequency a constant 733,333,333 Hz (the Xbox CPU clock); the game's own timer helpers
// make the same assumption. On a PC `rdtsc` ticks at the host clock (3-5 GHz), so everything the game
// times in seconds (fades, blur ramps) ran several times too fast. These patches return a 733.33 MHz
// counter derived from the host performance counter instead. The game's calibrated timer (FUN_00180c00,
// which measures raw `rdtsc` against QueryPerformanceCounter) then calibrates itself correctly.
#include "timing.h"

#include "common.h"
#include "ui/armory.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cwchar>
#include <iterator>

namespace {

constexpr uint64_t XBOX_TSC_HZ = 733333333;

// The Xbox never sleeps with a game running, but the PC does: after a sleep (or a debugger break) the host counter
// has moved on by the whole pause, and the game saw one frame that long. So the counter the game reads moves by the
// host time between two readings, but by a second at most; the game reads it many times a frame.
uint64_t xbox_tsc()
{
    static LARGE_INTEGER freq = [] {
        LARGE_INTEGER f;
        QueryPerformanceFrequency(&f);
        return f;
    }();
    static SRWLOCK lock = SRWLOCK_INIT;
    static int64_t last_host, game; // host counts
    LARGE_INTEGER now;
    QueryPerformanceCounter(&now);
    AcquireSRWLockExclusive(&lock);
    if (!last_host) game = last_host = now.QuadPart;
    int64_t step = now.QuadPart - last_host;
    if (step > 0) {
        game += step < freq.QuadPart ? step : freq.QuadPart;
        last_host = now.QuadPart;
    }
    uint64_t t = (uint64_t)game;
    ReleaseSRWLockExclusive(&lock);
    if (step > 2 * freq.QuadPart)
        logf("timing: the clock jumped %.1f s (the PC slept?); the game sees 1 s", (double)step / freq.QuadPart);
    uint64_t f = (uint64_t)freq.QuadPart;
    return t / f * XBOX_TSC_HZ + t % f * XBOX_TSC_HZ / f;
}

// XAPI QueryPerformanceCounter (0x232da), stdcall
BOOL __stdcall xapi_QueryPerformanceCounter(LARGE_INTEGER *p)
{
    p->QuadPart = (LONGLONG)xbox_tsc();
    return TRUE;
}

void __cdecl store_tsc() { *(uint64_t *)(uintptr_t)0x002C0468 = xbox_tsc(); }
uint32_t __cdecl tsc_low() { return (uint32_t)xbox_tsc(); }

// The game's helpers keep ecx; LTCG callers may rely on that, so wrap the C functions.
__declspec(naked) void store_tsc_thunk() // FUN_00084190: *(uint64 *)0x2c0468 = rdtsc
{
    __asm {
        push ecx
        call store_tsc
        pop ecx
        ret
    }
}

__declspec(naked) void tsc_low_thunk() // FUN_000841a0: return (uint32)rdtsc
{
    __asm {
        push ecx
        call tsc_low
        pop ecx
        ret
    }
}

struct Patch {
    uint32_t addr;
    uint8_t expect[6];
    size_t expect_len;
    const void *target;
    const char *what;
};

bool patch(const Patch &p)
{
    auto *code = (uint8_t *)(uintptr_t)p.addr;
    if (memcmp(code, p.expect, p.expect_len) != 0) {
        logf("timing: %s at 0x%08x does not match this build; not patched", p.what, p.addr);
        return false;
    }
    code[0] = 0xE9;
    int32_t rel = (int32_t)((uintptr_t)p.target - (p.addr + 5));
    memcpy(code + 1, &rel, 4);
    return true;
}

} // namespace

namespace {
float g_frame_60 = 1.0f / 60.0f;
float g_frame_30 = 1.0f / 30.0f;

// A disp32/imm32 operand at `at` inside the instruction at `insn` (whose first bytes must match).
struct Operand {
    uint32_t insn;
    uint8_t expect[6];
    uint32_t at, old_value;
};
} // namespace

// Weapon refire at 60 fps. FUN_001EEFD0 (weapon state machine, ebp = weapon user) fires when its timer
// [ebp+0xDC] is <= 0 (FUN_001F0210 subtracts the frame time first) and then sets the timer to the weapon's
// refire interval (e.g. 0.04 s). Checked once per frame, the interval is effectively rounded up to whole
// frames: at 30 fps 0.04 s fires every 2nd frame (66 ms, ~15 shots/s), at 60 fps every 3rd (50 ms, ~20/s).
// The original rate is the 30 fps rounding, so the interval is rounded up to whole 1/30 s steps (minus a
// little, so the 4th 1/60 s frame fires and not the 5th). weapon_tuning.ini applies per-weapon multipliers
// before this rounding; 1.0 preserves the original rate.
namespace {
std::array<float, 17> g_weapon_rate_multiplier{};
std::array<float, 17> g_weapon_damage_multiplier{};
std::array<bool, 17> g_weapon_rate_logged{};
std::array<bool, 17> g_weapon_damage_logged{};
bool g_refire_30fps_rounding;
DWORD g_weapon_rate_checked;
FILETIME g_weapon_rate_stamp{};
bool g_weapon_rate_loaded;
wchar_t g_weapon_rate_ini[MAX_PATH]{};

bool read_u32(uint32_t address, uint32_t &value)
{
    MEMORY_BASIC_INFORMATION info{};
    const void *p = reinterpret_cast<const void *>(static_cast<uintptr_t>(address));
    if (!p || VirtualQuery(p, &info, sizeof info) != sizeof info || info.State != MEM_COMMIT ||
        (info.Protect & (PAGE_NOACCESS | PAGE_GUARD))) return false;
    const uintptr_t start = reinterpret_cast<uintptr_t>(p);
    const uintptr_t end = reinterpret_cast<uintptr_t>(info.BaseAddress) + info.RegionSize;
    if (start > end || sizeof value > end - start) return false;
    value = *static_cast<const uint32_t *>(p);
    return true;
}

void reload_weapon_rates()
{
    const DWORD now = GetTickCount();
    if (now - g_weapon_rate_checked < 1000) return;
    g_weapon_rate_checked = now;
    if (!g_weapon_rate_ini[0]) {
        GetModuleFileNameW(nullptr, g_weapon_rate_ini, MAX_PATH);
        wchar_t *slash = wcsrchr(g_weapon_rate_ini, L'\\');
        if (slash) wcscpy_s(slash + 1, MAX_PATH - (slash + 1 - g_weapon_rate_ini), L"weapon_tuning.ini");
    }
    WIN32_FILE_ATTRIBUTE_DATA attrs{};
    FILETIME stamp{};
    if (GetFileAttributesExW(g_weapon_rate_ini, GetFileExInfoStandard, &attrs)) stamp = attrs.ftLastWriteTime;
    if (g_weapon_rate_loaded && CompareFileTime(&stamp, &g_weapon_rate_stamp) == 0) return;
    g_weapon_rate_loaded = true;
    g_weapon_rate_stamp = stamp;
    g_weapon_rate_multiplier.fill(1.0f);
    g_weapon_damage_multiplier.fill(1.0f);
    for (int id = 0; id < (int)g_weapon_rate_multiplier.size(); ++id) {
        wchar_t section[32], text[64]{};
        swprintf_s(section, L"weapon_%02d", id);
        wchar_t *end = nullptr;
        if (GetPrivateProfileStringW(section, L"rate_multiplier", L"", text, (DWORD)std::size(text), g_weapon_rate_ini)) {
            const float value = wcstof(text, &end);
            if (end != text && std::isfinite(value)) g_weapon_rate_multiplier[id] = std::clamp(value, 0.1f, 10.0f);
        }
        text[0] = L'\0';
        end = nullptr;
        if (GetPrivateProfileStringW(section, L"damage_multiplier", L"", text, (DWORD)std::size(text), g_weapon_rate_ini)) {
            const float damage = wcstof(text, &end);
            if (end != text && std::isfinite(damage)) g_weapon_damage_multiplier[id] = std::clamp(damage, 0.0f, 100.0f);
        }
    }
}

int player_weapon_id_for_user(uint32_t weapon_user)
{
    uint32_t player = 0, slots = 0, slot_weapon = 0, user_definition = 0, user_head = 0;
    if (!weapon_user || !read_u32(0x002D45D4, player) || !player || !read_u32(player + 0x2C8, slots) || !slots ||
        !read_u32(weapon_user + 0xEC, user_definition) || !user_definition || !read_u32(weapon_user, user_head)) return -1;
    const int user_id = (int)(user_head & 0xFF);
    if (user_id < 0 || user_id >= (int)g_weapon_rate_multiplier.size()) return -1;
    bool is_player_weapon = false;
    for (int slot = 0; slot < 2; ++slot) {
        if (read_u32(slots + slot * 4, slot_weapon) && slot_weapon == weapon_user) {
            is_player_weapon = true;
            break;
        }
    }
    if (!is_player_weapon) return -1; // avoids scaling NPCs that share the global definition
    reload_weapon_rates();
    return user_id;
}

float player_weapon_rate_multiplier(uint32_t weapon_user, int &weapon_id)
{
    weapon_id = player_weapon_id_for_user(weapon_user);
    return weapon_id >= 0 ? g_weapon_rate_multiplier[weapon_id] : 1.0f;
}

extern "C" uint32_t __cdecl scale_player_weapon_damage(uint32_t bits, uint32_t source_context)
{
    float damage;
    memcpy(&damage, &bits, sizeof damage);
    uint32_t weapon_user = 0;
    int weapon_id = -1;
    if (read_u32(source_context + 4, weapon_user) && weapon_user)
        weapon_id = player_weapon_id_for_user(weapon_user);
    if (weapon_id >= 0) {
        const float multiplier = g_weapon_damage_multiplier[weapon_id];
        if (damage > 0.0f && multiplier >= 0.0f) damage *= multiplier;
        if (!g_weapon_damage_logged[weapon_id]) {
            g_weapon_damage_logged[weapon_id] = true;
            logf("[weapon-damage] player weapon ID %d multiplier %.2f", weapon_id, multiplier);
        }
    }
    memcpy(&bits, &damage, sizeof bits);
    return bits;
}
} // namespace

extern "C" uint32_t __cdecl refire_interval(uint32_t bits, uint32_t weapon_user)
{
    float t;
    memcpy(&t, &bits, 4);
    const float original = t;
    int weapon_id = -1;
    const float multiplier = player_weapon_rate_multiplier(weapon_user, weapon_id);
    if (t > 0.0f && multiplier > 0.0f) t /= multiplier;
    if (g_refire_30fps_rounding && t > 0.0f)
        t = ceilf(t * 30.0f - 1e-3f) / 30.0f - 0.0005f;
    if (weapon_id >= 0 && !g_weapon_rate_logged[weapon_id]) {
        g_weapon_rate_logged[weapon_id] = true;
        logf("[weapon-rate] weapon ID %d: game interval %.4f s (%.2f/s); multiplier %.2f; frame interval %.4f s (%.2f/s)",
             weapon_id, original, original > 0.f ? 1.f / original : 0.f, multiplier, t, t > 0.f ? 1.f / t : 0.f);
    }
    memcpy(&bits, &t, 4);
    return bits;
}

#define REFIRE_THUNK(name, reg)                                                                                    \
    __declspec(naked) void name()                                                                                  \
    {                                                                                                              \
        __asm pushad                                                                                               \
        __asm push ebp                                                                                             \
        __asm push reg                                                                                             \
        __asm call refire_interval                                                                                 \
        __asm add esp, 8                                                                                           \
        __asm mov dword ptr [ebp + 0xDC], eax                                                                      \
        __asm popad                                                                                                \
        __asm ret                                                                                                  \
    }
REFIRE_THUNK(refire_edx, edx)
REFIRE_THUNK(refire_ecx, ecx)
REFIRE_THUNK(refire_eax, eax)

// The game computes the incoming hit strength in XMM1 at 0x1D8AA8. This thunk scales it only when the
// impact source belongs to the player's currently held weapon; enemy and environmental damage pass through.
__declspec(naked) void weapon_damage_thunk()
{
    __asm pushfd
    __asm pushad
    __asm sub esp, 080h
    __asm movdqu xmmword ptr [esp + 00h], xmm0
    __asm movdqu xmmword ptr [esp + 10h], xmm2
    __asm movdqu xmmword ptr [esp + 20h], xmm3
    __asm movdqu xmmword ptr [esp + 30h], xmm4
    __asm movdqu xmmword ptr [esp + 40h], xmm5
    __asm movdqu xmmword ptr [esp + 50h], xmm6
    __asm movdqu xmmword ptr [esp + 60h], xmm7
    __asm movd eax, xmm1
    __asm push edi
    __asm push eax
    __asm call scale_player_weapon_damage
    __asm add esp, 8
    __asm movd xmm1, eax
    __asm movdqu xmm0, xmmword ptr [esp + 00h]
    __asm movdqu xmm2, xmmword ptr [esp + 10h]
    __asm movdqu xmm3, xmmword ptr [esp + 20h]
    __asm movdqu xmm4, xmmword ptr [esp + 30h]
    __asm movdqu xmm5, xmmword ptr [esp + 40h]
    __asm movdqu xmm6, xmmword ptr [esp + 50h]
    __asm movdqu xmm7, xmmword ptr [esp + 60h]
    __asm add esp, 080h
    __asm popad
    __asm popfd
    // The CALL that entered this thunk left its return address at [esp], so the original [esp+8]
    // destination is now [esp+0x0c] until RET consumes that address.
    __asm movss dword ptr [esp + 0Ch], xmm1
    __asm ret
}

bool install_refire_patches()
{
    struct Site {
        uint32_t addr;
        uint8_t expect[6]; // mov [ebp+0DCh], reg
        void (*thunk)();
    } sites[] = {
        {0x001EFC72, {0x89, 0x95, 0xDC, 0x00, 0x00, 0x00}, refire_edx}, // interval from the fire mode (+0xCC)
        {0x001EFC94, {0x89, 0x8D, 0xDC, 0x00, 0x00, 0x00}, refire_ecx}, // interval (+0x20), main fire path
        {0x001EFCA6, {0x89, 0x85, 0xDC, 0x00, 0x00, 0x00}, refire_eax}, // interval (+0x20), first shot
        {0x001EFEF3, {0x89, 0x8D, 0xDC, 0x00, 0x00, 0x00}, refire_ecx}, // interval (+0x20), other fire path
    };
    for (const Site &s : sites)
        if (memcmp((const void *)(uintptr_t)s.addr, s.expect, 6)) {
            logf("timing: weapon refire site 0x%08x does not match this build", s.addr);
            return false;
        }
    for (const Site &s : sites) { // call thunk; nop (the 6-byte store it replaces)
        auto *code = (uint8_t *)(uintptr_t)s.addr;
        code[0] = 0xE8;
        int32_t rel = (int32_t)((uintptr_t)s.thunk - (s.addr + 5));
        memcpy(code + 1, &rel, 4);
        code[5] = 0x90;
    }
    return true;
}

bool install_weapon_rate_patches()
{
    const bool refire = install_refire_patches();
    auto *damage = (uint8_t *)(uintptr_t)0x001D8AA8;
    const uint8_t expected[6] = {0xF3, 0x0F, 0x11, 0x4C, 0x24, 0x08}; // movss [esp+8],xmm1 (computed hit strength)
    bool damage_ok = false;
    if (!memcmp(damage, expected, sizeof expected)) {
        damage[0] = 0xE8;
        int32_t rel = (int32_t)((uintptr_t)&weapon_damage_thunk - (0x001D8AA8 + 5));
        memcpy(damage + 1, &rel, sizeof rel);
        damage[5] = 0x90;
        damage_ok = true;
    } else {
        logf("weapon damage: hit-strength site 0x001d8aa8 does not match this build; damage multiplier unavailable");
    }
    if (refire) logf("weapon rate: per-weapon INI tuning active (weapon_tuning.ini)");
    if (damage_ok) logf("weapon damage: per-weapon INI multiplier active (player weapon hits)");
    return refire;
}

bool install_60fps_patches()
{
    uint32_t frame = (uint32_t)(uintptr_t)&g_frame_60;
    const Operand ops[] = {
        {0x0020C2A4, {0xF3, 0x0F, 0x10, 0x05, 0xC0, 0x5F}, 0x0020C2A8, 0x00295FC0}, // movss xmm0, [1/30] (NTSC frame time)
        {0x0020C2AC, {0xC7, 0x05, 0x00, 0x38, 0x2F, 0x00}, 0x0020C2B2, 0x21},       // mov [0x2F3800], 33 (ms per frame)
        {0x00193EAE, {0xF3, 0x0F, 0x59, 0x05, 0xC0, 0x5F}, 0x00193EB2, 0x00295FC0}, // mulss xmm0, [1/30]
        {0x00212210, {0xF3, 0x0F, 0x10, 0x05, 0xC0, 0x5F}, 0x00212214, 0x00295FC0}, // movss xmm0, [1/30] -> 0x2F57F4
    };
    for (const Operand &o : ops)
        if (memcmp((const void *)(uintptr_t)o.insn, o.expect, 6) || *(uint32_t *)(uintptr_t)o.at != o.old_value) {
            logf("timing: 60 fps patch site 0x%08x does not match this build; staying at 30 fps", o.insn);
            return false;
        }
    for (const Operand &o : ops) *(uint32_t *)(uintptr_t)o.at = o.old_value == 0x21 ? 16u : frame;
    g_refire_30fps_rounding = true;
    // Reload blur (the post-process controller at *0x2D1990 + 0x830A0, mode 1): its hold time is set at
    // 0x17B314 to reload-animation length [anim+0x1C] (in 30 fps animation frames) * frame time (game
    // +0x2013C, = 1/60 now) * 0.5 - c, so it halved at 60 fps and the blur cleared early. Use 1/30 there.
    static const uint8_t blur_expect[8] = {0xF3, 0x0F, 0x59, 0x82, 0x3C, 0x01, 0x02, 0x00}; // mulss xmm0, [edx+0x2013C]
    auto *blur = (uint8_t *)(uintptr_t)0x0017B314;
    if (!memcmp(blur, blur_expect, 8)) {
        blur[3] = 0x05; // mulss xmm0, [disp32]
        uint32_t a = (uint32_t)(uintptr_t)&g_frame_30;
        memcpy(blur + 4, &a, 4);
    } else {
        logf("timing: reload blur site 0x0017B314 does not match this build");
    }
    logf("timing: world steps 1/60 s per frame (60 fps); weapon refire keeps the 30 fps rhythm");
    return true;
}

void install_timing_patches()
{
    const Patch patches[] = {
        {0x000232DA, {0x8B, 0x4C, 0x24, 0x04, 0x0F, 0x31}, 6, (const void *)&xapi_QueryPerformanceCounter, "QueryPerformanceCounter"},
        {0x00084190, {0x53, 0x0F, 0x31}, 3, (const void *)&store_tsc_thunk, "timer helper (store rdtsc)"},
        {0x000841A0, {0x83, 0xEC, 0x08, 0x53, 0x0F, 0x31}, 6, (const void *)&tsc_low_thunk, "timer helper (rdtsc low)"},
    };
    int n = 0;
    for (const Patch &p : patches) n += patch(p);
    logf("timing: %d of %zu rdtsc users now tick at 733.33 MHz (host QPC based)", n, sizeof patches / sizeof patches[0]);
}
