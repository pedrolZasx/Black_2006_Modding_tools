#include "rain.h"

#include "common.h"
#include "d3d/host.h"
#include "audio/output.h"
#include "input/bindings.h"
#include "ui/sfx.h"

#include <windows.h>

#include <algorithm>
#include <chrono>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <random>
#include <string>
#include <vector>

namespace rain {
namespace {

// ---- settings (rain.ini) -------------------------------------------------------------------------------------------
struct Range {
    float lo = 0, hi = 0;
    Range() = default;
    Range(float a, float b) : lo(a), hi(b) {}
};

struct Zone { // "indoor" box in world coordinates: the rain fades out while the camera is inside
    int level = -1; // -1 = every level
    float lo[3] = {0, 0, 0}, hi[3] = {0, 0, 0};
};

struct Settings {
    bool enabled = true;
    std::vector<int> levels;      // empty = every level
    float intensity = 1.0f;       // master brightness of the rain
    int count = 2200;             // drops simulated and drawn (all of them are inside the box around the player)
    float radius = 12.0f;         // metres: half size of the box in x and z
    float below = 5.0f, above = 9.0f; // metres of the box under / over the camera
    Range speed{9.5f, 12.5f};     // m/s
    Range length{0.45f, 0.85f};   // metres per streak
    Range alpha{0.28f, 0.55f};    // brightness of a drop
    float wind[2] = {3.5f, 1.5f}; // mean m/s in world x and z
    float wind_variation = 2.0f;  // per-drop random sideways wind (m/s)
    float blend_chance = 100.0f; // % of the drops blended with the background
    Range blend_amount{0.20f, 0.78f}; // how much a drop takes the background colour (0..1)
    Range blend_alpha{0.35f, 0.75f}; // how much weaker such a drop is
    float width = 1.3f;           // streak width, pixels of a 480-line picture
    float color[3] = {0.78f, 0.84f, 0.95f};
    float near_fade = 1.0f;       // metres: drops closer than this fade out (no giant streaks in front of the lens)
    float amb_min = 0.30f, amb_gain = 0.90f; // streak brightness = amb_min + amb_gain * brightness behind it
    float fade_in = 1.5f, fade_out = 0.6f;   // seconds
    bool sound = true;
    std::string sound_file = "rain.wav"; // looped ambience, relative to black.exe or absolute
    float sound_volume = 0.80f;
    std::vector<Zone> zones;
};

Settings g_s;
bool g_loaded;
std::wstring g_ini_path;
std::vector<float> g_rain_sound;
uint32_t g_next_sound_check;
std::wstring g_last_missing_sound_path;

bool two(const char *v, Range &r)
{
    float a = 0, b = 0;
    int n = sscanf(v, "%f %f", &a, &b);
    if (n < 1) return false;
    r = Range(a, n >= 2 ? b : a);
    return true;
}

void write_default_ini(const std::wstring &path)
{
    FILE *f = _wfopen(path.c_str(), L"w");
    if (!f) return;
    fputs(
        "# 3D rain around the player for the BLACK port. Saved changes apply within a second, while the game runs.\n"
        "# F7 = rain on / off.  F6 = write the camera position to black.log (to make `indoor` boxes, see below).\n"
        "# Every drop follows a fixed trajectory in WORLD space. Camera position is used only to cull drops outside\n"
        "# the local view box, so walking does not drag the rain along: you pass through it.\n"
        "# Each drop has a stable random wind variation, so nearby drops do not all lean the same way.\n"
        "# Only the drops inside a box around the camera are worked out and\n"
        "# drawn, so it costs the same everywhere. Drops are hidden by walls, props and the gun.\n"
        "# Two numbers = a range (min max): every drop picks a random value in it.\n"
        "\n"
        "[general]\n"
        "enabled = 1            # 0 = no rain at all\n"
        "levels = all           # all, or only these levels, e.g. levels = 1 3 5 (level_01, level_03, level_05)\n"
        "intensity = 1.0        # master brightness of the rain (0 = invisible, 2 = very strong)\n"
        "fade_in = 1.5          # seconds the rain takes to fade in (level start, leaving an indoor box)\n"
        "fade_out = 0.6         # seconds the rain takes to fade out (pause / cutscene / entering an indoor box)\n"
        "sound = 1              # loop the rain ambience while rain is active in a mission\n"
        "sound_file = rain.wav  # WAV next to black.exe, or a relative path such as rain\\rain.wav\n"
        "sound_volume = 0.80    # 0..4\n"
        "\n"
        "[box around the player]\n"
        "count = 2200           # number of drops (more = denser rain, a bit slower). 1000 light, 4000 heavy\n"
        "radius = 12            # metres: half size of the box in x and z. Smaller = cheaper, rain ends closer\n"
        "below = 5              # metres of the box under the camera\n"
        "above = 9              # metres of the box over the camera\n"
        "\n"
        "[drops]\n"
        "speed = 9.5 12.5       # m/s fall speed\n"
        "length = 0.45 0.85     # metres, length of a streak\n"
        "alpha = 0.28 0.55      # how visible a drop is\n"
        "wind = 3.5 1.5         # mean m/s sideways push in world x and z\n"
        "wind_variation = 2.0   # per-drop random sideways wind in m/s; 0 = same direction for every drop\n"
        "blend_chance = 100    # percent of drops that blend with the scene behind them\n"
        "blend_amount = 0.20 0.78 # 0 = rain colour, 1 = background colour\n"
        "blend_alpha = 0.35 0.75 # a blended drop is this much of its normal strength\n"
        "width = 1.3            # streak width in pixels of a 480-line picture (scales with the render resolution)\n"
        "color = 0.78 0.84 0.95 # rain colour (r g b)\n"
        "near_fade = 1.0        # metres: drops closer than this fade out\n"
        "amb_min = 0.30         # streak brightness = amb_min + amb_gain * brightness of the picture behind the streak,\n"
        "amb_gain = 0.90        #   so the rain is dim in dark rooms and bright over a bright sky\n"
        "\n"
        "[indoor boxes]\n"
        "# The rain cannot know a ceiling is over you, so name the places where it must not fall. While the camera is\n"
        "# inside a box the rain fades out. Press F6 where you stand to write the position to black.log, then add\n"
        "# two opposite corners of a box around the room:\n"
        "#   indoor = LEVEL x1 y1 z1 x2 y2 z2        (LEVEL = the level number, or -1 for any level)\n"
        "# Example: indoor = 3  -12 -2 40  8 6 62\n",
        f);
    fclose(f);
}

Settings parse_ini(const std::wstring &path, bool &ok)
{
    Settings s;
    const wchar_t *base = path.c_str() + path.find_last_of(L"/\\") + 1;
    const bool weather_file = _wcsicmp(base, L"weather.ini") == 0;
    std::string section;
    FILE *f = _wfopen(path.c_str(), L"r");
    ok = f != nullptr;
    if (!f) return s;
    char line[512];
    while (fgets(line, sizeof line, f)) {
        if (char *h = strchr(line, '#')) *h = 0;
        char *section_start = line;
        while (*section_start == ' ' || *section_start == '\t') ++section_start;
        if (*section_start == '[') {
            char *end = strchr(section_start + 1, ']');
            if (end) {
                *end = 0;
                section = section_start + 1;
                for (char &ch : section) ch = (char)tolower((unsigned char)ch);
            }
            continue;
        }
        if (weather_file && section != "rain") continue;
        char *eq = strchr(line, '=');
        if (!eq) continue;
        *eq = 0;
        std::string key = line, val = eq + 1;
        auto trim = [](std::string &t) {
            size_t a = t.find_first_not_of(" \t\r\n"), b = t.find_last_not_of(" \t\r\n");
            t = a == std::string::npos ? std::string() : t.substr(a, b - a + 1);
        };
        trim(key);
        trim(val);
        if (key.empty()) continue;
        const char *v = val.c_str();
        float a = (float)atof(v), c[3] = {0, 0, 0};
        Range r;
        if (key == "enabled") s.enabled = a != 0;
        else if (key == "levels") {
            s.levels.clear();
            if (_stricmp(v, "all") && _stricmp(v, "-1"))
                for (const char *p = v; *p;) {
                    while (*p == ' ' || *p == ',' || *p == '\t') p++;
                    if (*p >= '0' && *p <= '9') s.levels.push_back(atoi(p));
                    while (*p && *p != ' ' && *p != ',' && *p != '\t') p++;
                }
        } else if (key == "intensity") s.intensity = std::clamp(a, 0.0f, 4.0f);
        else if (key == "fade_in") s.fade_in = std::clamp(a, 0.05f, 30.0f);
        else if (key == "fade_out") s.fade_out = std::clamp(a, 0.05f, 30.0f);
        else if (key == "sound") s.sound = a != 0;
        else if (key == "sound_file") s.sound_file = val;
        else if (key == "sound_volume") s.sound_volume = std::clamp(a, 0.0f, 4.0f);
        else if (key == "count") s.count = std::clamp((int)a, 0, 20000);
        else if (key == "radius") s.radius = std::clamp(a, 3.0f, 60.0f);
        else if (key == "below") s.below = std::clamp(a, 1.0f, 40.0f);
        else if (key == "above") s.above = std::clamp(a, 1.0f, 60.0f);
        else if (key == "speed" && two(v, r)) s.speed = Range(std::clamp(r.lo, 1.0f, 60.0f), std::clamp(r.hi, 1.0f, 60.0f));
        else if (key == "length" && two(v, r)) s.length = Range(std::clamp(r.lo, 0.05f, 6.0f), std::clamp(r.hi, 0.05f, 6.0f));
        else if (key == "alpha" && two(v, r)) s.alpha = Range(std::clamp(r.lo, 0.0f, 1.0f), std::clamp(r.hi, 0.0f, 1.0f));
        else if (key == "wind") {
            if (sscanf(v, "%f %f", &c[0], &c[1]) == 2) {
                s.wind[0] = std::clamp(c[0], -30.0f, 30.0f);
                s.wind[1] = std::clamp(c[1], -30.0f, 30.0f);
            }
        } else if (key == "wind_variation") s.wind_variation = std::clamp(a, 0.0f, 10.0f);
        else if (key == "blend_chance") s.blend_chance = std::clamp(a, 0.0f, 100.0f);
        else if (key == "blend_amount" && two(v, r))
            s.blend_amount = Range(std::clamp(r.lo, 0.0f, 1.0f), std::clamp(r.hi, 0.0f, 1.0f));
        else if (key == "blend_alpha" && two(v, r))
            s.blend_alpha = Range(std::clamp(r.lo, 0.0f, 1.0f), std::clamp(r.hi, 0.0f, 1.0f));
        else if (key == "width") s.width = std::clamp(a, 0.3f, 8.0f);
        else if (key == "color") {
            if (sscanf(v, "%f %f %f", &c[0], &c[1], &c[2]) == 3) std::copy(c, c + 3, s.color);
        } else if (key == "near_fade") s.near_fade = std::clamp(a, 0.2f, 10.0f);
        else if (key == "amb_min") s.amb_min = std::clamp(a, 0.0f, 2.0f);
        else if (key == "amb_gain") s.amb_gain = std::clamp(a, 0.0f, 4.0f);
        else if (key == "indoor") {
            float z[7];
            if (sscanf(v, "%f %f %f %f %f %f %f", &z[0], &z[1], &z[2], &z[3], &z[4], &z[5], &z[6]) == 7) {
                Zone zn;
                zn.level = (int)z[0];
                for (int i = 0; i < 3; i++) {
                    zn.lo[i] = std::min(z[1 + i], z[4 + i]);
                    zn.hi[i] = std::max(z[1 + i], z[4 + i]);
                }
                if (s.zones.size() < 256) s.zones.push_back(zn);
            }
        }
    }
    fclose(f);
    return s;
}

void refresh_settings()
{
    static FILETIME stamp;
    static uint32_t next_check;
    const std::wstring weather_path = g_cfg.port_dir + L"\\weather.ini";
    const std::wstring legacy_path = g_cfg.port_dir + L"\\rain.ini";
    if (g_ini_path.empty()) {
        // Prefer the shared weather.ini when it contains a [rain] section. Keep accepting an older rain.ini
        // for users who already customized that separate file.
        bool has_rain_section = false;
        FILE *weather_file = _wfopen(weather_path.c_str(), L"r");
        if (weather_file) {
            char line[256];
            while (fgets(line, sizeof line, weather_file)) {
                char *p = line;
                while (*p == ' ' || *p == '\t') ++p;
                if (_strnicmp(p, "[rain]", 6) == 0) { has_rain_section = true; break; }
            }
            fclose(weather_file);
        }
        g_ini_path = has_rain_section || GetFileAttributesW(legacy_path.c_str()) == INVALID_FILE_ATTRIBUTES
                         ? weather_path : legacy_path;
    }
    uint32_t fr = g_frame_count.load();
    if (g_loaded && fr < next_check) return;
    next_check = fr + 30;
    if (g_ini_path == weather_path && GetFileAttributesW(legacy_path.c_str()) == INVALID_FILE_ATTRIBUTES) {
        bool has_rain_section = false;
        FILE *weather_file = _wfopen(weather_path.c_str(), L"r");
        if (weather_file) {
            char line[256];
            while (fgets(line, sizeof line, weather_file)) {
                char *p = line;
                while (*p == ' ' || *p == '\t') ++p;
                if (_strnicmp(p, "[rain]", 6) == 0) { has_rain_section = true; break; }
            }
            fclose(weather_file);
        }
        if (!has_rain_section && weather_file == nullptr) { /* weather pass creates it later in this frame */ }
        else if (!has_rain_section) {
            FILE *append = _wfopen(weather_path.c_str(), L"a");
            if (append) {
                fputs("\n[rain]\nenabled = 1\ncount = 2200\nradius = 12\nbelow = 5\nabove = 9\n"
                      "speed = 9.5 12.5\nlength = 0.45 0.85\nalpha = 0.28 0.55\nwind = 3.5 1.5\n"
                      "wind_variation = 2.0\nblend_chance = 100\nblend_amount = 0.20 0.78\n"
                      "blend_alpha = 0.35 0.75\nwidth = 1.3\ncolor = 0.78 0.84 0.95\n"
                      "near_fade = 1.0\namb_min = 0.30\namb_gain = 0.90\n", append);
                fclose(append);
            }
        }
    }
    WIN32_FILE_ATTRIBUTE_DATA a;
    if (!GetFileAttributesExW(g_ini_path.c_str(), GetFileExInfoStandard, &a)) {
        g_loaded = true; // weather pass creates weather.ini if needed; use built-in rain defaults meanwhile
        return;
    }
    if (g_loaded && !CompareFileTime(&a.ftLastWriteTime, &stamp)) return;
    stamp = a.ftLastWriteTime;
    bool ok = false;
    Settings s = parse_ini(g_ini_path, ok);
    if (!ok) return;
    g_s = s;
    g_loaded = true;
    logf("[rain] settings from %ls: %s, %d drops in a %.0f m box (%.0f under / %.0f over), wind %.1f %.1f +/- %.1f, %u indoor boxes", g_ini_path.c_str(), g_s.enabled ? "on" : "off",
         g_s.count, g_s.radius * 2.0f, g_s.below, g_s.above, g_s.wind[0], g_s.wind[1], g_s.wind_variation, (unsigned)g_s.zones.size());
}

void refresh_rain_sound()
{
    if (!g_rain_sound.empty() || !g_s.sound || g_s.sound_file.empty()) return;
    const uint32_t frame = g_frame_count.load();
    if (frame < g_next_sound_check) return;
    g_next_sound_check = frame + 120;
    int n = MultiByteToWideChar(CP_ACP, 0, g_s.sound_file.c_str(), -1, nullptr, 0);
    if (n <= 1 || n > MAX_PATH) return;
    std::wstring file((size_t)n, L'\0');
    MultiByteToWideChar(CP_ACP, 0, g_s.sound_file.c_str(), -1, &file[0], n);
    file.pop_back();
    const bool absolute = (file.size() > 1 && file[1] == L':') || (!file.empty() && (file[0] == L'\\' || file[0] == L'/'));
    const std::wstring path = absolute ? file : g_cfg.port_dir + L"\\" + file;
    FILE *f = _wfopen(path.c_str(), L"rb");
    if (!f) {
        if (_wcsicmp(path.c_str(), g_last_missing_sound_path.c_str()) != 0) {
            g_last_missing_sound_path = path;
            logf("[rain] sound file not found: %ls (expected next to black.exe or under its folder)", path.c_str());
        }
        return; // allow the user to add the WAV while the game is running
    }
    g_last_missing_sound_path.clear();
    fseek(f, 0, SEEK_END);
    long size = ftell(f);
    fseek(f, 0, SEEK_SET);
    bool ok = size >= 44 && size <= 90 * 1024 * 1024;
    std::vector<uint8_t> bytes;
    if (ok) {
        bytes.resize((size_t)size);
        ok = fread(bytes.data(), 1, bytes.size(), f) == bytes.size();
    }
    fclose(f);
    if (ok) {
        try { ok = sfx::decode_wav(bytes.data(), bytes.size(), g_rain_sound, 1.0f); }
        catch (...) { ok = false; }
    }
    if (ok) logf("[rain] loop sound loaded: %ls (%.1f s)", path.c_str(), (double)(g_rain_sound.size() / 2) / audio_out::RATE);
    else logf("[rain] loop sound %ls failed to load (max 90 MB; use 16-bit PCM or 32-bit float, mono or stereo)", path.c_str());
}

// ---- camera --------------------------------------------------------------------------------------------------------
// The renderer (*0x2D12B8) keeps the camera as a quaternion x y z w at +0x760 and the position at +0x770 (see
// input/freecam.cpp, FUN_002033A0); its field of view in degrees is at +0x750 (fov.cpp). Y is up, the quaternion
// matrix is row-vector style: its rows are the camera's right, up and forward in the world.
bool readable(const void *address, size_t bytes)
{
    if (!address || bytes == 0) return false;
    MEMORY_BASIC_INFORMATION info{};
    if (VirtualQuery(address, &info, sizeof info) != sizeof info || info.State != MEM_COMMIT || (info.Protect & (PAGE_NOACCESS | PAGE_GUARD)))
        return false;
    const uintptr_t start = reinterpret_cast<uintptr_t>(address);
    const uintptr_t region_end = reinterpret_cast<uintptr_t>(info.BaseAddress) + info.RegionSize;
    return start <= region_end && bytes <= region_end - start;
}

bool finite3(const float *v) { return std::isfinite(v[0]) && std::isfinite(v[1]) && std::isfinite(v[2]); }

bool read_camera(Frame &f)
{
    const uint32_t *slot = (const uint32_t *)(uintptr_t)0x002D12B8;
    if (!readable(slot, 4)) return false;
    uint32_t r = *slot;
    if (r < 0x10000) return false;
    const uint8_t *base = (const uint8_t *)(uintptr_t)r;
    if (!readable(base + 0x740, 0x80)) return false; // through +0x7BC (aspect)
    float q[4];
    float p[3];
    memcpy(q, base + 0x760, sizeof q);
    memcpy(p, base + 0x770, sizeof p);
    float fov = *(const float *)(base + 0x750);
    if (!finite3(p) || !finite3(q) || !std::isfinite(q[3])) return false;
    if (std::fabs(p[0]) > 100000.0f || std::fabs(p[1]) > 100000.0f || std::fabs(p[2]) > 100000.0f) return false;
    float n = std::sqrt(q[0] * q[0] + q[1] * q[1] + q[2] * q[2] + q[3] * q[3]);
    if (n < 0.5f || n > 1.5f) return false; // not a rotation: the pointer is not the camera (yet)
    for (float &c : q) c /= n;
    const float x = q[0], y = q[1], z = q[2], w = q[3];
    f.right[0] = 1.0f - 2.0f * (y * y + z * z);
    f.right[1] = 2.0f * (x * y + w * z);
    f.right[2] = 2.0f * (x * z - w * y);
    f.up[0] = 2.0f * (x * y - w * z);
    f.up[1] = 1.0f - 2.0f * (x * x + z * z);
    f.up[2] = 2.0f * (y * z + w * x);
    f.fwd[0] = 2.0f * (x * z + w * y);
    f.fwd[1] = 2.0f * (y * z - w * x);
    f.fwd[2] = 1.0f - 2.0f * (x * x + y * y);
    memcpy(f.cam, p, sizeof p);
    f.fov_deg = (std::isfinite(fov) && fov > 10.0f && fov < 150.0f) ? fov : 0.0f;
    // camera +0x70 = near plane, +0x74 = aspect (camera = renderer + 0x740, see fov.cpp)
    float nr = *(const float *)(base + 0x7B0), as = *(const float *)(base + 0x7B4);
    f.near_plane = (std::isfinite(nr) && nr > 0.01f && nr < 2.0f) ? nr : 0.0f;
    f.aspect = (std::isfinite(as) && as > 1.0f && as < 3.0f) ? as : 0.0f;
    return true;
}

// ---- the rain ------------------------------------------------------------------------------------------------------
// No drop is stored. Every drop belongs to a fixed cell of a grid laid over the WORLD and its position is a pure function
// of (cell, drop number, time): where it starts at the top of its fall, its speed, its phase, and how far the wind has
// carried it. Each frame only the cells around the camera are evaluated; walking therefore moves you through the rain
// instead of dragging it along. Vertically the fall is periodic (period = box height), so the lattice of drops repeats
// every `below + above` metres of height and a drop that reaches the bottom of its fall fades out and starts again.
uint32_t hash32(uint32_t x)
{
    x ^= x >> 16;
    x *= 0x7FEB352Du;
    x ^= x >> 15;
    x *= 0x846CA68Bu;
    x ^= x >> 16;
    return x;
}
float h01(int cx, int cy, int cz, int k, uint32_t salt)
{
    uint32_t h = hash32((uint32_t)cx * 73856093u ^ (uint32_t)cy * 83492791u ^
                        (uint32_t)cz * 19349663u ^ (uint32_t)k * 2654435761u ^ (salt + 1u) * 2246822519u);
    return (float)((h >> 8) & 0xFFFFFF) / 16777216.0f;
}
float lerpf(const Range &r, float t) { return r.lo + (r.hi - r.lo) * t; }

std::vector<Drop> g_drops;
double g_time;      // seconds of rain time (advances while the rain is drawn)
int g_level_seen = -2;
float g_inten;      // 0..1 fade
bool g_on = true;   // F7
std::chrono::steady_clock::time_point g_last_t;
bool g_have_t;

bool level_allowed()
{
    int lv = g_current_level.load();
    if (lv < 0) return false; // no level opened yet: still in the menus / intro
    if (g_s.levels.empty()) return true;
    return std::find(g_s.levels.begin(), g_s.levels.end(), lv) != g_s.levels.end();
}

bool in_indoor_box(const float *p)
{
    int lv = g_current_level.load();
    for (const Zone &z : g_s.zones) {
        if (z.level >= 0 && z.level != lv) continue;
        if (p[0] >= z.lo[0] && p[0] <= z.hi[0] && p[1] >= z.lo[1] && p[1] <= z.hi[1] && p[2] >= z.lo[2] && p[2] <= z.hi[2]) return true;
    }
    return false;
}

void keys(const float *cam, bool cam_ok)
{
    static bool prev7, prev6;
    bool focus = host3d::window() && GetForegroundWindow() == host3d::window();
    bool k7 = focus && (GetAsyncKeyState(VK_F7) & 0x8000);
    bool k6 = focus && (GetAsyncKeyState(VK_F6) & 0x8000);
    if (k7 && !prev7) {
        g_on = !g_on;
        logf("[rain] %s", g_on ? "on" : "off");
    }
    if (k6 && !prev6) {
        if (cam_ok) logf("[rain] camera at x %.2f  y %.2f  z %.2f  (level %d)", cam[0], cam[1], cam[2], g_current_level.load());
        else logf("[rain] camera position not available now");
    }
    prev7 = k7;
    prev6 = k6;
}

} // namespace

bool frame(Frame &out)
{
    refresh_settings();
    refresh_rain_sound();

    Frame cam{};
    bool cam_ok = read_camera(cam);
    keys(cam.cam, cam_ok);

    auto now = std::chrono::steady_clock::now();
    float dt = g_have_t ? std::chrono::duration<float>(now - g_last_t).count() : 0.0f;
    g_last_t = now;
    g_have_t = true;
    dt = std::clamp(dt, 0.0f, 0.1f);

    const bool in_game = bindings::in_play();
    sfx::radio_level_active(in_game);
    bool want = g_s.enabled && g_on && cam_ok && g_s.count > 0 && level_allowed() && in_game;
    if (want && in_indoor_box(cam.cam)) want = false;
    float target = want ? 1.0f : 0.0f;
    if (g_inten < target) g_inten = std::min(target, g_inten + dt / g_s.fade_in);
    else if (g_inten > target) g_inten = std::max(target, g_inten - dt / g_s.fade_out);
    if (g_inten <= 0.003f && !want) {
        g_inten = 0.0f;
        if (!g_rain_sound.empty()) audio_out::stop_sfx_loop(g_rain_sound.data());
        return false;
    }
    if (!g_rain_sound.empty()) {
        if (want && g_s.sound) audio_out::play_sfx_loop(g_rain_sound.data(), g_rain_sound.size() / 2, g_s.sound_volume * g_inten);
        else audio_out::stop_sfx_loop(g_rain_sound.data());
    }
    if (!cam_ok) return false;

    g_time += dt;
    (void)g_level_seen;

    // Evaluate the drops of the cells around the camera.
    const float R = g_s.radius, H = g_s.below + g_s.above;
    const float cs = 2.0f; // cell size, metres
    const float vmin = std::max(g_s.speed.lo, 1.0f);
    const float drift = std::min((std::sqrt(g_s.wind[0] * g_s.wind[0] + g_s.wind[1] * g_s.wind[1]) + g_s.wind_variation) * H / vmin, 24.0f);
    const int per_side = std::max(1, (int)std::ceil(2.0f * R / cs));
    const int K = std::max(1, (int)std::ceil((float)g_s.count / (float)(per_side * per_side))); // drops per cell
    const int cx0 = (int)std::floor((cam.cam[0] - R - drift) / cs), cx1 = (int)std::floor((cam.cam[0] + R + drift) / cs);
    const int cz0 = (int)std::floor((cam.cam[2] - R - drift) / cs), cz1 = (int)std::floor((cam.cam[2] + R + drift) / cs);
    // Vertical cells are fixed in world space too. Previously the rain's y origin was camera.y - below,
    // which made the entire rain volume rise and fall with the player. Evaluate a couple of world bands
    // around the camera instead; camera position affects only which bands are culled into view.
    const int cy0 = (int)std::floor((cam.cam[1] - g_s.below) / H) - 1;
    const int cy1 = (int)std::floor((cam.cam[1] + g_s.above) / H) + 1;
    const size_t cap = (size_t)g_s.count * 2 + 64;
    g_drops.clear();
    g_drops.reserve(cap);
    for (int cx = cx0; cx <= cx1 && g_drops.size() < cap; cx++)
        for (int cz = cz0; cz <= cz1 && g_drops.size() < cap; cz++)
            for (int cy = cy0; cy <= cy1 && g_drops.size() < cap; cy++)
            for (int k = 0; k < K && g_drops.size() < cap; k++) {
                float speed = lerpf(g_s.speed, h01(cx, cy, cz, k, 1));
                double ph = (double)h01(cx, cy, cz, k, 2) + g_time * (double)speed / (double)H;
                float phase = (float)(ph - std::floor(ph)); // 0 = top of the fall, 1 = bottom
                float tfall = phase * H / speed;
                const float theta = h01(cx, cy, cz, k, 11) * 6.28318530718f;
                const float gust = std::sqrt(h01(cx, cy, cz, k, 12)) * g_s.wind_variation;
                const float wx = g_s.wind[0] + std::cos(theta) * gust;
                const float wz = g_s.wind[1] + std::sin(theta) * gust;
                float x = (cx + h01(cx, cy, cz, k, 3)) * cs + wx * tfall;
                float z = (cz + h01(cx, cy, cz, k, 4)) * cs + wz * tfall;
                if (std::fabs(x - cam.cam[0]) > R || std::fabs(z - cam.cam[2]) > R) continue;
                float y = (float)cy * H + (1.0f - phase) * H; // world-space band, falling without camera-relative offset
                if (y < cam.cam[1] - g_s.below || y > cam.cam[1] + g_s.above) continue;
                float a = lerpf(g_s.alpha, h01(cx, cy, cz, k, 6));
                a *= std::min(1.0f, std::min(phase, 1.0f - phase) / 0.06f); // fade where the fall starts / ends
                float blend = 0.0f;
                if (h01(cx, cy, cz, k, 7) * 100.0f < g_s.blend_chance) {
                    blend = lerpf(g_s.blend_amount, h01(cx, cy, cz, k, 8));
                    a *= lerpf(g_s.blend_alpha, h01(cx, cy, cz, k, 9));
                }
                Drop d;
                d.p[0] = x;
                d.p[1] = y;
                d.p[2] = z;
                float dx = wx, dy = -speed, dz = wz, dl = std::sqrt(dx * dx + dy * dy + dz * dz);
                d.dir[0] = dx / dl;
                d.dir[1] = dy / dl;
                d.dir[2] = dz / dl;
                d.len = lerpf(g_s.length, h01(cx, cy, cz, k, 10));
                d.alpha = a;
                d.blend = blend;
                g_drops.push_back(d);
            }

    out = cam;
    out.radius = R;
    out.below = g_s.below;
    out.above = g_s.above;
    std::copy(g_s.color, g_s.color + 3, out.color);
    out.intensity = g_inten * g_s.intensity;
    out.width_px = g_s.width;
    out.near_fade = g_s.near_fade;
    out.amb_min = g_s.amb_min;
    out.amb_gain = g_s.amb_gain;
    out.drops = g_drops.data();
    out.count = (int)g_drops.size();
    return out.intensity > 0.002f;
}

} // namespace rain

namespace rain {
bool wind_xz(float out[2]) { out[0] = g_s.wind[0]; out[1] = g_s.wind[1]; return true; }
} // namespace rain
