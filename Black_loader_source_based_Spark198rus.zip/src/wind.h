// Wind for foliage (leaves, trees, grass): the vertex shaders of alpha-tested / blended world geometry get a small
// wind displacement added to their vertex position. Everything is set in wind.ini next to black.exe (written on first
// start, re-read while the game runs). Code: wind.cpp (settings + time animation), d3d/nv2a_vsh.cpp (the HLSL that
// moves the vertices), d3d/draw.cpp (per-draw constants c201..c204).
#pragma once

#include <cstdint>
#include <string>
#include <vector>

struct IDirect3DDevice9;

namespace wind {

// Compile-time options: the translated vertex shaders are built once, so these need a restart of the game.
struct CompileOpts {
    int uv_reg = 9;          // vertex input register holding texcoord 0 (NV2A v9)
    int color_reg = 3;       // vertex input register holding the diffuse colour (NV2A v3)
    int world_const = -1;    // >=0: first constant slot of an object->world matrix (translation in .w of 3 rows) -> per-instance phase
    bool object_space = false; // also move shaders whose v0 is NOT world space (direction then follows the object's rotation)
};

CompileOpts compile_opts();

// wind.ini [shaders]: shaders picked by hash (the log prints "[wind-scan] shader XXXXXXXX ..."). Read when the shader is compiled.
// Returns 0 = decide by draw state, 1 = always foliage, 2 = always light ray, 3 = always grass, -1 = never touch this shader.
int forced_class(uint32_t shader_hash);

// Class 1 = foliage (alpha-tested: leaves, bushes, trees), 2 = light ray (alpha-blended cards), 3 = grass (forced by hash only). `forced` from forced_class().
// Fills k[20] = c201..c205 for the current draw. False: wind stays off for this draw.
bool draw_constants(bool alpha_test, bool alpha_blend, bool first_person, int forced, int *cls_out, float k[20]);

// Density ([density] tree / lightray / grass = N): total copies of every draw of that class (1 = off). offset(): shift of copy i (1..N-1).
// Classes: 1 = tree / foliage (alpha-tested), 2 = light ray (alpha-blended cards), 3 = grass (shaders listed in wind.ini [shaders] grass=).
int copies(int cls);
int snap_budget(); // [density] snap_budget: vertices per frame that may be ground-snapped (0 = unlimited)
int copy_cap();    // [density] copy_cap: extra vertices per frame over all copies (0 = unlimited)
void offset(int cls, int copy, uint32_t patch_hash, float out[4]);
// [grass] sway_const=SLOT SCALE: multiplies a vertex constant for grass draws (to tame / boost the game's own grass sway).
void grass_sway_constants(IDirect3DDevice9 *d, const float *all_constants /* 192 x float4 */);

// Ground snapping for density copies: draws of the shaders listed in wind.ini [shaders] ground= are collected as triangles (world space, kept for the
// level); a copy of a grass / bush draw is moved sideways per vertex and then up or down by the ground height difference.
bool is_ground(uint32_t shader_hash);
bool ground_wanted();                      // ground list set, snap_to_ground=1 and some density > 1
bool ground_seen_draw(uint64_t signature); // true if this draw was ingested already (else remembers it)
void ground_add_tri(const float *a, const float *b, const float *c);
bool ground_height(float x, float z, float y_ref, float *out); // height of the ground triangle nearest to y_ref under (x, z)

// F12 (after F11) walks through the scanned shaders and makes one blink on screen: how you find which shader draws the grass.
bool blink_hides(uint32_t shader_hash);

// F11 = log, over the next 2 seconds, every vertex shader that draws, with draw counts and alpha state ("[wind-scan] draws ...").
void scan_note(uint32_t shader_hash, uint32_t insts, int cls, bool alpha_test, bool alpha_blend, bool has_wind_code);
bool scan_overlay_text(std::vector<std::string> &lines);
bool scan_overlay_active();

// F10: toggle wind on / off while playing.
void toggle();

} // namespace wind
