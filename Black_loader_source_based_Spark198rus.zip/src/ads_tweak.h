// Live first-person ADS joint offsets shared with black_ads_tweak.exe.
#pragma once

#include <windows.h>
#include <cstdint>

// The skinning shader starts its indexed 3-row bone matrices at c60. Xbox vertex
// programs expose constants through c191, so the model can address up to 44 joints.
constexpr int kAdsJointCount = 44;
constexpr int kAdsWeaponCount = 17; // BLACK weapon IDs 0-16, also used by the armory model table
constexpr float kSniperZoomMin = 1.0f;
constexpr float kSniperZoomMax = 8.0f;
constexpr float kSniperZoomStep = 0.25f;

struct AdsTweakShared {
    uint32_t magic;
    volatile LONG sequence; // seqlock for pose edits made by the external UI
    volatile LONG save_requested;
    volatile LONG aim_active; // set only by the real bound Aim input during gameplay
    volatile LONG editor_hover; // suppress fire from clicks on the external editor
    volatile LONG move_all; // editor broadcasts selected joint edits to every joint
    volatile LONG weapon_id; // current held weapon, or -1 for the shared fallback pose
    volatile LONG global_rotation; // use one rotation around the selected pivot joint
    volatile LONG pivot_joint;
    volatile LONG weapon_zoom_milli; // per-weapon zoom ratio in thousandths (1000 = 1.0x)
    volatile LONG ads_transition_ms;
    volatile LONG zoom_transition_ms;
    float offsets[kAdsJointCount][6]; // translation X/Y/Z and rotation X/Y/Z (degrees)
};

extern "C" volatile LONG g_ads_tweak_aim_active;
extern "C" volatile LONG g_ads_tweak_force_nozoom;
extern "C" volatile LONG g_ads_modern_mode;
extern "C" volatile LONG g_ads_sniper_scope_active; // Modern ADS is active with the sniper (BLACK weapon ID 2)
extern "C" volatile float g_ads_sniper_zoom;
extern "C" volatile LONG g_ads_sniper_native_linger; // ADS ended but BLACK's own scope is still up: keep it hidden
extern "C" volatile float g_native_weapon_zoom;      // the game's own weapon zoom ratio (1 = not scoped)
extern "C" volatile float g_ads_tweak_zoom;

void ads_tweak_initialize();
void ads_tweak_poll();
void ads_tweak_set_aim(bool active);
bool ads_tweak_is_aiming();
float ads_tweak_pose_weight();
bool ads_tweak_editor_hover();
void ads_tweak_apply(float (*skin_constants)[4], int register_count);
bool ads_tweak_launch_ui();
void ads_tweak_set_modern_mode(bool modern);
void ads_tweak_sniper_zoom_update(int direction, float elapsed_seconds);
