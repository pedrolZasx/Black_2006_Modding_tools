#include "health_regen.h"

#include "common.h"

#include <algorithm>
#include <cerrno>
#include <cmath>
#include <cwchar>
#include <iterator>

namespace {
constexpr uint32_t kDefaultHealthAddress = 0x80B8754C;
constexpr int kDefaultMaxHealth = 22;
constexpr DWORD kPollMs = 100;

struct Config {
    bool enabled = true;
    uint32_t address = kDefaultHealthAddress;
    int max_health = kDefaultMaxHealth;
    DWORD delay_ms = 5000;
    float points_per_second = 1.0f;
};

Config g_health_cfg;
HANDLE g_thread;
wchar_t g_ini[MAX_PATH]{};

void load_config()
{
    GetModuleFileNameW(nullptr, g_ini, MAX_PATH);
    wchar_t *slash = wcsrchr(g_ini, L'\\');
    if (slash) wcscpy_s(slash + 1, MAX_PATH - (slash + 1 - g_ini), L"health_regen.ini");

    g_health_cfg.enabled = GetPrivateProfileIntW(L"health_regen", L"enabled", 1, g_ini) != 0;
    wchar_t text[64]{};
    if (GetPrivateProfileStringW(L"health_regen", L"health_address", L"0x80B8754C", text,
                                 static_cast<DWORD>(std::size(text)), g_ini)) {
        wchar_t *end = nullptr;
        const unsigned long address = wcstoul(text, &end, 0);
        if (end != text && address >= 0x80000000ul && address <= 0x8ffffffful)
            g_health_cfg.address = static_cast<uint32_t>(address);
    }
    g_health_cfg.max_health = std::clamp(static_cast<int>(GetPrivateProfileIntW(
        L"health_regen", L"max_health", kDefaultMaxHealth, g_ini)), 1, 1000);
    const int delay = static_cast<int>(GetPrivateProfileIntW(L"health_regen", L"delay_after_damage_seconds", 5, g_ini));
    g_health_cfg.delay_ms = static_cast<DWORD>(std::clamp(delay, 0, 3600) * 1000);
    text[0] = L'\0';
    GetPrivateProfileStringW(L"health_regen", L"points_per_second", L"1", text,
                              static_cast<DWORD>(std::size(text)), g_ini);
    wchar_t *end = nullptr;
    const float rate = wcstof(text, &end);
    if (end != text && std::isfinite(rate)) g_health_cfg.points_per_second = std::clamp(rate, 0.01f, 100.0f);
}

bool health_ptr(uint32_t address, volatile int *&value, bool for_write)
{
    auto *p = reinterpret_cast<void *>(static_cast<uintptr_t>(address));
    MEMORY_BASIC_INFORMATION mbi{};
    if (!p || VirtualQuery(p, &mbi, sizeof mbi) != sizeof mbi || mbi.State != MEM_COMMIT ||
        (mbi.Protect & (PAGE_NOACCESS | PAGE_GUARD))) return false;
    const uintptr_t start = reinterpret_cast<uintptr_t>(p);
    const uintptr_t end = reinterpret_cast<uintptr_t>(mbi.BaseAddress) + mbi.RegionSize;
    if (start > end || sizeof(int) > end - start) return false;
    if (for_write && mbi.Protect != PAGE_READWRITE && mbi.Protect != PAGE_WRITECOPY &&
        mbi.Protect != PAGE_EXECUTE_READWRITE && mbi.Protect != PAGE_EXECUTE_WRITECOPY) return false;
    value = static_cast<volatile int *>(p);
    return true;
}

DWORD WINAPI regen_thread(void *)
{
    DWORD last_damage = GetTickCount();
    DWORD next_point = last_damage;
    int previous = -1;
    float fractional = 0.0f;
    bool logged = false;
    for (;;) {
        if (!g_health_cfg.enabled) {
            Sleep(1000);
            continue;
        }
        volatile int *health = nullptr;
        if (!health_ptr(g_health_cfg.address, health, false)) {
            if (!logged) {
                logf("health regen: address 0x%08x is not readable; worker waiting", g_health_cfg.address);
                logged = true;
            }
            Sleep(1000);
            continue;
        }
        int current = *health;
        if (current < 0 || current > g_health_cfg.max_health) {
            previous = -1;
            Sleep(500);
            continue;
        }
        if (!logged) {
            logf("health regen: tracking player health at 0x%08x (max %d)", g_health_cfg.address, g_health_cfg.max_health);
            logged = true;
        }
        const DWORD now = GetTickCount();
        if (previous < 0) {
            previous = current;
            last_damage = next_point = now;
        } else if (current < previous) {
            last_damage = next_point = now;
            fractional = 0.0f;
        } else if (current > previous) {
            fractional = 0.0f;
        }
        previous = current;

        if (current > 0 && current < g_health_cfg.max_health && now - last_damage >= g_health_cfg.delay_ms &&
            now - next_point >= 1000) {
            const float points = g_health_cfg.points_per_second * (static_cast<float>(now - next_point) / 1000.0f);
            fractional += points;
            const int add = static_cast<int>(fractional);
            if (add > 0) {
                volatile int *writable = nullptr;
                if (health_ptr(g_health_cfg.address, writable, true)) {
                    const int updated = std::min(g_health_cfg.max_health, current + add);
                    *writable = updated;
                    current = updated;
                    fractional -= static_cast<float>(add);
                }
            }
            next_point = now;
        }
        Sleep(kPollMs);
    }
}
} // namespace

bool health_regen_initialize()
{
    load_config();
    if (!g_health_cfg.enabled) {
        logf("health regen: disabled by health_regen.ini");
        return true;
    }
    g_thread = CreateThread(nullptr, 0, regen_thread, nullptr, 0, nullptr);
    if (!g_thread) {
        logf("health regen: could not start worker (error %lu)", GetLastError());
        return false;
    }
    logf("health regen: enabled (delay %lu s, %.2f points/s; settings in health_regen.ini)",
         g_health_cfg.delay_ms / 1000, g_health_cfg.points_per_second);
    return true;
}
