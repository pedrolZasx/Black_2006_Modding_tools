#include "fire_lights.h"
#include "common.h"
#include "d3d/state.h"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <vector>

namespace fire_lights {
namespace {

struct Profile {
    uint32_t hash = 0;
    char name[48] = "fire";
    bool enabled = true;
    float color[3] = {1.0f, 0.55f, 0.20f};
    float intensity = 1.6f;
    float range = 7.0f;
    float flicker_amount = 0.35f;
    float flicker_speed = 7.0f;
    float height = 0.4f;          // metres added above the sprite centre
    float forward = 0.0f;         // metres along the camera forward direction
    bool debug = false;           // draw a screen-facing cross at the resulting light position
    float merge_radius = 1.5f;    // sprites closer than this make one light
    float size_ref = 8.0f;        // vertices in a fire that count as "normal size" (0 = don't scale by size)
    float linger = 0.25f;         // seconds a fire may be missing before its light starts fading
    float fade_in = 6.0f;         // light level per second going up
    float fade_out = 2.0f;        // light level per second going down (1/fade_out = seconds to go dark)
    float max_distance = 25.0f;   // fires farther than this from the camera get no light (and are not even tracked)
    int   max_lights = 4;         // at most this many fire lights of this shader at once (the nearest ones); the renderer draws 4 lights in total
    int   min_vertices = 200;     // reject small draws that share the fire vertex shader
    int   max_vertices = 330;     // reject large unrelated draws that share the fire vertex shader
    int   confirm_frames = 12;    // require a stable location for several frames before lighting it
    int   vp_const = 10;          // first constant slot of the game's world->clip matrix (4 rows)
};

struct Cluster { float sum[3]; uint32_t n; };
struct Fire {
    int profile;                  // hash index into g_profiles at creation (hash kept for reload safety)
    uint32_t hash;
    float pos[3];
    uint32_t verts;
    DWORD last_seen, born, last_confirm;
    uint32_t confirm_frames;
    float level;                  // 0..1 fade
    int level_id;
};

std::mutex g_mu;
std::vector<Profile> g_profiles;
FILETIME g_stamp{};
bool g_loaded = false;
struct CurSet { uint32_t hash; std::vector<Cluster> c; };
std::vector<CurSet> g_cur_sets;
std::vector<Fire> g_fires;
std::vector<world_lights::Light> g_debug_lights;
int g_last_level = -2;
const int kMaxFires = 48;

const wchar_t *ini_path()
{
    static wchar_t p[MAX_PATH]{};
    if (!p[0]) {
        GetModuleFileNameW(nullptr, p, MAX_PATH);
        wchar_t *s = wcsrchr(p, L'\\');
        if (s) wcscpy_s(s + 1, MAX_PATH - (s + 1 - p), L"fire_lights.ini");
    }
    return p;
}

const char *kDefaultIni =
    "; Fire lights. Every draw of a listed shader gets a point light at its flame sprites; the light fades out when the fire ends.\n"
    "; Find a shader hash in game: F11 (scan), then F12 repeatedly until the fire blinks; the log prints\n"
    ";   [wind-scan] BLINK n/N: shader XXXXXXXX\n"
    "; To add another fire / explosion shader copy a section below and change the hash. Reloaded while the game runs.\n"
    "; color = r,g,b   intensity = brightness   range = metres   flicker_amount 0..1   flicker_speed = cycles per second\n"
    "; height = metres above the sprite centre   forward = metres along camera direction   merge_radius = sprites closer than this share one light\n"
    "; size_ref = vertices of a 'normal' fire (bigger fires are brighter, 0 = ignore size)\n"
    "; linger = seconds before the light starts fading after the sprites vanish   fade_in / fade_out = light level per second\n"
    "; max_lights = most fire lights at once (nearest first)   max_distance = metres from the camera; farther fires get no light   vp_const = first slot of the game's world->clip matrix (10)\n"
    "\n"
    "[fire_C3B8752A]\n"
    "name=barrel fire\n"
    "enabled=1\n"
    "color=1.0,0.55,0.20\n"
    "intensity=1.6\n"
    "range=7\n"
    "flicker_amount=0.35\n"
    "flicker_speed=7\n"
    "height=0.4\n"
    "forward=0\n"
    "merge_radius=1.5\n"
    "size_ref=8\n"
    "linger=0.25\n"
    "fade_in=6\n"
    "fade_out=2\n"
    "max_distance=25\n"
    "max_lights=4\n"
    "min_vertices=200\n"
    "max_vertices=330\n"
    "confirm_frames=12\n"
    "vp_const=10\n"
    "\n"
    "; example for an explosion shader (remove the leading ; and put the real hash):\n"
    "; [fire_00000000]\n"
    "; name=explosion\n"
    "; color=1.0,0.7,0.35\n"
    "; intensity=3.5\n"
    "; range=12\n"
    "; merge_radius=3\n"
    "; fade_out=3\n";

void load_ini()
{
    static DWORD last_check = 0;
    const DWORD tick = GetTickCount();
    if (g_loaded && tick - last_check < 1000) return; // look for an edited ini once a second
    last_check = tick;
    WIN32_FILE_ATTRIBUTE_DATA a{};
    if (!GetFileAttributesExW(ini_path(), GetFileExInfoStandard, &a)) {
        if (g_loaded) return;
        FILE *w = nullptr;
        _wfopen_s(&w, ini_path(), L"wt");
        if (w) { fputs(kDefaultIni, w); fclose(w); }
        if (!GetFileAttributesExW(ini_path(), GetFileExInfoStandard, &a)) { g_loaded = true; return; }
    }
    if (g_loaded && !CompareFileTime(&g_stamp, &a.ftLastWriteTime)) return;
    g_stamp = a.ftLastWriteTime;
    g_loaded = true;
    g_profiles.clear();
    FILE *f = nullptr;
    _wfopen_s(&f, ini_path(), L"rt");
    if (!f) return;
    char line[512];
    Profile cur{};
    bool have = false;
    while (fgets(line, sizeof line, f)) {
        if (line[0] == ';' || line[0] == '#') continue;
        if (line[0] == '[') {
            if (have) g_profiles.push_back(cur);
            have = false;
            unsigned h = 0;
            if (sscanf_s(line, "[fire_%x]", &h) == 1 && h) { cur = Profile{}; cur.hash = h; have = true; }
            continue;
        }
        if (!have) continue;
        float a1, b1, c1; int i1; char s[64];
        if (sscanf_s(line, "name=%47[^\r\n]", cur.name, (unsigned)sizeof cur.name) == 1) {}
        else if (sscanf_s(line, "enabled=%d", &i1) == 1) cur.enabled = i1 != 0;
        else if (sscanf_s(line, "color=%f,%f,%f", &a1, &b1, &c1) == 3) { cur.color[0] = a1; cur.color[1] = b1; cur.color[2] = c1; }
        else if (sscanf_s(line, "intensity=%f", &a1) == 1) cur.intensity = a1;
        else if (sscanf_s(line, "range=%f", &a1) == 1) cur.range = a1;
        else if (sscanf_s(line, "flicker_amount=%f", &a1) == 1) cur.flicker_amount = a1;
        else if (sscanf_s(line, "flicker_speed=%f", &a1) == 1) cur.flicker_speed = a1;
        else if (sscanf_s(line, "height=%f", &a1) == 1) cur.height = a1;
        else if (sscanf_s(line, "forward=%f", &a1) == 1) cur.forward = std::clamp(a1, -5.0f, 5.0f);
        else if (sscanf_s(line, "debug=%d", &i1) == 1) cur.debug = i1 != 0;
        else if (sscanf_s(line, "merge_radius=%f", &a1) == 1) cur.merge_radius = std::max(a1, 0.2f);
        else if (sscanf_s(line, "size_ref=%f", &a1) == 1) cur.size_ref = a1;
        else if (sscanf_s(line, "linger=%f", &a1) == 1) cur.linger = std::max(a1, 0.f);
        else if (sscanf_s(line, "fade_in=%f", &a1) == 1) cur.fade_in = std::max(a1, 0.1f);
        else if (sscanf_s(line, "fade_out=%f", &a1) == 1) cur.fade_out = std::max(a1, 0.05f);
        else if (sscanf_s(line, "max_distance=%f", &a1) == 1) cur.max_distance = a1;
        else if (sscanf_s(line, "max_lights=%d", &i1) == 1) cur.max_lights = std::clamp(i1, 1, 8);
        else if (sscanf_s(line, "min_vertices=%d", &i1) == 1) cur.min_vertices = std::clamp(i1, 1, 100000);
        else if (sscanf_s(line, "max_vertices=%d", &i1) == 1) cur.max_vertices = std::clamp(i1, 1, 100000);
        else if (sscanf_s(line, "confirm_frames=%d", &i1) == 1) cur.confirm_frames = std::clamp(i1, 1, 120);
        else if (sscanf_s(line, "vp_const=%d", &i1) == 1) cur.vp_const = std::clamp(i1, 0, 188);
        (void)s;
    }
    if (have) g_profiles.push_back(cur);
    fclose(f);
    logf("[fire] BUILD 3 (world-space unprojection, near-player limits) - fire_lights.ini: %zu fire shader(s)", g_profiles.size());
    for (auto &p : g_profiles) logf("[fire]   shader %08X \"%s\" %s", p.hash, p.name, p.enabled ? "on" : "off");
}

const Profile *find(uint32_t hash)
{
    for (auto &p : g_profiles) if (p.hash == hash && p.enabled) return &p;
    return nullptr;
}

} // namespace

bool is_fire_shader(uint32_t hash)
{
    std::lock_guard<std::mutex> lk(g_mu);
    load_ini();
    return find(hash) != nullptr;
}

// 4x4 inverse (row-major); false when singular
static bool inv4(const float m[16], float o[16])
{
    float inv[16];
    inv[0]=m[5]*m[10]*m[15]-m[5]*m[11]*m[14]-m[9]*m[6]*m[15]+m[9]*m[7]*m[14]+m[13]*m[6]*m[11]-m[13]*m[7]*m[10];
    inv[4]=-m[4]*m[10]*m[15]+m[4]*m[11]*m[14]+m[8]*m[6]*m[15]-m[8]*m[7]*m[14]-m[12]*m[6]*m[11]+m[12]*m[7]*m[10];
    inv[8]=m[4]*m[9]*m[15]-m[4]*m[11]*m[13]-m[8]*m[5]*m[15]+m[8]*m[7]*m[13]+m[12]*m[5]*m[11]-m[12]*m[7]*m[9];
    inv[12]=-m[4]*m[9]*m[14]+m[4]*m[10]*m[13]+m[8]*m[5]*m[14]-m[8]*m[6]*m[13]-m[12]*m[5]*m[10]+m[12]*m[6]*m[9];
    inv[1]=-m[1]*m[10]*m[15]+m[1]*m[11]*m[14]+m[9]*m[2]*m[15]-m[9]*m[3]*m[14]-m[13]*m[2]*m[11]+m[13]*m[3]*m[10];
    inv[5]=m[0]*m[10]*m[15]-m[0]*m[11]*m[14]-m[8]*m[2]*m[15]+m[8]*m[3]*m[14]+m[12]*m[2]*m[11]-m[12]*m[3]*m[10];
    inv[9]=-m[0]*m[9]*m[15]+m[0]*m[11]*m[13]+m[8]*m[1]*m[15]-m[8]*m[3]*m[13]-m[12]*m[1]*m[11]+m[12]*m[3]*m[9];
    inv[13]=m[0]*m[9]*m[14]-m[0]*m[10]*m[13]-m[8]*m[1]*m[14]+m[8]*m[2]*m[13]+m[12]*m[1]*m[10]-m[12]*m[2]*m[9];
    inv[2]=m[1]*m[6]*m[15]-m[1]*m[7]*m[14]-m[5]*m[2]*m[15]+m[5]*m[3]*m[14]+m[13]*m[2]*m[7]-m[13]*m[3]*m[6];
    inv[6]=-m[0]*m[6]*m[15]+m[0]*m[7]*m[14]+m[4]*m[2]*m[15]-m[4]*m[3]*m[14]-m[12]*m[2]*m[7]+m[12]*m[3]*m[6];
    inv[10]=m[0]*m[5]*m[15]-m[0]*m[7]*m[13]-m[4]*m[1]*m[15]+m[4]*m[3]*m[13]+m[12]*m[1]*m[7]-m[12]*m[3]*m[5];
    inv[14]=-m[0]*m[5]*m[14]+m[0]*m[6]*m[13]+m[4]*m[1]*m[14]-m[4]*m[2]*m[13]-m[12]*m[1]*m[6]+m[12]*m[2]*m[5];
    inv[3]=-m[1]*m[6]*m[11]+m[1]*m[7]*m[10]+m[5]*m[2]*m[11]-m[5]*m[3]*m[10]-m[9]*m[2]*m[7]+m[9]*m[3]*m[6];
    inv[7]=m[0]*m[6]*m[11]-m[0]*m[7]*m[10]-m[4]*m[2]*m[11]+m[4]*m[3]*m[10]+m[8]*m[2]*m[7]-m[8]*m[3]*m[6];
    inv[11]=-m[0]*m[5]*m[11]+m[0]*m[7]*m[9]+m[4]*m[1]*m[11]-m[4]*m[3]*m[9]-m[8]*m[1]*m[7]+m[8]*m[3]*m[5];
    inv[15]=m[0]*m[5]*m[10]-m[0]*m[6]*m[9]-m[4]*m[1]*m[10]+m[4]*m[2]*m[9]+m[8]*m[1]*m[6]-m[8]*m[2]*m[5];
    const float det = m[0]*inv[0] + m[1]*inv[4] + m[2]*inv[8] + m[3]*inv[12];
    if (!std::isfinite(det) || fabsf(det) < 1e-20f) return false;
    const float id = 1.f / det;
    for (int i = 0; i < 16; i++) o[i] = inv[i] * id;
    return true;
}

void ingest(uint32_t hash, const uint8_t *base, uint32_t stride, int pos_off, uint32_t count, const float (*constants)[4], const int rows[4])
{
    if (!base || !count || pos_off < 0 || (uint32_t)pos_off + 12 > stride) return;
    std::lock_guard<std::mutex> lk(g_mu);
    const Profile *pr = find(hash);
    if (!pr) return;
    static uint32_t logged_transform_hash = 0;
    bool log_transform = logged_transform_hash != hash;
    if (log_transform) logged_transform_hash = hash;
    CurSet *set = nullptr;
    for (auto &s : g_cur_sets) if (s.hash == hash) { set = &s; break; }
    if (!set) { g_cur_sets.push_back({hash, {}}); set = &g_cur_sets.back(); }
    const float r2 = pr->merge_radius * pr->merge_radius;
    const uint32_t step = count > 512 ? count / 512 : 1; // very large draws are sampled
    float cam[3] = {}; bool have_cam = false;
    { float r[3], u[3], f[3]; if (world_lights::freecam_basis(cam, r, u, f)) have_cam = (cam[0] != 0.f || cam[1] != 0.f || cam[2] != 0.f); }
    const float keep2 = pr->max_distance > 0.f ? pr->max_distance * pr->max_distance * 1.7f : 0.f; // 1.3x the light distance
    // object -> clip (the shader's own matrix) then clip -> world (inverse of the game's world -> clip matrix)
    float vpinv[16]; bool unproject = false;
    const bool scale_offset = rows && constants && rows[0] == -2 && rows[1] >= 0 && rows[1] < 192 && rows[2] >= 0 && rows[2] < 192;
    const bool dp4_transform = rows && constants && rows[0] >= 0 && rows[1] >= 0 && rows[2] >= 0 && rows[3] >= 0;
    if (scale_offset || dp4_transform) {
        float vp[16];
        for (int r = 0; r < 4; r++) for (int k = 0; k < 4; k++) vp[r * 4 + k] = constants[pr->vp_const + r][k];
        unproject = inv4(vp, vpinv);
        if (!unproject) return; // the camera matrix is not valid right now
    }
    for (uint32_t i = 0; i < count; i += step) {
        const float *v = (const float *)(base + (size_t)i * stride + pos_off);
        float p[3] = {v[0], v[1], v[2]};
        const float raw[3] = {p[0], p[1], p[2]};
        float clip_debug[4]{};
        if (unproject) {
            float cl[4];
            if (scale_offset) {
                const float *sc = constants[rows[1]], *of = constants[rows[2]];
                const float vw = ((uint32_t)pos_off + 16 <= stride && std::isfinite(v[3])) ? v[3] : 1.f;
                cl[0] = p[0] * sc[0] + of[0]; cl[1] = p[1] * sc[1] + of[1];
                cl[2] = p[2] * sc[2] + of[2]; cl[3] = vw * sc[3] + of[3];
                // XDK shaders emit Xbox screen-space x/y and D24 depth here. Reverse that viewport
                // mapping before applying inverse world->clip; otherwise inverse VP collapses to camera.
                float screen_scale[4], screen_offset[4];
                xd3d::viewport_transform(screen_scale, screen_offset);
                if (fabsf(screen_scale[0]) < 1e-8f || fabsf(screen_scale[1]) < 1e-8f || fabsf(screen_scale[2]) < 1e-8f) continue;
                for (int c = 0; c < 3; c++) cl[c] = (cl[c] - screen_offset[c]) / screen_scale[c] * cl[3];
            } else {
                for (int r = 0; r < 4; r++) { const float *m = constants[rows[r]]; cl[r] = m[0] * p[0] + m[1] * p[1] + m[2] * p[2] + m[3]; }
            }
            memcpy(clip_debug, cl, sizeof cl);
            float wh[4];
            for (int r = 0; r < 4; r++) wh[r] = vpinv[r * 4 + 0] * cl[0] + vpinv[r * 4 + 1] * cl[1] + vpinv[r * 4 + 2] * cl[2] + vpinv[r * 4 + 3] * cl[3];
            if (fabsf(wh[3]) < 1e-12f) continue;
            p[0] = wh[0] / wh[3]; p[1] = wh[1] / wh[3]; p[2] = wh[2] / wh[3];
            if (log_transform) {
                logf("[fire] transform sample %08X: raw %.4f %.4f %.4f normalized-clip %.5f %.5f %.5f %.5f -> world %.4f %.4f %.4f; vp_const=%d camera %.3f %.3f %.3f", hash, raw[0], raw[1], raw[2], clip_debug[0], clip_debug[1], clip_debug[2], clip_debug[3], p[0], p[1], p[2], pr->vp_const, have_cam ? cam[0] : 0.f, have_cam ? cam[1] : 0.f, have_cam ? cam[2] : 0.f);
                if (scale_offset) {
                    const float *sc = constants[rows[1]], *of = constants[rows[2]];
                    logf("[fire] scale c%d %.5f %.5f %.5f %.5f; offset c%d %.5f %.5f %.5f %.5f", rows[1]-96, sc[0], sc[1], sc[2], sc[3], rows[2]-96, of[0], of[1], of[2], of[3]);
                }
                for (int r = 0; r < 4; r++) logf("[fire] vp c%d %.5f %.5f %.5f %.5f", pr->vp_const + r - 96, constants[pr->vp_const + r][0], constants[pr->vp_const + r][1], constants[pr->vp_const + r][2], constants[pr->vp_const + r][3]);
                log_transform = false;
            }
        }
        if (!std::isfinite(p[0]) || !std::isfinite(p[1]) || !std::isfinite(p[2]) || fabsf(p[0]) > 1e5f || fabsf(p[1]) > 1e5f || fabsf(p[2]) > 1e5f) continue;
        if (have_cam && keep2 > 0.f) {
            const float dx = p[0] - cam[0], dy = p[1] - cam[1], dz = p[2] - cam[2];
            if (dx * dx + dy * dy + dz * dz > keep2) continue; // too far from the player: no light, no tracking
        }
        Cluster *hit = nullptr;
        for (auto &c : set->c) {
            const float inv = 1.f / (float)c.n;
            const float dx = c.sum[0] * inv - p[0], dy = c.sum[1] * inv - p[1], dz = c.sum[2] * inv - p[2];
            if (dx * dx + dy * dy + dz * dz <= r2) { hit = &c; break; }
        }
        if (hit) { hit->sum[0] += p[0]; hit->sum[1] += p[1]; hit->sum[2] += p[2]; hit->n += step; }
        else if (set->c.size() < 96) set->c.push_back({{p[0], p[1], p[2]}, step});
    }
}

// Turns this frame's clusters into persistent fires, advances the fades and returns the lights.
int collect(int level, world_lights::Light *out, int max)
{
    std::lock_guard<std::mutex> lk(g_mu);
    load_ini();
    const DWORD now = GetTickCount();
    static DWORD last = 0;
    const float dt = last ? std::min(0.25f, (now - last) * 0.001f) : 0.016f;
    const bool advance = !last || now != last;
    last = now;
    if (level != g_last_level) { // new mission: forget the old fires
        g_fires.clear();
        g_debug_lights.clear();
        for (auto &s : g_cur_sets) s.c.clear();
        g_last_level = level;
    }
    g_debug_lights.clear();
    float cam[3] = {};
    float cam_forward[3] = {0.f, 0.f, 1.f};
    bool have_cam = false;
    {
        float r[3], u[3], f[3];
        if (world_lights::freecam_basis(cam, r, u, f)) {
            have_cam = (cam[0] != 0.f || cam[1] != 0.f || cam[2] != 0.f);
            memcpy(cam_forward, f, sizeof cam_forward);
        }
    }
    // match this frame's clusters against the known fires
    for (auto &s : g_cur_sets) {
        const Profile *pr = find(s.hash);
        if (!pr) { s.c.clear(); continue; }
        const float mr = pr->merge_radius * 1.6f, mr2 = mr * mr;
        for (auto &c : s.c) {
            if (c.n < (uint32_t)pr->min_vertices || c.n > (uint32_t)pr->max_vertices) continue; // restrict by vertex-count window
            const float inv = 1.f / (float)c.n;
            const float p[3] = {c.sum[0] * inv, c.sum[1] * inv, c.sum[2] * inv};
            Fire *best = nullptr; float bd = mr2;
            for (auto &f : g_fires) {
                if (f.hash != s.hash) continue;
                const float dx = f.pos[0] - p[0], dy = f.pos[1] - p[1], dz = f.pos[2] - p[2];
                const float d2 = dx * dx + dy * dy + dz * dz;
                if (d2 < bd) { bd = d2; best = &f; }
            }
            if (best) {
                if (now - best->last_seen > 150) best->confirm_frames = 1;
                else if (now != best->last_confirm) best->confirm_frames = std::min(best->confirm_frames + 1, 100000u);
                best->last_confirm = now;
                for (int j = 0; j < 3; j++) best->pos[j] += (p[j] - best->pos[j]) * 0.3f;
                best->verts = (best->verts * 3 + c.n) / 4;
                best->last_seen = now;
            } else if ((int)g_fires.size() < kMaxFires) {
                Fire nf{};
                nf.hash = s.hash; nf.pos[0] = p[0]; nf.pos[1] = p[1]; nf.pos[2] = p[2];
                nf.verts = c.n; nf.last_seen = nf.born = nf.last_confirm = now; nf.confirm_frames = 1; nf.level = 0.f; nf.level_id = level;
                g_fires.push_back(nf);
            }
        }
        s.c.clear();
    }
    // fades
    if (advance) {
        for (auto &f : g_fires) {
            const Profile *pr = find(f.hash);
            if (!pr) { f.level = 0.f; f.last_seen = 0; continue; }
            const bool alive = (now - f.last_seen) < (DWORD)(pr->linger * 1000.f);
            if (alive && f.confirm_frames >= (uint32_t)pr->confirm_frames) {
                if (f.level <= 0.001f) logf("[fire] confirmed %08X (%s) at %.2f %.2f %.2f after %u stable frames (%u vertices)", f.hash, pr->name, f.pos[0], f.pos[1], f.pos[2], f.confirm_frames, f.verts);
                f.level = std::min(1.f, f.level + pr->fade_in * dt);
            } else if (!alive) {
                f.level = std::max(0.f, f.level - pr->fade_out * dt);
            } else {
                f.level = 0.f;
            }
        }
        g_fires.erase(std::remove_if(g_fires.begin(), g_fires.end(), [&](const Fire &f) {
            const Profile *pr = find(f.hash);
            const bool alive = pr && (now - f.last_seen) < (DWORD)(pr->linger * 1000.f);
            return !alive && f.level <= 0.f;
        }), g_fires.end());
    }
    // lights: only fires near the player, nearest first, at most max_lights per shader
    struct Cand { float d2; const Fire *f; const Profile *pr; };
    std::vector<Cand> cands;
    for (const Fire &f : g_fires) {
        const Profile *pr = find(f.hash);
        if (!pr || f.level <= 0.001f) continue;
        float d2 = 0.f;
        if (have_cam) {
            const float dx = f.pos[0] - cam[0], dy = f.pos[1] - cam[1], dz = f.pos[2] - cam[2];
            d2 = dx * dx + dy * dy + dz * dz;
            if (pr->max_distance > 0.f && d2 > pr->max_distance * pr->max_distance) continue;
        }
        cands.push_back({d2, &f, pr});
    }
    std::sort(cands.begin(), cands.end(), [](const Cand &a, const Cand &b) { return a.d2 < b.d2; });
    std::vector<std::pair<uint32_t, int>> used;
    int n = 0;
    for (const Cand &cd : cands) {
        if (n >= max) break;
        int *cnt = nullptr;
        for (auto &u : used) if (u.first == cd.f->hash) { cnt = &u.second; break; }
        if (!cnt) { used.push_back({cd.f->hash, 0}); cnt = &used.back().second; }
        if (*cnt >= cd.pr->max_lights) continue;
        ++*cnt;
        const Fire &f = *cd.f; const Profile *pr = cd.pr;
        world_lights::Light l{};
        l.level = level;
        l.position[0] = f.pos[0] + pr->forward * cam_forward[0];
        l.position[1] = f.pos[1] + pr->height + pr->forward * cam_forward[1];
        l.position[2] = f.pos[2] + pr->forward * cam_forward[2];
        l.direction[1] = 1.f;
        for (int j = 0; j < 3; j++) l.color[j] = pr->color[j];
        const float size = pr->size_ref > 0.f ? std::clamp(sqrtf((float)f.verts / pr->size_ref), 0.5f, 2.f) : 1.f;
        const float smooth = f.level * f.level * (3.f - 2.f * f.level);
        l.intensity = pr->intensity * size * smooth;
        l.range = pr->range;
        l.inner_degrees = 18.f; l.outer_degrees = 35.f;
        l.cone = false;
        l.flicker_amount = pr->flicker_amount;
        l.flicker_speed = pr->flicker_speed;
        l.beam_mode = 1; l.beam_length = 1.f; l.beam_width = 1.f; l.beam_soft = 0.6f; // no beam: vol_intensity stays 0
        if (pr->debug && g_debug_lights.size() < 16) g_debug_lights.push_back(l);
        out[n++] = l;
    }
    return n;
}

int debug_positions(int level, float out[][3], int max)
{
    if (!out || max <= 0) return 0;
    std::lock_guard<std::mutex> lk(g_mu);
    int n = 0;
    for (const auto &l : g_debug_lights) {
        if (l.level != level || n >= max) continue;
        memcpy(out[n++], l.position, sizeof l.position);
    }
    return n;
}

} // namespace fire_lights
