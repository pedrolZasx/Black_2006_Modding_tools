#include <windows.h>
#include <commctrl.h>
#include <algorithm>
#include <cstdio>
#include <cwchar>
#include <string>
#include <vector>

namespace {
constexpr int ID_LEVEL=100, ID_WIND=101, ID_WEATHER=102, ID_RAIN=103, ID_RAIN_SOUND=104, ID_SAVE=105, ID_LEAVES=106;
constexpr int ID_FIELD_BASE=1000;
HWND g_window, g_level;
std::wstring g_dir;
struct Field { const wchar_t *label; int file; const wchar_t *section; const wchar_t *key; const wchar_t *fallback_section; const wchar_t *fallback_key; const wchar_t *initial; bool per_level; };
const Field g_fields[] = {
 {L"Wind · direction (degrees)",0,L"wind_level",L"direction",L"wind",L"direction",L"60",true},
 {L"Wind · direction drift (degrees)",0,L"wind_level",L"direction_drift",L"wind",L"direction_drift",L"25",true},
 {L"Wind · drift speed (Hz)",0,L"wind_level",L"direction_drift_speed",L"wind",L"direction_drift_speed",L"0.05",true},
 {L"Wind · gust-front speed (m/s)",0,L"wind_level",L"speed",L"wind",L"speed",L"6",true},
 {L"Wind · wavelength (m)",0,L"wind_level",L"wavelength",L"wind",L"wavelength",L"14",true},
 {L"Wind · strength (m)",0,L"wind_level",L"strength",L"wind",L"strength",L"0.18",true},
 {L"Wind · natural variation (0-1)",0,L"wind_level",L"variation",L"wind",L"variation",L"0.35",true},
 {L"Wind · gust amount",0,L"wind_level",L"gust",L"wind",L"gust",L"0.6",true},
 {L"Wind · gust speed (Hz)",0,L"wind_level",L"gust_speed",L"wind",L"gust_speed",L"0.25",true},
 {L"Wind · flutter",0,L"wind_level",L"flutter",L"wind",L"flutter",L"0.35",true},
 {L"Wind · flutter speed (Hz)",0,L"wind_level",L"flutter_speed",L"wind",L"flutter_speed",L"3.2",true},
 {L"Wind · droop",0,L"wind_level",L"droop",L"wind",L"droop",L"0.25",true},
 {L"Wind · follow rain wind (0/1)",0,L"wind_level",L"follow_rain",L"wind",L"follow_rain",L"1",true},
 {L"Foliage · enabled (0/1)",0,L"wind_level",L"foliage_enabled",L"wind_foliage",L"enabled",L"1",true},
 {L"Foliage · strength",0,L"wind_level",L"foliage_strength",L"wind_foliage",L"strength",L"1.0",true},
 {L"Foliage · weight (none/uv/alpha)",0,L"wind_level",L"foliage_weight",L"wind_foliage",L"weight",L"none",true},
 {L"Foliage · bend",0,L"wind_level",L"foliage_bend",L"wind_foliage",L"bend",L"1.5",true},
 {L"Foliage · phase (radians)",0,L"wind_level",L"foliage_phase",L"wind_foliage",L"phase",L"0",true},
 {L"Foliage · material codes",0,L"wind_level",L"foliage_hashes",L"shaders",L"foliage",L"",true},
 {L"Grass · enabled (0/1)",0,L"wind_level",L"grass_enabled",L"wind_grass",L"enabled",L"1",true},
 {L"Grass · strength",0,L"wind_level",L"grass_strength",L"wind_grass",L"strength",L"1.6",true},
 {L"Grass · weight (uv/alpha)",0,L"wind_level",L"grass_weight",L"wind_grass",L"weight",L"uv",true},
 {L"Grass · bend",0,L"wind_level",L"grass_bend",L"wind_grass",L"bend",L"1.8",true},
 {L"Grass · phase (radians)",0,L"wind_level",L"grass_phase",L"wind_grass",L"phase",L"1.7",true},
 {L"Light rays · enabled (0/1)",0,L"wind_level",L"lightray_enabled",L"wind_lightray",L"enabled",L"0",true},
 {L"Light rays · strength",0,L"wind_level",L"lightray_strength",L"wind_lightray",L"strength",L"0",true},
 {L"Light rays · weight (none/uv)",0,L"wind_level",L"lightray_weight",L"wind_lightray",L"weight",L"none",true},
 {L"Light rays · bend",0,L"wind_level",L"lightray_bend",L"wind_lightray",L"bend",L"1.5",true},
 {L"Light rays · phase (radians)",0,L"wind_level",L"lightray_phase",L"wind_lightray",L"phase",L"0",true},
 {L"Tree copies (1-8)",0,L"density",L"tree",L"density",L"tree",L"1",false},
 {L"Tree spread (m)",0,L"density",L"tree_spread",L"density",L"tree_spread",L"1.5",false},
 {L"Light-ray copies (1-8)",0,L"density",L"lightray",L"density",L"lightray",L"1",false},
 {L"Light-ray spread (m)",0,L"density",L"lightray_spread",L"density",L"lightray_spread",L"0.4",false},
 {L"Grass copies (1-8)",0,L"density",L"grass",L"density",L"grass",L"1",false},
 {L"Grass spread (m)",0,L"density",L"grass_spread",L"density",L"grass_spread",L"0.4",false},
 {L"Storm · flash strength",1,L"general",L"strength",L"general",L"strength",L"1.0",false},
 {L"Storm · strike interval (sec)",1,L"general",L"interval",L"general",L"interval",L"6 25",false},
 {L"Storm · strong strike chance (%)",1,L"general",L"big_chance",L"general",L"big_chance",L"55",false},
 {L"Rain · intensity",1,L"rain",L"intensity",L"rain",L"intensity",L"1.0",false},
 {L"Rain · drop count",1,L"rain",L"count",L"rain",L"count",L"2200",false},
 {L"Rain · speed (min max)",1,L"rain",L"speed",L"rain",L"speed",L"9.5 12.5",false},
 {L"Rain · sound volume (0-4)",1,L"rain",L"sound_volume",L"rain",L"sound_volume",L"0.80",false},
 {L"Rain · WAV path",1,L"rain",L"sound_file",L"rain",L"sound_file",L"rain\\rain.wav",false},
 {L"Leaves · particle count",1,L"leaves_level",L"count",L"leaves",L"count",L"90",true},
 {L"Leaves · radius (m)",1,L"leaves_level",L"radius",L"leaves",L"radius",L"22",true},
 {L"Leaves · height (m)",1,L"leaves_level",L"height",L"leaves",L"height",L"14",true},
 {L"Leaves · size (m)",1,L"leaves_level",L"size",L"leaves",L"size",L"0.34",true},
 {L"Leaves · fall speed (m/s)",1,L"leaves_level",L"fall_speed",L"leaves",L"fall_speed",L"0.28",true},
 {L"Leaves · wind (x z)",1,L"leaves_level",L"wind",L"leaves",L"wind",L"0.45 0.12",true},
 {L"Leaves · flutter",1,L"leaves_level",L"flutter",L"leaves",L"flutter",L"1.6",true},
 {L"Leaves · randomness",1,L"leaves_level",L"randomness",L"leaves",L"randomness",L"0.8",true},
 {L"Leaves · rotation speed",1,L"leaves_level",L"rotation_speed",L"leaves",L"rotation_speed",L"2.8",true},
 {L"Leaves · opacity (0-1)",1,L"leaves_level",L"opacity",L"leaves",L"opacity",L"0.85",true},
 {L"Leaves · texture path",1,L"leaves_level",L"texture",L"leaves",L"texture",L"fx\\leaf.png",true},
};
constexpr int kFieldCount=(int)(sizeof(g_fields)/sizeof(g_fields[0]));
std::wstring path(const wchar_t *f){return g_dir+f;}
std::string narrow(const std::wstring &w){int n=WideCharToMultiByte(CP_UTF8,0,w.c_str(),-1,nullptr,0,nullptr,nullptr);std::string s(n? n:0,'\0');if(n>0){WideCharToMultiByte(CP_UTF8,0,w.c_str(),-1,s.data(),n,nullptr,nullptr);s.pop_back();}return s;}
std::wstring read_file(const std::wstring &p){FILE*f=nullptr;_wfopen_s(&f,p.c_str(),L"rb");if(!f)return {};fseek(f,0,SEEK_END);long n=ftell(f);rewind(f);std::string s(n>0?n:0,'\0');if(n>0)fread(s.data(),1,s.size(),f);fclose(f);int wn=MultiByteToWideChar(CP_UTF8,0,s.c_str(),(int)s.size(),nullptr,0);std::wstring w(wn,L'\0');if(wn)MultiByteToWideChar(CP_UTF8,0,s.c_str(),(int)s.size(),w.data(),wn);return w;}
bool write_file(const std::wstring&p,const std::wstring&s){FILE*f=nullptr;_wfopen_s(&f,p.c_str(),L"wb");if(!f)return false;std::string b=narrow(s);bool ok=fwrite(b.data(),1,b.size(),f)==b.size();fclose(f);return ok;}
std::wstring trim(std::wstring s){auto a=s.find_first_not_of(L" \t\r\n"),b=s.find_last_not_of(L" \t\r\n");return a==s.npos?L"":s.substr(a,b-a+1);}
std::vector<std::wstring> lines(const std::wstring&s){std::vector<std::wstring>o;size_t a=0;while(a<s.size()){size_t b=s.find(L'\n',a);if(b==s.npos)b=s.size();o.push_back(s.substr(a,b-a));a=b+1;}return o;}
std::wstring value(const std::wstring&file,const std::wstring&section,const std::wstring&key,const std::wstring&fallback){std::wstring sec;for(auto l:lines(file)){l=trim(l);if(l.size()>2&&l.front()==L'['&&l.back()==L']'){sec=l.substr(1,l.size()-2);continue;}if(sec!=section)continue;size_t e=l.find(L'=');if(e!=l.npos&&trim(l.substr(0,e))==key)return trim(l.substr(e+1));}return fallback;}
std::wstring set_value(std::wstring file,const std::wstring&section,const std::wstring&key,const std::wstring&val){auto ls=lines(file);bool in=false,found=false,have=false;std::vector<std::wstring>out;for(auto l:ls){std::wstring t=trim(l);if(t.size()>2&&t.front()==L'['&&t.back()==L']'){if(in&&!found){out.push_back(key+L"="+val);found=true;}in=t.substr(1,t.size()-2)==section;if(in)have=true;out.push_back(l);continue;}if(in){size_t e=l.find(L'=');if(e!=l.npos&&trim(l.substr(0,e))==key){out.push_back(key+L"="+val);found=true;continue;}}out.push_back(l);}if(!have){if(!out.empty()&&!out.back().empty())out.push_back(L"");out.push_back(L"["+section+L"]");}if(!found)out.push_back(key+L"="+val);std::wstring r;for(auto&l:out)r+=l+L"\r\n";return r;}
bool list_has(std::wstring s,int lv){if(s==L"all"||s==L"-1")return true;std::wstring token;for(wchar_t c:s+L" "){if(c==L' '||c==L','||c==L'\t'){if(!token.empty()){if(_wtoi(token.c_str())==lv)return true;token.clear();}}else token+=c;}return false;}
std::wstring list_set(std::wstring s,int lv,bool on){std::vector<int>v;bool all=s==L"all"||s==L"-1";if(all&&!on){for(int n=0;n<100;n++)if(n!=lv)v.push_back(n);}else if(!all){std::wstring t;for(wchar_t c:s+L" "){if(c==L' '||c==L','||c==L'\t'){if(!t.empty()){int n=_wtoi(t.c_str());if(n>=0&&n<=99&&std::find(v.begin(),v.end(),n)==v.end())v.push_back(n);t.clear();}}else t+=c;}}auto i=std::find(v.begin(),v.end(),lv);if(on&&i==v.end())v.push_back(lv);if(!on&&i!=v.end())v.erase(i);std::sort(v.begin(),v.end());if(v.empty())return L"999";std::wstring o;for(int n:v){if(!o.empty())o+=L" ";wchar_t b[8];swprintf_s(b,L"%d",n);o+=b;}return o;}
int level(){return (int)SendMessageW(g_level,CB_GETCURSEL,0,0);}
std::wstring level_section(){wchar_t b[40];swprintf_s(b,L"wind_level_%02d",level());return b;}
std::wstring leaf_section(){wchar_t b[40];swprintf_s(b,L"leaves_level_%02d",level());return b;}
std::wstring field_section(const Field&f){return f.per_level?(f.file&&wcscmp(f.section,L"leaves_level")==0?leaf_section():level_section()):f.section;}
void set_check(int id,bool b){SendDlgItemMessageW(g_window,id,BM_SETCHECK,b?BST_CHECKED:BST_UNCHECKED,0);}
bool checked(int id){return SendDlgItemMessageW(g_window,id,BM_GETCHECK,0,0)==BST_CHECKED;}
std::wstring edit(int id){wchar_t b[512]{};GetDlgItemTextW(g_window,id,b,(int)_countof(b));return b;}
void put(int id,const std::wstring&s){SetDlgItemTextW(g_window,id,s.c_str());}
std::wstring field_value(const std::wstring &wi,const std::wstring &we,int i){const Field&f=g_fields[i];const auto&file=f.file?we:wi;std::wstring sec=field_section(f);return value(file,sec,f.key,value(file,f.fallback_section,f.fallback_key,f.initial));}
void load(){auto wi=read_file(path(L"wind.ini")),we=read_file(path(L"weather.ini"));int lv=level();auto ws=level_section();auto wind_on=value(wi,ws,L"enabled",value(wi,L"wind",L"enabled",L"1"));auto general=value(we,L"general",L"enabled",L"1");auto weather_on=general!=L"0"&&general!=L"false"&&list_has(value(we,L"general",L"levels",L"all"),lv);auto rain_on=value(we,L"rain",L"enabled",L"1");set_check(ID_WIND,wind_on!=L"0"&&wind_on!=L"false");set_check(ID_WEATHER,weather_on);set_check(ID_RAIN,rain_on!=L"0"&&rain_on!=L"false"&&list_has(value(we,L"rain",L"levels",L"all"),lv));set_check(ID_RAIN_SOUND,value(we,L"rain",L"sound",L"1")!=L"0");set_check(ID_LEAVES,value(we,leaf_section(),L"enabled",value(we,L"leaves",L"enabled",L"0"))!=L"0");for(int i=0;i<kFieldCount;i++)put(ID_FIELD_BASE+i,field_value(wi,we,i));}
void save(){auto wp=path(L"wind.ini"),ep=path(L"weather.ini");auto wi=read_file(wp),we=read_file(ep);if(wi.empty()||we.empty()){MessageBoxW(g_window,L"wind.ini and weather.ini must be next to black.exe.",L"FX editor",MB_ICONERROR);return;}const int lv=level();const std::wstring ws=level_section();wi=set_value(wi,ws,L"enabled",checked(ID_WIND)?L"1":L"0");for(int i=0;i<kFieldCount;i++){const Field&f=g_fields[i];if(f.file){we=set_value(we,field_section(f),f.key,edit(ID_FIELD_BASE+i));}else {const std::wstring sec=field_section(f);wi=set_value(wi,sec,f.key,edit(ID_FIELD_BASE+i));}}we=set_value(we,L"general",L"enabled",L"1");we=set_value(we,L"general",L"levels",list_set(value(we,L"general",L"levels",L"all"),lv,checked(ID_WEATHER)));we=set_value(we,L"rain",L"enabled",L"1");we=set_value(we,L"rain",L"levels",list_set(value(we,L"rain",L"levels",L"all"),lv,checked(ID_RAIN)));we=set_value(we,L"rain",L"sound",checked(ID_RAIN_SOUND)?L"1":L"0");we=set_value(we,leaf_section(),L"enabled",checked(ID_LEAVES)?L"1":L"0");if(!write_file(wp,wi)||!write_file(ep,we))MessageBoxW(g_window,L"Could not write the INI files.",L"FX editor",MB_ICONERROR);else MessageBoxW(g_window,L"Saved. Wind, rain audio, and weather reload automatically while BLACK is running.",L"FX editor",MB_ICONINFORMATION);}
HWND ctrl(const wchar_t*cls,const wchar_t*text,DWORD style,int x,int y,int w,int h,int id){return CreateWindowW(cls,text,WS_CHILD|WS_VISIBLE|style,x,y,w,h,g_window,(HMENU)(INT_PTR)id,GetModuleHandleW(nullptr),nullptr);}
LRESULT CALLBACK proc(HWND h,UINT m,WPARAM w,LPARAM l){if(m==WM_CREATE){g_window=h;CreateWindowW(L"STATIC",L"Map",WS_CHILD|WS_VISIBLE,14,14,45,22,h,nullptr,nullptr,nullptr);g_level=CreateWindowW(L"COMBOBOX",L"",WS_CHILD|WS_VISIBLE|CBS_DROPDOWNLIST|WS_VSCROLL,62,10,145,260,h,(HMENU)ID_LEVEL,GetModuleHandleW(nullptr),nullptr);for(int i=0;i<100;i++){wchar_t b[32];swprintf_s(b,L"Level %02d",i);SendMessageW(g_level,CB_ADDSTRING,0,(LPARAM)b);}SendMessageW(g_level,CB_SETCURSEL,0,0);ctrl(L"BUTTON",L"Wind enabled for this map",BS_AUTOCHECKBOX,230,10,190,24,ID_WIND);ctrl(L"BUTTON",L"Storm enabled",BS_AUTOCHECKBOX,430,10,135,24,ID_WEATHER);ctrl(L"BUTTON",L"Rain enabled",BS_AUTOCHECKBOX,575,10,110,24,ID_RAIN);ctrl(L"BUTTON",L"Rain ambience enabled",BS_AUTOCHECKBOX,695,10,180,24,ID_RAIN_SOUND);ctrl(L"BUTTON",L"Leaves enabled for this map",BS_AUTOCHECKBOX,890,10,190,24,ID_LEAVES);for(int i=0;i<kFieldCount;i++){int col=i/18,row=i%18,x=14+col*460,y=48+row*30;CreateWindowW(L"STATIC",g_fields[i].label,WS_CHILD|WS_VISIBLE,x,y,195,22,h,nullptr,nullptr,nullptr);CreateWindowExW(WS_EX_CLIENTEDGE,L"EDIT",L"",WS_CHILD|WS_VISIBLE|WS_TABSTOP|ES_AUTOHSCROLL,x+195,y-3,245,24,h,(HMENU)(INT_PTR)(ID_FIELD_BASE+i),GetModuleHandleW(nullptr),nullptr);}ctrl(L"BUTTON",L"Save settings",BS_DEFPUSHBUTTON,1220,610,155,32,ID_SAVE);CreateWindowW(L"STATIC",L"Foliage codes are hex hashes, comma separated; blank inherits [shaders] foliage, `none` disables it per mission.",WS_CHILD|WS_VISIBLE,14,625,1100,22,h,nullptr,nullptr,nullptr);load();return 0;}if(m==WM_COMMAND){if(LOWORD(w)==ID_LEVEL&&HIWORD(w)==CBN_SELCHANGE)load();if(LOWORD(w)==ID_SAVE)save();return 0;}if(m==WM_DESTROY){PostQuitMessage(0);return 0;}return DefWindowProcW(h,m,w,l);}
}
int WINAPI wWinMain(HINSTANCE inst,HINSTANCE,PWSTR,int){wchar_t p[MAX_PATH]{};GetModuleFileNameW(nullptr,p,MAX_PATH);wchar_t*s=wcsrchr(p,L'\\');if(s)s[1]=0;g_dir=p;INITCOMMONCONTROLSEX ic{sizeof(ic),ICC_STANDARD_CLASSES};InitCommonControlsEx(&ic);WNDCLASSW wc{};wc.lpfnWndProc=proc;wc.hInstance=inst;wc.lpszClassName=L"BlackFxEditor";wc.hCursor=LoadCursorW(nullptr,IDC_ARROW);wc.hbrBackground=(HBRUSH)(COLOR_BTNFACE+1);RegisterClassW(&wc);g_window=CreateWindowW(wc.lpszClassName,L"BLACK — Wind / Weather / Rain",WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX,CW_USEDEFAULT,CW_USEDEFAULT,1420,680,nullptr,nullptr,inst,nullptr);if(!g_window)return 1;ShowWindow(g_window,SW_SHOW);MSG msg;while(GetMessageW(&msg,nullptr,0,0)>0){TranslateMessage(&msg);DispatchMessageW(&msg);}return(int)msg.wParam;}
