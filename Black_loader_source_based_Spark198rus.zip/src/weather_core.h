// Thunderstorm flash patterns: pure logic, no Windows, no D3D, no audio (so it can be tested on its own).
//
// A "strike" is a list of flash pulses on a millisecond timeline:
//   big strike : small flash, small flash, ... then a QUICK BIG flash (and sometimes a faint flicker after it)
//   weak strike: one or two faint flashes, nothing big
// Each pulse jumps up in a few ms and dies away (squared fall-off), like a real flash on the clouds.
#pragma once

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <random>
#include <string>
#include <vector>

namespace weather {

struct Range {
    float lo = 0, hi = 0;
    Range() = default;
    Range(float a, float b) : lo(a), hi(b) {}
};

struct Settings {
    // ---- general
    bool enabled = true;
    std::vector<int> levels;          // empty = every level, else only level_NN for the listed N
    float strength = 1.0f;            // master flash brightness
    float color[3] = {0.78f, 0.86f, 1.0f};
    Range interval{6.0f, 25.0f};      // seconds between strikes
    Range first_strike{3.0f, 8.0f};   // seconds from entering a level to the first strike
    float big_chance = 55.0f;         // % of strikes that are "small, small, BIG"; the rest are weak
    float attack = 10.0f;             // ms a flash needs to reach full brightness
    // ---- strong strike: small flashes, then the quick big one
    Range small_count{2, 2};
    Range small_intensity{0.22f, 0.42f};
    Range small_length{55, 90};       // ms
    Range small_gap{70, 150};         // ms from the start of one small flash to the start of the next
    Range big_delay{90, 200};         // ms from the start of the last small flash to the big flash
    Range big_intensity{0.95f, 1.25f};
    Range big_length{180, 320};       // ms
    float flicker_chance = 45.0f;     // % chance of a faint flicker right after the big flash
    Range flicker_intensity{0.15f, 0.35f};
    // ---- weak strike
    Range weak_count{1, 2};
    Range weak_intensity{0.06f, 0.20f};
    Range weak_length{80, 170};
    Range weak_gap{90, 220};
    // ---- how the light looks on the map
    float flash_floor = 0.22f;        // how much even a black surface lights up
    float flash_gain = 1.2f;          // how much the existing colours brighten
    float far_fade = 0.35f;           // 0..1: far surfaces get less light
    float flash_range = 80.0f;        // metres at which far_fade is complete
    float normal_strength = 0.5f;     // 0 = flat light, 1 = surfaces facing the camera light up more
    float sky_gain = 1.0f;            // sky / very far pixels
    float gun_flash = 1.0f;           // 1 = the first-person gun is lit by the flash too, 0 = not
    // ---- thunder sound
    bool sound = true;
    std::string sound_folder = "thunder"; // relative to black.exe, or a full path
    Range thunder_delay{350, 1600};   // ms AFTER the big flash starts
    float thunder_volume = 1.0f;
    bool weak_sound = true;
    Range weak_thunder_delay{700, 2400};
    float weak_thunder_volume = 0.35f;
    float sound_budget_mb = 48.0f;    // all thunder wavs together stay in memory (32-bit process)
};

struct Pulse {
    double start;  // ms, absolute
    double len;    // ms of fall-off after the attack
    double peak;   // 0..~1.3
};

struct Strike {
    bool big = false;
    std::vector<Pulse> pulses;
    double big_start = 0; // the big flash (big strikes) or the first flash (weak strikes)
    double end = 0;       // when the last pulse is over
    int flashes = 0;
};

typedef std::mt19937 Rng;

inline float rnd(Rng &r, const Range &g)
{
    float lo = std::min(g.lo, g.hi), hi = std::max(g.lo, g.hi);
    if (hi <= lo) return lo;
    return lo + (hi - lo) * (float)((r() & 0xFFFFFF) / 16777216.0);
}
inline int rnd_int(Rng &r, const Range &g)
{
    int lo = (int)std::lround(std::min(g.lo, g.hi)), hi = (int)std::lround(std::max(g.lo, g.hi));
    if (hi <= lo) return lo;
    return lo + (int)(r() % (uint32_t)(hi - lo + 1));
}
inline bool chance(Rng &r, float percent) { return rnd(r, Range(0, 100)) < percent; }

inline Strike make_strike(const Settings &s, bool big, Rng &r, double t0)
{
    Strike k;
    k.big = big;
    double t = t0;
    if (big) {
        int n = std::max(0, rnd_int(r, s.small_count));
        for (int i = 0; i < n; i++) {
            k.pulses.push_back({t, (double)rnd(r, s.small_length), (double)rnd(r, s.small_intensity)});
            if (i + 1 < n) t += rnd(r, s.small_gap);
        }
        t = n ? t + rnd(r, s.big_delay) : t; // the big flash comes quickly after the last small one
        double len = rnd(r, s.big_length);
        k.pulses.push_back({t, len, (double)rnd(r, s.big_intensity)});
        k.big_start = t;
        if (chance(r, s.flicker_chance))
            k.pulses.push_back({t + len * 0.75 + rnd(r, Range(50, 120)), (double)rnd(r, Range(60, 110)), (double)rnd(r, s.flicker_intensity)});
    } else {
        int n = std::max(1, rnd_int(r, s.weak_count));
        k.big_start = t;
        for (int i = 0; i < n; i++) {
            k.pulses.push_back({t, (double)rnd(r, s.weak_length), (double)rnd(r, s.weak_intensity)});
            t += rnd(r, s.weak_gap);
        }
    }
    k.flashes = (int)k.pulses.size();
    k.end = t0;
    for (const Pulse &p : k.pulses) k.end = std::max(k.end, p.start + s.attack + p.len);
    return k;
}

// Flash brightness of a strike at time t (ms): the brightest pulse at that moment.
inline double level_at(const Strike &k, double t, double attack)
{
    double m = 0;
    for (const Pulse &p : k.pulses) {
        double dt = t - p.start;
        if (dt < 0 || dt > attack + p.len) continue;
        double v;
        if (dt < attack) v = dt / std::max(attack, 0.001);
        else {
            double x = 1.0 - (dt - attack) / std::max(p.len, 1.0);
            v = x * x;
        }
        m = std::max(m, p.peak * v);
    }
    return m;
}

} // namespace weather
