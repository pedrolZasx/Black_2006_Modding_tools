#include <windows.h>
#include <commctrl.h>
#include <algorithm>
#include <cmath>
#include <cwchar>
#include <iterator>
#include <string>

namespace {
enum { ID_LEVEL=100, ID_ROT=101, ID_YAW=102, ID_PITCH=103, ID_ROT_EDIT=104, ID_YAW_EDIT=105, ID_PITCH_EDIT=106, ID_SAVE=107, ID_RELOAD=108, ID_BRIGHT=109, ID_CONTRAST=110, ID_SAT=111, ID_BRIGHT_EDIT=112, ID_CONTRAST_EDIT=113, ID_SAT_EDIT=114, ID_HUE=115, ID_HUE_EDIT=116, ID_ENABLED=117 };
constexpr UINT_PTR ID_AUTO_SAVE=2;
HWND g_window, g_level, g_rotation, g_yaw, g_pitch, g_bright, g_contrast, g_saturation, g_enabled;
HWND g_rot_edit, g_yaw_edit, g_pitch_edit, g_bright_edit, g_contrast_edit, g_sat_edit, g_hue, g_hue_edit, g_asset, g_status;
std::wstring g_ini;
bool g_loading;
bool g_dirty;

std::wstring ini_value(const wchar_t *section, const wchar_t *key, const wchar_t *fallback)
{
    wchar_t value[256]{};
    GetPrivateProfileStringW(section, key, fallback, value, (DWORD)std::size(value), g_ini.c_str());
    return value;
}

int mission()
{
    const LRESULT i = SendMessageW(g_level, CB_GETCURSEL, 0, 0);
    return i < 0 ? 0 : (int)i;
}

std::wstring level_section(int n)
{
    wchar_t s[32]{};
    swprintf_s(s, L"sky_level_%02d", n);
    return s;
}

float parse_float(const std::wstring &s, float fallback)
{
    wchar_t *end = nullptr;
    const float v = wcstof(s.c_str(), &end);
    return end == s.c_str() || !std::isfinite(v) ? fallback : v;
}

float read_angle(const wchar_t *key, float fallback)
{
    const std::wstring def = ini_value(L"sky", key, L"");
    const std::wstring value = ini_value(level_section(mission()).c_str(), key, def.c_str());
    return parse_float(value, fallback);
}

void put_angle(HWND edit, float value)
{
    wchar_t text[32]{};
    swprintf_s(text, L"%.1f", value);
    SetWindowTextW(edit, text);
}

void set_track(HWND slider, float value, int low, int high, float scale=1.f)
{
    SendMessageW(slider, TBM_SETRANGEMIN, FALSE, low);
    SendMessageW(slider, TBM_SETRANGEMAX, TRUE, high);
    SendMessageW(slider, TBM_SETPOS, TRUE, (LPARAM)lroundf(std::clamp(value*scale, (float)low, (float)high)));
}

void load_selected()
{
    g_loading = true;
    const int n = mission();
    wchar_t section[32]{}, filename[64]{};
    swprintf_s(section, L"sky_level_%02d", n);
    swprintf_s(filename, L"Environment image: fx\\sky_%02d.png", n);
    SetWindowTextW(g_asset, filename);

    const std::wstring enabled = ini_value(section, L"enabled", ini_value(L"sky", L"enabled", L"1").c_str());
    const bool sky_enabled = enabled != L"0" && enabled != L"false" && enabled != L"off";
    SendMessageW(g_enabled, BM_SETCHECK, sky_enabled ? BST_CHECKED : BST_UNCHECKED, 0);

    const float rotation = read_angle(L"environment_rotation", 0.f);
    const float yaw_default = 158.2f, pitch_default = 33.4f;
    const std::wstring default_dir = ini_value(L"sky", L"moon_dir", L"0.3,0.55,-0.75");
    float dx=0.3f, dy=0.55f, dz=-0.75f;
    swscanf_s(default_dir.c_str(), L"%f,%f,%f", &dx, &dy, &dz);
    const std::wstring level_dir = ini_value(section, L"moon_dir", default_dir.c_str());
    swscanf_s(level_dir.c_str(), L"%f,%f,%f", &dx, &dy, &dz);
    const float yaw = read_angle(L"moon_yaw", atan2f(dx,dz)*57.2957795f);
    const float pitch = read_angle(L"moon_pitch", asinf(std::clamp(dy,-1.f,1.f))*57.2957795f);
    put_angle(g_rot_edit, rotation);
    put_angle(g_yaw_edit, std::isfinite(yaw) ? yaw : yaw_default);
    put_angle(g_pitch_edit, std::isfinite(pitch) ? pitch : pitch_default);
    set_track(g_rotation, rotation, -180, 180);
    set_track(g_yaw, yaw, -180, 180);
    set_track(g_pitch, pitch, -89, 89);
    const float brightness=read_angle(L"environment_brightness",1.f);
    const float contrast=read_angle(L"environment_contrast",1.f);
    const float saturation=read_angle(L"environment_saturation",1.f);
    const float hue=read_angle(L"environment_hue",0.f);
    put_angle(g_bright_edit,brightness); put_angle(g_contrast_edit,contrast); put_angle(g_sat_edit,saturation);put_angle(g_hue_edit,hue);
    set_track(g_bright,brightness,0,400,100.f); set_track(g_contrast,contrast,0,300,100.f); set_track(g_saturation,saturation,0,300,100.f);
    set_track(g_hue,hue,-180,180);
    g_loading = false;
    SetWindowTextW(g_status, L"Select a mission and adjust the angles. Save writes that mission's sky_level section.");
}

float edit_value(HWND h, float fallback, float low, float high)
{
    wchar_t text[64]{};
    GetWindowTextW(h, text, (int)std::size(text));
    return std::clamp(parse_float(text, fallback), low, high);
}

void save_selected()
{
    const int n = mission();
    const float rotation = edit_value(g_rot_edit, 0.f, -180.f, 180.f);
    const float yaw = edit_value(g_yaw_edit, 0.f, -180.f, 180.f);
    const float pitch = edit_value(g_pitch_edit, 0.f, -89.f, 89.f);
    const float brightness = edit_value(g_bright_edit, 1.f, 0.f, 4.f);
    const float contrast = edit_value(g_contrast_edit, 1.f, 0.f, 3.f);
    const float saturation = edit_value(g_sat_edit, 1.f, 0.f, 3.f);
    const float hue = edit_value(g_hue_edit, 0.f, -180.f, 180.f);
    const float yr = yaw * 0.01745329252f, pr = pitch * 0.01745329252f;
    const float dx = cosf(pr)*sinf(yr), dy = sinf(pr), dz = cosf(pr)*cosf(yr);
    wchar_t section[32]{}, filename[64]{}, rotation_text[32]{}, direction[96]{}, value[32]{};
    swprintf_s(section, L"sky_level_%02d", n);
    swprintf_s(filename, L"fx\\sky_%02d.png", n);
    swprintf_s(rotation_text, L"%.2f", rotation);
    swprintf_s(direction, L"%.6f,%.6f,%.6f", dx, dy, dz);

    WritePrivateProfileStringW(L"sky", L"enabled", L"1", g_ini.c_str());
    WritePrivateProfileStringW(L"sky", L"environment_strength", L"1", g_ini.c_str());
    const bool enabled = SendMessageW(g_enabled, BM_GETCHECK, 0, 0) == BST_CHECKED;
    WritePrivateProfileStringW(section, L"enabled", enabled ? L"1" : L"0", g_ini.c_str());
    WritePrivateProfileStringW(section, L"environment", filename, g_ini.c_str());
    WritePrivateProfileStringW(section, L"environment_strength", L"1", g_ini.c_str());
    WritePrivateProfileStringW(section, L"environment_rotation", rotation_text, g_ini.c_str());
    swprintf_s(value,L"%.2f",brightness); WritePrivateProfileStringW(section,L"environment_brightness",value,g_ini.c_str());
    swprintf_s(value,L"%.2f",contrast); WritePrivateProfileStringW(section,L"environment_contrast",value,g_ini.c_str());
    swprintf_s(value,L"%.2f",saturation); WritePrivateProfileStringW(section,L"environment_saturation",value,g_ini.c_str());
    swprintf_s(value,L"%.2f",hue); WritePrivateProfileStringW(section,L"environment_hue",value,g_ini.c_str());
    WritePrivateProfileStringW(section, L"moon_dir", direction, g_ini.c_str());
    WritePrivateProfileStringW(section, L"moon", L"fx\\moon.png", g_ini.c_str());
    WritePrivateProfileStringW(nullptr, nullptr, nullptr, nullptr);
    SetWindowTextW(g_status, L"Saved to world_fx.ini. The running game reloads the file automatically.");
}

void schedule_auto_save()
{
    if(g_loading||!g_window)return;
    g_dirty=true;KillTimer(g_window,ID_AUTO_SAVE);SetTimer(g_window,ID_AUTO_SAVE,300,nullptr);
    SetWindowTextW(g_status,L"Live preview: saving this mission automatically…");
}

void label(HWND h, const wchar_t *text, int x, int y, int w, int height=22)
{
    CreateWindowW(L"STATIC", text, WS_CHILD|WS_VISIBLE, x,y,w,height,h,nullptr,nullptr,nullptr);
}

HWND edit(HWND h, int id, int x, int y)
{
    return CreateWindowExW(WS_EX_CLIENTEDGE,L"EDIT",L"0",WS_CHILD|WS_VISIBLE|WS_TABSTOP|ES_AUTOHSCROLL,
                           x,y,76,25,h,(HMENU)(INT_PTR)id,nullptr,nullptr);
}

LRESULT CALLBACK wndproc(HWND h, UINT m, WPARAM w, LPARAM l)
{
    switch(m) {
    case WM_CREATE: {
        g_window=h;
        label(h,L"Per-mission sky editor. Put each panorama in the adjacent fx folder; angles save to world_fx.ini.",16,12,700,24);
        label(h,L"Mission",16,54,80);
        g_level=CreateWindowW(WC_COMBOBOXW,L"",WS_CHILD|WS_VISIBLE|WS_TABSTOP|CBS_DROPDOWNLIST,110,48,130,240,h,(HMENU)ID_LEVEL,nullptr,nullptr);
        for(int i=0;i<100;i++){wchar_t s[24]{};swprintf_s(s,L"Mission %02d",i);SendMessageW(g_level,CB_ADDSTRING,0,(LPARAM)s);}
        SendMessageW(g_level,CB_SETCURSEL,0,0);
        g_asset=CreateWindowW(L"STATIC",L"",WS_CHILD|WS_VISIBLE,270,54,390,24,h,nullptr,nullptr,nullptr);
        g_enabled=CreateWindowW(L"BUTTON",L"Enable sky replacement for this mission",WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_AUTOCHECKBOX,270,78,360,24,h,(HMENU)ID_ENABLED,nullptr,nullptr);
        label(h,L"Sky rotation",16,106,160);
        g_rotation=CreateWindowExW(0,TRACKBAR_CLASSW,L"",WS_CHILD|WS_VISIBLE|WS_TABSTOP|TBS_NOTICKS,160,96,430,34,h,(HMENU)ID_ROT,nullptr,nullptr);
        g_rot_edit=edit(h,ID_ROT_EDIT,608,101);
        label(h,L"Moon yaw",16,162,160);
        g_yaw=CreateWindowExW(0,TRACKBAR_CLASSW,L"",WS_CHILD|WS_VISIBLE|WS_TABSTOP|TBS_NOTICKS,160,152,430,34,h,(HMENU)ID_YAW,nullptr,nullptr);
        g_yaw_edit=edit(h,ID_YAW_EDIT,608,157);
        label(h,L"Moon pitch",16,218,160);
        g_pitch=CreateWindowExW(0,TRACKBAR_CLASSW,L"",WS_CHILD|WS_VISIBLE|WS_TABSTOP|TBS_NOTICKS,160,208,430,34,h,(HMENU)ID_PITCH,nullptr,nullptr);
        g_pitch_edit=edit(h,ID_PITCH_EDIT,608,213);
        label(h,L"Texture brightness",16,274,160);g_bright=CreateWindowExW(0,TRACKBAR_CLASSW,L"",WS_CHILD|WS_VISIBLE|WS_TABSTOP|TBS_NOTICKS,160,264,430,34,h,(HMENU)ID_BRIGHT,nullptr,nullptr);g_bright_edit=edit(h,ID_BRIGHT_EDIT,608,269);
        label(h,L"Texture contrast",16,330,160);g_contrast=CreateWindowExW(0,TRACKBAR_CLASSW,L"",WS_CHILD|WS_VISIBLE|WS_TABSTOP|TBS_NOTICKS,160,320,430,34,h,(HMENU)ID_CONTRAST,nullptr,nullptr);g_contrast_edit=edit(h,ID_CONTRAST_EDIT,608,325);
        label(h,L"Texture saturation",16,386,160);g_saturation=CreateWindowExW(0,TRACKBAR_CLASSW,L"",WS_CHILD|WS_VISIBLE|WS_TABSTOP|TBS_NOTICKS,160,376,430,34,h,(HMENU)ID_SAT,nullptr,nullptr);g_sat_edit=edit(h,ID_SAT_EDIT,608,381);
        label(h,L"Texture hue",16,442,160);g_hue=CreateWindowExW(0,TRACKBAR_CLASSW,L"",WS_CHILD|WS_VISIBLE|WS_TABSTOP|TBS_NOTICKS,160,432,430,34,h,(HMENU)ID_HUE,nullptr,nullptr);g_hue_edit=edit(h,ID_HUE_EDIT,608,437);
        CreateWindowW(L"BUTTON",L"Save now",WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_PUSHBUTTON,16,500,130,34,h,(HMENU)ID_SAVE,nullptr,nullptr);
        CreateWindowW(L"BUTTON",L"Reload",WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_PUSHBUTTON,158,500,96,34,h,(HMENU)ID_RELOAD,nullptr,nullptr);
        g_status=CreateWindowW(L"STATIC",L"",WS_CHILD|WS_VISIBLE,16,552,700,36,h,nullptr,nullptr,nullptr);
        load_selected();
        return 0;
    }
    case WM_COMMAND:
        if(LOWORD(w)==ID_LEVEL && HIWORD(w)==CBN_SELCHANGE){if(g_dirty){KillTimer(h,ID_AUTO_SAVE);g_dirty=false;save_selected();}load_selected();return 0;}
        if(LOWORD(w)==ID_SAVE){KillTimer(h,ID_AUTO_SAVE);g_dirty=false;save_selected();return 0;}
        if(LOWORD(w)==ID_RELOAD){load_selected();return 0;}
        if(LOWORD(w)==ID_ENABLED && HIWORD(w)==BN_CLICKED){schedule_auto_save();SetWindowTextW(g_status,L"Live preview: sky enable state will save automatically…");return 0;}
        if(HIWORD(w)==EN_CHANGE && ((LOWORD(w)>=ID_ROT_EDIT&&LOWORD(w)<=ID_PITCH_EDIT)||(LOWORD(w)>=ID_BRIGHT_EDIT&&LOWORD(w)<=ID_HUE_EDIT))){schedule_auto_save();return 0;}
        return 0;
    case WM_HSCROLL: {
        if(g_loading)return 0;
        HWND s=(HWND)l; const int id=GetDlgCtrlID(s); float v=(float)SendMessageW(s,TBM_GETPOS,0,0);
        if(id==ID_ROT)put_angle(g_rot_edit,v);
        else if(id==ID_YAW)put_angle(g_yaw_edit,v);
        else if(id==ID_PITCH)put_angle(g_pitch_edit,v);
        else if(id==ID_BRIGHT)put_angle(g_bright_edit,v/100.f);
        else if(id==ID_CONTRAST)put_angle(g_contrast_edit,v/100.f);
        else if(id==ID_SAT)put_angle(g_sat_edit,v/100.f);
        else if(id==ID_HUE)put_angle(g_hue_edit,v);
        schedule_auto_save();
        SetWindowTextW(g_status,L"Live preview updates automatically after adjustment.");
        return 0;
    }
    case WM_TIMER:if(w==ID_AUTO_SAVE&&g_dirty){KillTimer(h,ID_AUTO_SAVE);g_dirty=false;save_selected();}return 0;
    case WM_CLOSE:if(g_dirty){KillTimer(h,ID_AUTO_SAVE);g_dirty=false;save_selected();}DestroyWindow(h);return 0;
    case WM_DESTROY:KillTimer(h,ID_AUTO_SAVE);PostQuitMessage(0);return 0;
    }
    return DefWindowProcW(h,m,w,l);
}
}

int WINAPI wWinMain(HINSTANCE instance,HINSTANCE,PWSTR,int)
{
    SetProcessDPIAware();
    INITCOMMONCONTROLSEX cc{sizeof(cc),ICC_BAR_CLASSES};
    InitCommonControlsEx(&cc);
    wchar_t path[MAX_PATH]{};
    GetModuleFileNameW(nullptr,path,(DWORD)std::size(path));
    if(wchar_t *slash=wcsrchr(path,L'\\')) slash[1]=0;
    g_ini=path; g_ini+=L"world_fx.ini";
    WNDCLASSW wc{};wc.lpfnWndProc=wndproc;wc.hInstance=instance;wc.hCursor=LoadCursorW(nullptr,IDC_ARROW);
    wc.hbrBackground=(HBRUSH)(COLOR_WINDOW+1);wc.lpszClassName=L"BlackSkyEditor";
    RegisterClassW(&wc);
    HWND h=CreateWindowW(wc.lpszClassName,L"BLACK Sky Editor",WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX,
                         CW_USEDEFAULT,CW_USEDEFAULT,760,640,nullptr,nullptr,instance,nullptr);
    if(!h)return 1;
    ShowWindow(h,SW_SHOW);UpdateWindow(h);
    MSG msg{};while(GetMessageW(&msg,nullptr,0,0)>0){TranslateMessage(&msg);DispatchMessageW(&msg);}
    return (int)msg.wParam;
}
