// In-game fly camera for level inspection. The hook is deliberately limited to the known XBE build:
// FUN_002033A0 builds the camera matrix from the quaternion at renderer+0x760 and position at +0x770.
#include "input/freecam.h"

#include "common.h"
#include "d3d/host.h"
#include "settings.h"
#include "world_lights.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cwchar>
#include <cstring>

extern "C" uint32_t g_freecam_original = 0x000135C0;
extern "C" uint32_t g_prop_init_original = 0x001D1770;

namespace freecam {

extern "C" void __cdecl freecam_apply_pose(float *pose);
extern "C" void __cdecl prop_register_actor(uint32_t actor, uint32_t record);

namespace {

constexpr uint32_t kCameraMatrixCall = 0x002034D6;
constexpr uint32_t kPlacementInitCall = 0x001D3712;
constexpr uint16_t kToggleKey = VK_F10;
constexpr uint16_t kEditToggleKey = VK_F9;
constexpr float kPi = 3.14159265358979323846f;
constexpr size_t kMaxPlacements = 1024;

struct RuntimePlacement {
    uint32_t actor;
    uint32_t record;
};

SRWLOCK g_lock = SRWLOCK_INIT;
std::atomic<bool> g_enabled{false};
bool g_pose_ready;
bool g_toggle_was_down;
bool g_editor_autostarted;
bool g_edit_toggle_was_down;
bool g_next_was_down;
bool g_previous_was_down;
bool g_frame_was_down;
std::atomic<bool> g_prop_edit{false};
bool g_prop_hook_ready;
std::array<RuntimePlacement, kMaxPlacements> g_placements{};
size_t g_placement_count;
size_t g_selected_placement = static_cast<size_t>(-1);
SRWLOCK g_placements_lock = SRWLOCK_INIT;
float g_rotation[4] = {0.0f, 0.0f, 0.0f, 1.0f}; // x, y, z, w
float g_position[3] = {};

bool readable(const void *address, size_t bytes)
{
    if (!address || bytes == 0) return false;
    MEMORY_BASIC_INFORMATION info{};
    if (VirtualQuery(address, &info, sizeof info) != sizeof info || info.State != MEM_COMMIT ||
        (info.Protect & (PAGE_NOACCESS | PAGE_GUARD))) return false;
    const uintptr_t start = reinterpret_cast<uintptr_t>(address);
    const uintptr_t region_end = reinterpret_cast<uintptr_t>(info.BaseAddress) + info.RegionSize;
    return start <= region_end && bytes <= region_end - start;
}

bool valid_placement(const RuntimePlacement &p)
{
    if (!readable(reinterpret_cast<const void *>(static_cast<uintptr_t>(p.actor)), 0x180) ||
        !readable(reinterpret_cast<const void *>(static_cast<uintptr_t>(p.record)), 0x50)) return false;
    const auto *actor = reinterpret_cast<const uint8_t *>(static_cast<uintptr_t>(p.actor));
    if (*reinterpret_cast<const uint32_t *>(actor + 0x114) != p.record ||
        *reinterpret_cast<const uint32_t *>(actor + 0x118) == 0) return false;
    return true;
}

void log_selected_placement()
{
    RuntimePlacement p{};
    size_t selected = static_cast<size_t>(-1);
    size_t count = 0;
    AcquireSRWLockShared(&g_placements_lock);
    selected = g_selected_placement;
    count = g_placement_count;
    if (selected < count) p = g_placements[selected];
    ReleaseSRWLockShared(&g_placements_lock);
    if (selected >= count || !valid_placement(p)) {
        logf("propedit: no live placement selected; cycle with [ and ]");
        return;
    }
    const auto *words = reinterpret_cast<const uint32_t *>(static_cast<uintptr_t>(p.record));
    logf("propedit: %zu/%zu actor=0x%08x record=0x%08x key=%08x/%08x",
         selected + 1, count, p.actor, p.record, words[16], words[17]);
    logf("propedit: raw record[00..0F]=%08x %08x %08x %08x | %08x %08x %08x %08x | %08x %08x %08x %08x | %08x %08x %08x %08x",
         words[0], words[1], words[2], words[3], words[4], words[5], words[6], words[7],
         words[8], words[9], words[10], words[11], words[12], words[13], words[14], words[15]);
    const auto *actor_words = reinterpret_cast<const uint32_t *>(static_cast<uintptr_t>(p.actor));
    logf("propedit: actor vtable=%08x primary[70..AC]=%08x %08x %08x %08x | %08x %08x %08x %08x | %08x %08x %08x %08x | %08x %08x %08x %08x",
         actor_words[0], actor_words[0x70 / 4], actor_words[0x74 / 4], actor_words[0x78 / 4], actor_words[0x7c / 4],
         actor_words[0x80 / 4], actor_words[0x84 / 4], actor_words[0x88 / 4], actor_words[0x8c / 4],
         actor_words[0x90 / 4], actor_words[0x94 / 4], actor_words[0x98 / 4], actor_words[0x9c / 4],
         actor_words[0xa0 / 4], actor_words[0xa4 / 4], actor_words[0xa8 / 4], actor_words[0xac / 4]);
    logf("propedit: actor mirror[140..17C]=%08x %08x %08x %08x | %08x %08x %08x %08x | %08x %08x %08x %08x | %08x %08x %08x %08x",
         actor_words[0x140 / 4], actor_words[0x144 / 4], actor_words[0x148 / 4], actor_words[0x14c / 4],
         actor_words[0x150 / 4], actor_words[0x154 / 4], actor_words[0x158 / 4], actor_words[0x15c / 4],
         actor_words[0x160 / 4], actor_words[0x164 / 4], actor_words[0x168 / 4], actor_words[0x16c / 4],
         actor_words[0x170 / 4], actor_words[0x174 / 4], actor_words[0x178 / 4], actor_words[0x17c / 4]);
}

void select_placement(int direction)
{
    AcquireSRWLockExclusive(&g_placements_lock);
    if (g_placement_count == 0) {
        g_selected_placement = static_cast<size_t>(-1);
        ReleaseSRWLockExclusive(&g_placements_lock);
        logf("propedit: no placements captured yet");
        return;
    }
    size_t candidate = g_selected_placement;
    for (size_t tries = 0; tries < g_placement_count; ++tries) {
        if (direction > 0) candidate = candidate == static_cast<size_t>(-1) ? 0 : (candidate + 1) % g_placement_count;
        else candidate = candidate == static_cast<size_t>(-1) ? g_placement_count - 1 :
                         (candidate + g_placement_count - 1) % g_placement_count;
        if (valid_placement(g_placements[candidate])) {
            g_selected_placement = candidate;
            ReleaseSRWLockExclusive(&g_placements_lock);
            log_selected_placement();
            return;
        }
    }
    g_selected_placement = static_cast<size_t>(-1);
    ReleaseSRWLockExclusive(&g_placements_lock);
    logf("propedit: no live placements found; reload the level before editing");
}

void normalize(float q[4])
{
    const float n = std::sqrt(q[0] * q[0] + q[1] * q[1] + q[2] * q[2] + q[3] * q[3]);
    if (n > 0.00001f) for (int i = 0; i < 4; ++i) q[i] /= n;
    else { q[0] = q[1] = q[2] = 0.0f; q[3] = 1.0f; }
}

void multiply(const float a[4], const float b[4], float out[4])
{
    const float x = a[3] * b[0] + a[0] * b[3] + a[1] * b[2] - a[2] * b[1];
    const float y = a[3] * b[1] - a[0] * b[2] + a[1] * b[3] + a[2] * b[0];
    const float z = a[3] * b[2] + a[0] * b[1] - a[1] * b[0] + a[2] * b[3];
    const float w = a[3] * b[3] - a[0] * b[0] - a[1] * b[1] - a[2] * b[2];
    out[0] = x; out[1] = y; out[2] = z; out[3] = w;
}

void turn(float yaw_degrees, float pitch_degrees)
{
    const float hy = yaw_degrees * (kPi / 360.0f);
    const float hp = pitch_degrees * (kPi / 360.0f);
    const float yaw[4] = {0.0f, sinf(hy), 0.0f, cosf(hy)};
    const float pitch[4] = {sinf(hp), 0.0f, 0.0f, cosf(hp)};
    float q[4];
    multiply(yaw, g_rotation, q); // yaw around world up
    multiply(q, pitch, g_rotation); // pitch around camera right
    normalize(g_rotation);
}

// The game uses Y-up and a row-vector quaternion matrix (FUN_000135C0).
void axes(float right[3], float forward[3])
{
    const float x = g_rotation[0], y = g_rotation[1], z = g_rotation[2], w = g_rotation[3];
    right[0] = 1.0f - 2.0f * (y * y + z * z);
    right[1] = 0.0f; // strafing stays level even when the camera looks up or down
    right[2] = 2.0f * (x * z - w * y);
    const float right_len = std::sqrt(right[0] * right[0] + right[2] * right[2]);
    if (right_len > 0.0001f) {
        right[0] /= right_len;
        right[2] /= right_len;
    }
    forward[0] = 2.0f * (x * z + w * y);
    forward[1] = 2.0f * (y * z - w * x);
    forward[2] = 1.0f - 2.0f * (x * x + y * y);
}

// Center the detached camera on the selected placement. The placement record's
// translation at +0x30..+0x38 is the same transform used by the editor's
// translated-BIN export. This only changes the camera pose; it never writes the
// actor or placement record.
void frame_selected_placement()
{
    RuntimePlacement p{};
    size_t selected = static_cast<size_t>(-1);
    size_t count = 0;
    AcquireSRWLockShared(&g_placements_lock);
    selected = g_selected_placement;
    count = g_placement_count;
    if (selected < count) p = g_placements[selected];
    ReleaseSRWLockShared(&g_placements_lock);

    if (selected >= count || !valid_placement(p)) {
        logf("propedit: cannot frame; select a live placement with [ or ] first");
        return;
    }

    const auto *record = reinterpret_cast<const float *>(static_cast<uintptr_t>(p.record));
    const float target[3] = {record[0x30 / 4], record[0x34 / 4], record[0x38 / 4]};
    if (!std::isfinite(target[0]) || !std::isfinite(target[1]) || !std::isfinite(target[2]) ||
        std::fabs(target[0]) > 100000.0f || std::fabs(target[1]) > 100000.0f || std::fabs(target[2]) > 100000.0f) {
        logf("propedit: cannot frame placement; transform position is not finite or in range");
        return;
    }

    float right[3], forward[3];
    axes(right, forward);
    const float horizontal = std::sqrt(forward[0] * forward[0] + forward[2] * forward[2]);
    const float fx = horizontal > 0.001f ? forward[0] / horizontal : 0.0f;
    const float fz = horizontal > 0.001f ? forward[2] / horizontal : 1.0f;
    constexpr float distance = 8.0f;
    const float eye[3] = {target[0] - fx * distance, target[1] + 2.0f, target[2] - fz * distance};
    const float dx = target[0] - eye[0], dy = target[1] - eye[1], dz = target[2] - eye[2];
    const float flat = std::sqrt(dx * dx + dz * dz);
    const float yaw_angle = std::atan2(dx, dz);
    const float pitch_angle = std::atan2(-dy, flat);
    const float yaw[4] = {0.0f, std::sin(yaw_angle * 0.5f), 0.0f, std::cos(yaw_angle * 0.5f)};
    const float pitch[4] = {std::sin(pitch_angle * 0.5f), 0.0f, 0.0f, std::cos(pitch_angle * 0.5f)};
    multiply(yaw, pitch, g_rotation);
    normalize(g_rotation);
    memcpy(g_position, eye, sizeof eye);
    logf("propedit: framed placement %zu/%zu at %.2f, %.2f, %.2f", selected + 1, count,
         target[0], target[1], target[2]);
}

__declspec(naked) void camera_matrix_thunk()
{
    __asm {
        pushfd
        pushad
        push edx
        call freecam_apply_pose
        add esp, 4
        popad
        popfd
        jmp dword ptr [g_freecam_original]
    }
}

__declspec(naked) void placement_init_thunk()
{
    __asm {
        pushfd
        pushad
        push edx
        push esi
        call prop_register_actor
        add esp, 8
        popad
        popfd
        jmp dword ptr [g_prop_init_original]
    }
}

} // namespace

extern "C" void __cdecl prop_register_actor(uint32_t actor, uint32_t record)
{
    if (!actor || !record) return;
    AcquireSRWLockExclusive(&g_placements_lock);
    for (size_t i = 0; i < g_placement_count; ++i) {
        if (g_placements[i].actor == actor) {
            g_placements[i].record = record;
            ReleaseSRWLockExclusive(&g_placements_lock);
            return;
        }
    }
    for (size_t i = 0; i < g_placement_count; ++i) {
        if (!valid_placement(g_placements[i])) {
            g_placements[i] = {actor, record};
            ReleaseSRWLockExclusive(&g_placements_lock);
            return;
        }
    }
    if (g_placement_count < g_placements.size())
        g_placements[g_placement_count++] = {actor, record};
    ReleaseSRWLockExclusive(&g_placements_lock);
}

// FUN_002033A0 calls this with EDX = renderer+0x760. Position follows the quaternion at +0x10.
// The exact pose (quaternion x y z w, position x y z) the game built its view matrix from on the last call. The renderer's
// fields can already hold the next frame's values when a frame is presented, so effects pinned to the world must use this.
static float g_render_pose[8];
static std::atomic<bool> g_render_pose_valid{false};

extern "C" void __cdecl freecam_apply_pose(float *pose)
{
    if (!pose) return;
    if (!g_enabled.load(std::memory_order_acquire)) {
        memcpy(g_render_pose, pose, sizeof g_render_pose);
        g_render_pose_valid.store(true, std::memory_order_release);
        return;
    }
    AcquireSRWLockExclusive(&g_lock);
    if (!g_pose_ready) {
        memcpy(g_rotation, pose, sizeof g_rotation);
        memcpy(g_position, pose + 4, sizeof g_position);
        normalize(g_rotation);
        g_pose_ready = true;
        logf("freecam: camera pose captured");
    }
    memcpy(pose, g_rotation, sizeof g_rotation);
    memcpy(pose + 4, g_position, sizeof g_position);
    memcpy(g_render_pose, pose, sizeof g_render_pose);
    g_render_pose_valid.store(true, std::memory_order_release);
    ReleaseSRWLockExclusive(&g_lock);
}

void install_patch()
{
    const uint8_t expected[5] = {0xE8, 0xE5, 0x00, 0xE1, 0xFF};
    auto *site = (uint8_t *)(uintptr_t)kCameraMatrixCall;
    if (memcmp(site, expected, sizeof expected) != 0) {
        logf("freecam: camera call does not match this XBE; F10 free camera disabled");
        return;
    }
    DWORD old_protect = 0;
    if (!VirtualProtect(site, sizeof expected, PAGE_EXECUTE_READWRITE, &old_protect)) {
        logf("freecam: could not make camera call writable (%lu)", GetLastError());
        return;
    }
    site[0] = 0xE8;
    const int32_t rel = (int32_t)((uintptr_t)&camera_matrix_thunk - (kCameraMatrixCall + 5));
    memcpy(site + 1, &rel, sizeof rel);
    FlushInstructionCache(GetCurrentProcess(), site, sizeof expected);
    DWORD ignored;
    VirtualProtect(site, sizeof expected, old_protect, &ignored);

    const uint8_t placement_expected[5] = {0xE8, 0x59, 0xE0, 0xFF, 0xFF};
    auto *placement_site = reinterpret_cast<uint8_t *>(static_cast<uintptr_t>(kPlacementInitCall));
    if (memcmp(placement_site, placement_expected, sizeof placement_expected) == 0 &&
        VirtualProtect(placement_site, sizeof placement_expected, PAGE_EXECUTE_READWRITE, &old_protect)) {
        const int32_t placement_rel = static_cast<int32_t>(reinterpret_cast<uintptr_t>(&placement_init_thunk) -
                                                            (kPlacementInitCall + 5));
        memcpy(placement_site + 1, &placement_rel, sizeof placement_rel);
        FlushInstructionCache(GetCurrentProcess(), placement_site, sizeof placement_expected);
        VirtualProtect(placement_site, sizeof placement_expected, old_protect, &ignored);
        g_prop_hook_ready = true;
        logf("propedit: placement capture hook ready");
    } else {
        logf("propedit: placement call does not match this XBE; prop editing disabled");
    }
    logf("freecam: ready; F10 toggles, WASD moves, Q/E changes height, mouse looks, Shift moves faster");
}

bool poll(bool focus, bool mouse_live, int mouse_dx, int mouse_dy)
{
    // Editor launchers still follow the game's normal startup and level-loading flow. Once gameplay is
    // active, detach the camera and block gamepad input so these builds behave as non-playable viewers.
    if (g_cfg.editor_mode && focus && !g_editor_autostarted) {
        g_editor_autostarted = true;
        g_enabled.store(true, std::memory_order_release);
        g_prop_edit.store(g_prop_hook_ready, std::memory_order_release);
        AcquireSRWLockExclusive(&g_lock);
        g_pose_ready = false;
        ReleaseSRWLockExclusive(&g_lock);
        host3d::request_capture(true);
        logf("editor: gameplay detected; detached camera enabled%s",
             g_prop_hook_ready ? " with placement selection" : "");
        if (g_prop_hook_ready) select_placement(1);
    }
    const bool key_down = focus && (GetAsyncKeyState(kToggleKey) & 0x8000) != 0;
    if (focus && key_down && !g_toggle_was_down) {
        const bool enable = !g_enabled.load(std::memory_order_relaxed);
        g_enabled.store(enable, std::memory_order_release);
        if (!enable) { g_prop_edit.store(false, std::memory_order_release); world_lights::close_editor(); }
        AcquireSRWLockExclusive(&g_lock);
        g_pose_ready = false;
        ReleaseSRWLockExclusive(&g_lock);
        if (enable) host3d::request_capture(true);
        logf("freecam: %s", enable ? "enabled" : "disabled");
    }
    g_toggle_was_down = key_down;
    if (!g_enabled.load(std::memory_order_acquire)) return false;

    const bool edit_toggle = focus && (GetAsyncKeyState(kEditToggleKey) & 0x8000) != 0;
    if (edit_toggle && !g_edit_toggle_was_down) {
        if (!g_prop_hook_ready) {
            logf("propedit: unavailable because the placement hook was not installed");
        } else {
            const bool edit_enabled = !g_prop_edit.load(std::memory_order_relaxed);
            g_prop_edit.store(edit_enabled, std::memory_order_release);
            logf("propedit: %s (HUD selection marker; [ ] cycle; movement disabled until actor and collision updates are traced)",
                 edit_enabled ? "enabled" : "disabled");
            if (edit_enabled) select_placement(1);
        }
    }
    g_edit_toggle_was_down = edit_toggle;

    uint32_t timer = *(const uint32_t *)(uintptr_t)0x002D45D4;
    float dt = timer ? *(const float *)(uintptr_t)(timer + 0x1C) : 1.0f / 60.0f;
    if (!(dt > 0.0f && dt < 0.25f)) dt = 1.0f / 60.0f;
    AcquireSRWLockExclusive(&g_lock);
    if (g_pose_ready) {
        if (mouse_live) turn(-mouse_dx * 0.022f * g_cfg.mouse_sens,
                             (g_cfg.mouse_invert ? -mouse_dy : mouse_dy) * 0.022f * g_cfg.mouse_sens);
        float right[3], forward[3];
        axes(right, forward);
        float f = (focus && (GetAsyncKeyState('W') & 0x8000) ? 1.0f : 0.0f) -
                  (focus && (GetAsyncKeyState('S') & 0x8000) ? 1.0f : 0.0f);
        float r = (focus && (GetAsyncKeyState('A') & 0x8000) ? 1.0f : 0.0f) -
                  (focus && (GetAsyncKeyState('D') & 0x8000) ? 1.0f : 0.0f);
        float u = (focus && (GetAsyncKeyState('E') & 0x8000) ? 1.0f : 0.0f) -
                  (focus && (GetAsyncKeyState('Q') & 0x8000) ? 1.0f : 0.0f);
        const float speed = 8.0f * dt * (focus && (GetAsyncKeyState(VK_SHIFT) & 0x8000) ? 4.0f : 1.0f);
        for (int i = 0; i < 3; ++i) g_position[i] += (forward[i] * f + right[i] * r) * speed;
        g_position[1] += u * speed;

        if (g_prop_edit.load(std::memory_order_acquire) && focus) {
            const bool next_down = (GetAsyncKeyState(VK_OEM_6) & 0x8000) != 0;
            const bool previous_down = (GetAsyncKeyState(VK_OEM_4) & 0x8000) != 0;
            if (next_down && !g_next_was_down) select_placement(1);
            if (previous_down && !g_previous_was_down) select_placement(-1);
            const bool frame_down = (GetAsyncKeyState('F') & 0x8000) != 0;
            if (frame_down && !g_frame_was_down) frame_selected_placement();
            g_frame_was_down = frame_down;
            g_next_was_down = next_down;
            g_previous_was_down = previous_down;
        }
    }
    ReleaseSRWLockExclusive(&g_lock);
    if (g_pose_ready) {
        float right[3], forward[3]; axes(right, forward);
        world_lights::editor_poll(focus, g_position, forward);
    }
    return true;
}

bool active() { return g_enabled.load(std::memory_order_acquire); }

bool render_pose(float out[8])
{
    if (!g_render_pose_valid.load(std::memory_order_acquire)) return false;
    memcpy(out, g_render_pose, sizeof g_render_pose);
    return true;
}

bool selection_overlay_active()
{
    return g_enabled.load(std::memory_order_acquire) && g_prop_edit.load(std::memory_order_acquire);
}

bool selection_overlay_text(std::wstring &text)
{
    if (!selection_overlay_active()) return false;

    size_t selected = static_cast<size_t>(-1);
    size_t count = 0;
    AcquireSRWLockShared(&g_placements_lock);
    selected = g_selected_placement;
    count = g_placement_count;
    ReleaseSRWLockShared(&g_placements_lock);

    wchar_t label[64]{};
    if (selected >= count)
        std::swprintf(label, sizeof(label) / sizeof(label[0]), L"PLACEMENT --/--  NO LIVE SELECTION");
    else
        std::swprintf(label, sizeof(label) / sizeof(label[0]), L"PLACEMENT %u/%u SELECTED",
                      static_cast<unsigned>(selected + 1), static_cast<unsigned>(count));
    text.assign(label);
    return true;
}

} // namespace freecam
