#pragma once

#include <string>

namespace freecam {

// Install the known-build hook immediately after the XBE has been mapped.
void install_patch();

// Called once per XInput poll. Returns true while the free camera owns input.
bool poll(bool focus, bool mouse_live, int mouse_dx, int mouse_dy);
bool active();
// Pose the game last built its camera matrix from: q[0..3] = x y z w, [4..6] = position. False before the first frame.
bool render_pose(float out[8]);
bool selection_overlay_active();
bool selection_overlay_text(std::wstring &text);

} // namespace freecam
